// Handlers extras: /mensagem (painel de publicacao) e /lock e /unlock.
// Registrados via registrar(client) para manter o index.js enxuto.

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const { comandoPode } = require('./permissions');
const { linhaSelecaoCanalDe, resolverSelecaoCanal } = require('./channelPicker');
const { urlValida } = require('./embedPainel');
const { getSessao, limparSessao, buildEmbed, buildPainel, buildPreview, buildEscolhaPainel } = require('./mensagemPainel');
const { capturarEstado, guardarEstado, estadoSalvo } = require('./channelLock');


function pode(interaction, cmd) {
  return comandoPode(interaction.member, interaction.user.id, cmd);
}


function registrar(client) {
  client.on('interactionCreate', async (interaction) => {
    try {
      // ---------- Escolha embed vs mensagem normal ----------
      if (interaction.isButton() && interaction.customId.startsWith('msgescolha:')) {
        const partes = interaction.customId.split(':');
        const donoId = partes[2];
        if (interaction.user.id !== donoId) {

          return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
        }
        if (!pode(interaction, 'mensagem')) {
          return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
        }
        const estado = getSessao(donoId);
        if (partes[1] === 'normal') {
          // Abre o modal de edicao direto: o usuario pode digitar a mensagem agora
          const modal = new ModalBuilder()
            .setCustomId(`msgmodal:mensagem:${donoId}`)
            .setTitle('📝 Mensagem')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('valor')
                  .setLabel('Texto da mensagem')
                  .setStyle(TextInputStyle.Paragraph)
                  .setRequired(true)
                  .setMaxLength(2000)
                  .setValue(estado.mensagem ? String(estado.mensagem).slice(0, 2000) : '')
              )
            );
          return interaction.showModal(modal);
        }
        if (partes[1] === 'embed') {
          estado.tipo = 'embed';
          const eb = require('./embedPainel');
          const sessaoEmbed = eb.getSessao(donoId);
          if (estado.mensagem) sessaoEmbed.descricao = estado.mensagem;
          if (estado.imagens?.length) sessaoEmbed.imagem = estado.imagens[0];

          return interaction.update(eb.buildPainel(donoId, interaction.guildId));
        }
        if (partes[1] === 'cancelar') {
          limparSessao(donoId);
          return interaction.update({ content: '❌ Cancelado.', embeds: [], components: [] });
        }
        return;
      }

      // ---------- Painel de edicao da mensagem ----------
      if (interaction.isButton() && interaction.customId.startsWith('msgpainel:')) {
        const partes = interaction.customId.split(':');
        const acao = partes[1];
        const donoId = partes[2];
        if (interaction.user.id !== donoId) {

          return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
        }
        if (!pode(interaction, 'mensagem')) {
          return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
        }
        const estado = getSessao(donoId);

        const abrirModal = (campo, titulo, label, multiline = false) => {
          const atual = estado[campo] || '';
          const modal = new ModalBuilder()
            .setCustomId(`msgmodal:${campo}:${donoId}`)
            .setTitle(titulo)
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('valor')
                  .setLabel(label)
                  .setStyle(multiline ? TextInputStyle.Paragraph : TextInputStyle.Short)
                  .setRequired(false)
                  .setValue(atual)
                )
              );
        return interaction.showModal(modal);
        };

        if (acao === 'mensagem') return abrirModal('mensagem', '📝 Mensagem', 'Texto da mensagem', true);
        if (acao === 'imagem') return abrirModal('imagem', '🖼️ Imagem', 'URL da imagem (ou vazio para remover)');
        if (acao === 'preview') return interaction.update(buildPreview(donoId, interaction.guildId));
        if (acao === 'voltar') return interaction.update(buildPainel(donoId, interaction.guildId));
        if (acao === 'publicar') {
          if (!estado.mensagem && !(estado.imagens || []).length) {

            return interaction.reply({ content: '❌ Preencha a mensagem ou escolha uma imagem.', flags: MessageFlags.Ephemeral });
          }
          const canais = linhaSelecaoCanalDe(interaction.guild, `msgcanal:${donoId}`, interaction.channel.id, '📣 Escolha o canal para publicar…');
          if (!canais.canais.length) {
            return interaction.reply({ content: '❌ Não encontrei nenhum canal para publicar.', flags: MessageFlags.Ephemeral });
          }
          const preview = buildEmbed(estado);
          return interaction.update({
            content: '🗂️ **Onde deseja publicar?**\n_Selecione um canal abaixo ou use **📌 Canal atual**._',
            embeds: preview ? [new EmbedBuilder().setColor(0xbeb6ff).setDescription('👁️ Isto será publicado:'), preview] : [new EmbedBuilder().setColor(0xbeb6ff).setDescription('👁️ Isto será publicado:')],
            components: [canais.row, canais.botoes],
          });
        }
        if (acao === 'cancelar') {
            limparSessao(donoId);
          return interaction.update({ content: '❌ Publicação cancelada.', embeds: [], components: [] });
        }
        return;
      }

      // ---------- Modais da mensagem ----------
      if (interaction.isModalSubmit() && interaction.customId.startsWith('msgmodal:')) {
        const partes = interaction.customId.split(':');
        const campo = partes[1];
        const donoId = partes[2];
        if (interaction.user.id !== donoId) {

          return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
        }
        const estado = getSessao(donoId);
        const valor = interaction.fields.getTextInputValue('valor').trim();
        if (campo === 'imagem') {
          if (!valor) {
            estado.imagens = [];
            return interaction.update(buildPainel(donoId, interaction.guildId));
          }
          if (!urlValida(valor)) {
            return interaction.reply({ content: '❌ URL de imagem inválida. Use um link completo com http(s)://. Deixe vazio para limpar as imagens.', flags: MessageFlags.Ephemeral });
          }
          estado.imagens.push(valor);
          if (estado.imagens.length > 10) estado.imagens = estado.imagens.slice(-10);
        } else {
          estado.mensagem = valor || null;
        }
          return interaction.update(buildPainel(donoId, interaction.guildId));
      }

      // ---------- Selecao de canal da mensagem ----------
      if ((interaction.isStringSelectMenu() || interaction.isButton()) && interaction.customId.startsWith('msgcanal:')) {
        const partes = interaction.customId.split(':');
        const donoId = partes[1];
        if (interaction.user.id !== donoId) {

          return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
        }
        if (!pode(interaction, 'mensagem')) {
          return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
       }
        if (interaction.isButton() && partes[2] === 'cancelar') {
          limparSessao(donoId);
          return interaction.reply({ content: '❌ Publicação cancelada.', flags: MessageFlags.Ephemeral });
       }
        const { canal } = resolverSelecaoCanal(interaction, `msgcanal:${donoId}`);
        if (!canal || !canal.isTextBased() || !canal.permissionsFor(interaction.guild.members.me)?.has('SendMessages')) {
          return interaction.reply({ content: '❌ Canal não encontrado ou sem permissão de envio para mim.', flags: MessageFlags.Ephemeral });
       }
        const estado = getSessao(donoId);
        const conteudo = estado.mensagem || null;
        const arquivos = (estado.imagens || []).slice(0, 10).map((url) => ({ attachment: url }));
        try {
          if (conteudo && conteudo.length > 2000) {
            // Texto longo: divide em fatias de até 2000 (anexos vão na última).
            const fatias = [];
            for (let i = 0; i < conteudo.length; i += 2000) {
              fatias.push(conteudo.slice(i, i + 2000));
            }
            for (let i = 0; i < fatias.length; i++) {
              const ultima = i === fatias.length - 1;
              await canal.send({
                content: fatias[i],
                files: ultima ? arquivos : [],
                allowedMentions: { parse: [] },
              });
            }
          } else {
            await canal.send({ content: conteudo, files: arquivos, allowedMentions: { parse: [] } });
          }
        } catch (e) {
          console.error('[Mensagem] Falha ao publicar:', e?.message || e);
          return interaction.reply({ content: `❌ Não consegui publicar em <#${canal.id}>. Verifique minhas permissões no canal.`, flags: MessageFlags.Ephemeral });
        }
        limparSessao(donoId);
        return interaction.update({ content: `✅ Mensagem publicada em <#${canal.id}>!`, embeds: [], components: [] });
      }
    } catch (error) {
      console.error('[Mensagem] Erro:', error);
      try {
        if (!interaction.replied && !interaction.deferred) {

          await interaction.reply({ content: '❌ Ocorreu um erro.', flags: MessageFlags.Ephemeral });
        }
      } catch {}
    }
  });

  // ---------- /lock ----------
  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isButton() && interaction.customId.startsWith('lockconf:')) {
        const partes = interaction.customId.split(':');
        if (!pode(interaction, 'lock')) return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
        if (partes[1] === 'cancelar') return interaction.reply({ content: '❌ Cancelado.', flags: MessageFlags.Ephemeral });
        if (partes[1] !== 'confirmar') return;
        const canalLock = interaction.guild.channels.cache.get(partes[2]);
        if (!canalLock) return interaction.reply({ content: '❌ Canal não encontrado.', flags: MessageFlags.Ephemeral });
        // So guarda o backup se ainda nao houver estado salvo: um segundo /lock
        // no mesmo canal (sem desbloquear) nao pode sobescrever o estado original..
        if (!estadoSalvo(canalLock.id)) {
          const estadoAnt = capturarEstado(canalLock);
          guardarEstado(canalLock.id, estadoAnt);
        }
        try {
          await canalLock.permissionOverwrites.edit(canalLock.guild.roles.everyone.id, { SendMessages: false });
        } catch (e) {
          console.error('[Lock] Falha:', e?.message || e);
          return interaction.reply({ content: '❌ Não consegui bloquear o canal.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update({ content: `🔒 Canal bloqueado: ${canalLock}.`, embeds: [], components: [] });
      }
    } catch (error) {
      console.error('[Lock] Erro:', error);
      try {
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: '❌ Ocorreu um erro.', flags: MessageFlags.Ephemeral });
        }
      } catch {}
    }
  });

  // ---------- /unlock ----------
  client.on('interactionCreate', async (interaction) => {
    try {
      if (interaction.isButton() && interaction.customId.startsWith('unlockconf:')) {
        const partes = interaction.customId.split(':');
        if (!pode(interaction, 'unlock')) return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
        if (partes[1] === 'cancelar') return interaction.reply({ content: '❌ Cancelado.', flags: MessageFlags.Ephemeral });
        if (partes[1] !== 'confirmar') return;
        const canalUnlock = interaction.guild.channels.cache.get(partes[2]);
        if (!canalUnlock) return interaction.reply({ content: '❌ Canal não encontrado.', flags: MessageFlags.Ephemeral });
        const estadoLock = estadoSalvo(canalUnlock.id);
        try {
          if (estadoLock) {
            await canalUnlock.permissionOverwrites.edit(canalUnlock.guild.roles.everyone.id
              , { SendMessages: estadoLock.allow ? true : estadoLock.deny ? false : null });
          } else {
            const overwrite2 = canalUnlock.permissionOverwrites.cache.get(canalUnlock.guild.roles.everyone.id);
            if (overwrite2) await overwrite2.delete('unlock pelo admin').catch(() => {});
          }
          guardarEstado(canalUnlock.id, null);
        } catch (e) {
          console.error('[Unlock] Falha:', e?.message || e);
          return interaction.reply({ content: '❌ Não consegui desbloquear o canal.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update({ content: `🔓 Canal desbloqueado: ${canalUnlock}.`, embeds: [], components: [] });
      }
    } catch (error) {
      console.error('[Unlock] Erro:', error);
      try {
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({ content: '❌ Ocorreu um erro.', flags: MessageFlags.Ephemeral });
        }
      } catch {}
    }
  });
}

module.exports = { registrar };
