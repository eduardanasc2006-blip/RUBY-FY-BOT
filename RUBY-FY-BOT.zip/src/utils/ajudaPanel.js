const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

const COR = 0xbeb6ff;
// Páginas sempre visíveis + admin (só aparecem para admin). A página
// "personalizados" (comandos custom) so existe dentro de um servidor, pois
// os comandos personalizados sao por-servidor (nao existem em DM).

// Categorias entre as quais se navega com as setas (a home fica de fora.)
const CATEGORIAS_PUBLICAS = ['conversor', 'estoque', 'compras'];
const CATEGORIAS_ADMIN = ['personalizados', 'painel', 'admin'];

// Lista central de comandos (prefixo e slash) para o menu de ajuda.
// É gerada dinamicamente a partir dos arquivos reais em src/commands e
// src/prefixCommands, então nunca fica desatualizada e sempre mostra o `!`
// e/ou o `/` que de fato existirem para cada comando.
const fs = require('node:fs');
const path = require('node:path');

function carregarComandos() {
 // Nomes vêm do nome dos arquivos (cada comando = um arquivo), evitando
 // require aqui para não gerar dependência circular com src/prefixCommands.
 const slashDir = path.join(__dirname, '..', 'commands');
 const prefixDir = path.join(__dirname, '..', 'prefixCommands');
 const slashPorNome = {};
 for (const f of fs.readdirSync(slashDir).filter((x) => x.endsWith('.js'))) {
 slashPorNome[path.basename(f, '.js')] = '/';
 }
 const prefixPorNome = {};
 for (const f of fs.readdirSync(prefixDir).filter((x) => x.endsWith('.js'))) {
 prefixPorNome[path.basename(f, '.js')] = '!';
 }
 // help e menu são aliases do comando de prefixo ajuda.
 const aliasPorNome = { help: '!', menu: '!' };
 return { slashPorNome, prefixPorNome, aliasPorNome };
}

const { slashPorNome, prefixPorNome, aliasPorNome } = carregarComandos();

const COMANDOS = [
 { grupo: 'Ajuda', cmd: 'ajuda', desc: 'Abre este menu de ajuda.', admin: false },
 { grupo: 'Ajuda', cmd: 'help', desc: 'Alias do menu de ajuda.', admin: false },
 { grupo: 'Conversor', cmd: 'robux', desc: 'Converte Robux em reais.', admin: false },
 { grupo: 'Conversor', cmd: 'reais', desc: 'Converte reais em Robux.', admin: false },
 { grupo: 'Conversor', cmd: 'gamepass', desc: 'Calcula o valor do Game Pass.', admin: false },
 { grupo: 'Conversor', cmd: 'taxa', desc: 'Mostra as taxas atuais.', admin: false },
 { grupo: 'Estoque', cmd: 'estoque', desc: 'Mostra produtos e preços ( ou busca: !estoque <nome>).', admin: false },
 { grupo: 'Compras', cmd: 'comprar', desc: 'Inicia uma compra pelos produtos do estoque.', admin: false },
 { grupo: 'Compras', cmd: 'cliente', desc: 'Mostra os cargos de cliente conquistados.', admin: false },
 { grupo: 'Compras', cmd: 'metas', desc: 'Configura metas de cargos para clientes.', admin: true },
 { grupo: 'Painéis', cmd: 'painel', desc: 'Gerenciador central dos painéis fixos.', admin: true },
 { grupo: 'Painéis', cmd: 'tabela', desc: 'Publica o painel de conversão.', admin: true },
 { grupo: 'Painéis', cmd: 'painelestoque', desc: 'Fixa o painel de estoque.', admin: true },
 { grupo: 'Painéis', cmd: 'painelcategoria', desc: 'Sem arg: seletor visual de categoria. Com <id>: fixa a categoria.', admin: true },
 { grupo: 'Administração', cmd: 'configtaxa', desc: 'Painel visual das taxas.', admin: true },
 { grupo: 'Administração', cmd: 'settaxa', desc: 'Altera a taxa (ex: !settaxa 100 3,50).', admin: true },
 { grupo: 'Administração', cmd: 'configestoque', desc: 'Gerencia produtos e quantidades.', admin: true },
 { grupo: 'Administração', cmd: 'embed', desc: 'Cria uma embed no canal.', admin: true },
 { grupo: 'Administração', cmd: 'backup', desc: 'Backup de taxas e estoque na DM.', admin: true },
 { grupo: 'Administração', cmd: 'canalavisos', desc: 'Canal de avisos de estoque.', admin: true },
 { grupo: 'Administração', cmd: 'logcompras', desc: 'Define o canal de logs das compras.', admin: true },
 { grupo: 'Administração', cmd: 'setproof', desc: 'Define o canal padrão dos proofs.', admin: true },
 { grupo: 'Administração', cmd: 'proof', desc: 'Posta o proof com seletor de cliente e canal.', admin: true },
 { grupo: 'Administração', cmd: 'limpar', desc: 'Apaga mensagens do canal.', admin: true },
 { grupo: 'Administração', cmd: 'mensagem', desc: 'Publica mensagem simples com até 10 imagens/links.', admin: true },
 { grupo: 'Administração', cmd: 'lock', desc: 'Bloqueia um canal para membros comuns.', admin: true },
 { grupo: 'Administração', cmd: 'unlock', desc: 'Desbloqueia um canal restaurando permissões.', admin: true },
 { grupo: 'Administração', cmd: 'rolegive', desc: 'Dá um cargo a um membro.', admin: true },
{ grupo: 'Administração', cmd: 'modelos', desc: 'Lista e usa modelos de embed salvos neste servidor.', admin: true },
{ grupo: 'Administração', cmd: 'setwelcome', desc: 'Personaliza a mensagem de boas-vindas do servidor.', admin: true },
{ grupo: 'Administração', cmd: 'testwelcome', desc: 'Envia a mensagem de boas-vindas neste canal para testar.', admin: true },
{ grupo: 'Ajuda', cmd: 'ping', desc: 'Testa a latência do bot.', admin: false },
{ grupo: 'Ajuda', cmd: 'info', desc: 'Mostra informações básicas do bot.', admin: false },
{ grupo: 'Ajuda', cmd: 'calc', desc: 'Calculadora: faça cálculos simples (+, -, *, /, %, parênteses).', admin: false },

 { grupo: 'Administração', cmd: 'permissoes', desc: 'Gerencia permissões por cargo.', admin: true },
 { grupo: 'Comandos personalizados', cmd: 'criarcomando', desc: 'Cria um comando personalizado.', admin: true },
 { grupo: 'Comandos personalizados', cmd: 'gerenciarcomandos', desc: 'Lista, edita ou exclui personalizados.', admin: true },
].map((c) => {
 const pre = prefixPorNome[c.cmd] ? '!' + c.cmd : null;
 const aliasPre = !pre && aliasPorNome[c.cmd] ? '!' + c.cmd : null;
 const slash = slashPorNome[c.cmd] ? '/' + c.cmd : null;
 return { ...c, pre: pre || aliasPre, slash };
});

// Comandos personalizados criados pelo dono (adicionados dinamicamente)
const customCom = require('./customCommands');

const PAGINAS = {
  inicio: () => ({
    titulo: '☁️ RUBY FY BOT — AJUDA',
    descricao: [
      '*Olá! Escolha abaixo o que você deseja consultar.*',
      '',
      '☁️ **CONVERSOR**',
      '*Ferramentas para calcular valores de Robux.*',
      '',
      '☁️ **ESTOQUE**',
      '*Veja os produtos disponíveis e seus valores.*',
      '',
      '☁️ **COMPRAS**',
      '*Compre produtos do estoque direto pelo bot.*',
      '',
      '☁️ **ADMINISTRAÇÃO**',
      '*Configurações disponíveis para administradores.*',
      '',
      '☁️ **AJUDA**',
      '*Utilidades e informações do bot.*',
      '',
      '➜ **!ping** — *Testa a latência do bot.*',
      '➜ **!info** — *Mostra informações do bot.*',
      '➜ **!calc <expressão>** — *Calculadora rápida.*',
      '',
      '━━━━━━━━━━━━━━━━━━',
    ].join('\n'),
  }),

  conversor: () => ({
    titulo: '☁️ CONVERSOR',
    descricao: [
      '*Escolha uma opção abaixo.*',
      '',
      '➜ **!robux <qtd>**',
      '*Descubra quanto custa determinada quantidade de Robux.*',
      '',
      '➜ **!reais <valor>**',
      '*Descubra quantos Robux correspondem a determinado valor.*',
      '',
      '➜ **!gamepass <robux>**',
      '*Descubra quanto cobrar no Game Pass para receber a quantidade desejada.*',
      '',
      '➜ **!taxa**',
      '*Consulte as taxas atuais.*',
    ].join('\n'),
  }),

  estoque: () => ({
    titulo: '☁️ ESTOQUE',
    descricao: [
      '*Consulte os produtos disponíveis e seus valores.*',
      '',
      '➜ **!estoque**',
      '*Abra o painel de estoque e escolha uma categoria.*',
      '',
      '*O estoque, os painéis fixos e as permissões são **por servidor** (cada server tem os seus).*',
    ].join('\n'),
  }),

  compras: () => ({
    titulo: '☁️ COMPRAS',
    descricao: [
      '*Compre produtos do estoque direto pelo bot, dentro do seu ticket.*',
      '',
      '➜ **/comprar**',
      '*Inicia a compra: escolha categoria, produto e quantidade.*',
      '',
      '➜ **/cliente <@usuário>**',
      '*Mostra os cargos de cliente já conquistados.*',
      '',
      '➜ **/metas (adm)**',
      '*Configura metas de cargos para clientes.*',
      '',
      '➜ **/logcompras (adm)**',
      '*Configura o canal donde ficam os logs das compras.*',
      '',
      '➜ **/proof (adm)**',
      '*Posta o comprovante do pedido. Anexe as imagens e no fluxo escolha **cliente** (busca pelo @), **canal** e **produto** (vem do estoque, sem dar baixa).*',
      '',
      '➜ **!proof (adm)**',
      '*Mesmo fluxo do /proof, mas por mensagem: anexe as imagens e clique no botão para preencher.*',
      '',
      '*Após o pedido, envie o comprovante no ticket e aguarde a confirmação da equipe.*',
    ].join('\n'),
  }),


  personalizados: (guildId) => {
    const lista = Object.values(customCom.listar(guildId));
    const linhas = [];
    if (lista.length === 0) {
      linhas.push('*Nenhum comando personalizado criado ainda.*', '');
      linhas.push('Use **/criarcomando (adm)** para criar o seu comando.', '');
      linhas.push('Com **/criarcomando (adm)** você define nome, título da embed, descrição, mensagem, cor, imagem (URL **ou anexo**) e conteúdos copiáveis.', '');
      linhas.push('Com **/gerenciarcomandos (adm)** você lista, edita ou exclui os já criados.');
      linhas.push('Os comandos criados são chamados com **!nome** (prefixo, não slash).');
    } else {
      for (const c of lista) {
        const extras = c.copiaveis && c.copiaveis.length ? ` — 📋 ${c.copiaveis.length} copiável(is)` : '';
        linhas.push(`➜ **!${c.nome}**${extras}`);
        if (c.descricao) linhas.push(`> *${c.descricao}*`);
        linhas.push('');
      }
    }
    return { titulo: '☁️ COMANDOS PERSONALIZADOS', descricao: linhas.join('\n') };
  },

  painel: () => ({
    titulo: '☁️ PAINÉIS FIXOS (adm)',
    descricao: [
      '➜ **!painel (adm)** — *Gerenciador central: mostra e publica/atualiza os painéis fixos.*',
      '',
      '➜ **!tabela (adm)** — *Publica o painel de conversão com botões no canal.*',
      '',
      '➜ **!painelestoque (adm)** — *Publica o painel fixo de estoque (atualiza sozinho).*',
      '',
      '➜ **!painelcategoria <id> (adm)** — *Fixar a categoria: sem id abre o seletor; com <id> fixa direto.*',
      '',
      '*Os painéis são **por servidor** e atualizam automaticamente quando algo muda.*',
    ].join('\n'),
  }),

  admin: () => ({
    titulo: '☁️ ADMINISTRAÇÃO',
    descricao: [
      '🔒 *Área exclusiva para administradores autorizados.*',
      '',
      '➜ **!settaxa 100 <valor> (adm)**',
      '*Altera a taxa de 100 a 999 Robux.*',
      '',
      '➜ **!settaxa 1000 <valor> (adm)**',
      '*Altera a taxa de 1.000 Robux ou mais.*',
      '',
      '➜ **!configtaxa (adm)**',
      '*Abre o painel visual de configuração das taxas.*',
      '',
      '➜ **!configestoque (adm)**',
      '*Gerencia categorias, produtos, valores e estoque (por servidor).*',
      '',
      '➜ **/metas (adm)**',
      '*Configura metas de cargos para clientes.*',
      '',
      '➜ **/comprar (adm)**',
      '*Aprova ou cancela pedidos confirmando/cancelando nos botões do pedido.*',
      '',
      '➜ **/logcompras (adm)**',
      '*Define o canal onde ficam os logs das compras (pedido criado, cancelado, confirmado e metas).*',
      '',
      '➜ **!embed (adm)**',
      '*Cria uma embed no canal.*',
      '',
      '➜ **!backup (adm)**',
      '*Backup das taxas e estoque na DM.*',
      '',
      '➜ **!canalavisos (adm)**',
      '*Canal de avisos quando um produto esgota.*',
      '',
      '➜ **!autoresposta / /autoresposta (adm)**',
      '*Gerencia respostas automáticas por palavra (ver, adicionar, remover, canais).*',
      '',
      '➜ **!limpar <1-100> (adm)**',
      '*Apaga mensagens do canal.*',
      '',
      '➜ **!mensagem / /mensagem (adm)**',
      '*Publica uma mensagem simples em qualquer canal — aceita até 5 imagens anexadas e links (até 10 no total).*',
      '',
      '➜ **!lock (adm)**',
      '*Bloqueia um canal para membros comuns.*',
      '',
      '➜ **!unlock (adm)**',
      '*Desbloqueia um canal restaurando permissões.*',
      '',
      '➜ **!rolegive <@cargo> <@usuario> (adm)**',
      '*Dá um cargo a um membro.*',
      '',
      '➜ **!permissoes (adm)**',
      '*Gerencia permissões por cargo.*',
      '',
      '➜ **!modelos (adm)**',
      '*Lista e usa modelos de embed salvos neste servidor.*',
      '',
      '➜ **!setwelcome (adm)**',
      '*Personaliza a mensagem de boas-vindas do servidor.*',
      '',
      '➜ **!testwelcome (adm)**',
      '*Envia a mensagem de boas-vindas neste canal para testar.*',
    ].join('\n'),
  }),
};

function buildAjuda(pagina = 'inicio', isAdmin = false, guildId = null) {
  let pag = PAGINAS[pagina] ? pagina : 'inicio';
  if ((pag === 'admin' || pag === 'painel' || pag === 'personalizados') && !isAdmin) pag = 'inicio';
  // Comandos personalizados sao por-servidor: a pagina so existe no servidor
  // (em DM nao ha o que listar, entao cai para a home).
  if (!guildId && pag === 'personalizados') pag = 'inicio';

  const dados = PAGINAS[pag](guildId, isAdmin);;
  const embed = new EmbedBuilder()
    .setColor(COR)
    .setTitle(dados.titulo)
    .setDescription(dados.descricao)
    .setFooter({ text: 'RUBY FY BOT — !ajuda' });

  const rows = [];

  if (pag === 'inicio') {
    const categorias = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ajuda:cat:conversor').setEmoji('🎮').setLabel('Conversor').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('ajuda:cat:estoque').setEmoji('📦').setLabel('Estoque').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('ajuda:cat:compras').setEmoji('🛒').setLabel('Compras').setStyle(ButtonStyle.Primary),
    );
    rows.push(categorias);

    if (isAdmin) {
      const extras = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ajuda:cat:admin').setEmoji('⚙️').setLabel('Administração').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('ajuda:cat:personalizados').setEmoji('📋').setLabel('Comandos').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('ajuda:cat:painel').setEmoji('🖼️').setLabel('Painel').setStyle(ButtonStyle.Secondary),
      );
      rows.push(extras);
    }
  } else {
    // Navegação entre categorias com setas: ◀️ Anterior | 🏠 Início | Próxima ▶️
    // Catálogo de navegação: admin anda por todas; público só pelas públicas.
    const cats = isAdmin ? [...CATEGORIAS_PUBLICAS, ...CATEGORIAS_ADMIN] : CATEGORIAS_PUBLICAS;
    const idx = cats.indexOf(pag);
    const prev = idx > 0 ? cats[idx - 1] : cats[cats.length - 1];
    const next = idx < cats.length - 1 ? cats[idx + 1] : cats[0];
    const nav = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`ajuda:nav:prev:${prev}`).setEmoji('◀️').setLabel('Anterior').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('ajuda:nav:home:inicio').setEmoji('🏠').setLabel('Início').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId(`ajuda:nav:next:${next}`).setEmoji('▶️').setLabel('Próxima').setStyle(ButtonStyle.Primary),
    );
    rows.push(nav);
  }

  return { embeds: [embed], components: rows };
}

module.exports = { buildAjuda };
