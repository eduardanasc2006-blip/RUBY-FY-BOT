require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');

// Garante que apenas UMA instância do bot rode por vez (evita duplicação de
// respostas quando o host/Discloud sobe o processo duas vezes, ex.: MAIN +
// START apontando para o mesmo arquivo, ou restart sem matar o processo antigo).
const LOCK_FILE = path.join(__dirname, '..', '.bot.lock');
const LOCK_MAX_IDADE_MS = 10 * 60 * 1000; // lock mais velho que isso e considerado obsoleto
function tentarObterLock() {
  try {
    const pid = Number(fs.readFileSync(LOCK_FILE, 'utf8'));
    // PID 1 e o init do container: process.kill(1, 0) sempre "existe" no Linux,
    // entao nunca pode ser tratado como outra instancia. Um lock com PID 1 veio
    // de um restart/reconnect anterior (ex.: Discloud) e deve ser reutilizado.
    if (pid > 1 && pid !== process.pid) {
      let vivo = false;
      try {
        process.kill(pid, 0); // só checa se o processo existe, sem matar
        vivo = true;
      } catch {
        vivo = false; // PID antigo morto → pode assumir o lock
      }
      // Mesmo com o PID vivo, um lock antigo (ex.: PID reciclado pelo sistema)
      // nao deve bloquear o boot para sempre.
      if (vivo) {
        const idade = Date.now() - fs.statSync(LOCK_FILE).mtimeMs;
        if (idade < LOCK_MAX_IDADE_MS) {
          console.error(`⚠️ Outra instância do bot já está rodando (PID ${pid}). Encerrando para evitar respostas duplicadas.`);
          return false;
        }
        console.error(`⚠️ Lock obsoleto do PID ${pid} (${Math.round(idade / 1000)}s). Assumindo o controle.`);
      }
    }
  } catch {}
  try {
    fs.writeFileSync(LOCK_FILE, String(process.pid));
    return true;
  } catch (error) {
    console.error(`⚠️ Não foi possível criar o lock file (${error?.message || error}). Continuando mesmo assim.`);
    return true;
  }
}
if (!tentarObterLock()) {
  process.exit(0);
}
process.on('exit', () => {
  try { fs.unlinkSync(LOCK_FILE); } catch {}
});
process.on('SIGINT', () => {
  try { fs.unlinkSync(LOCK_FILE); } catch {}
  process.exit(0);
});
process.on('SIGTERM', () => {
  try { fs.unlinkSync(LOCK_FILE); } catch {}
  process.exit(0);
});
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  Client,
  Collection,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  ModalBuilder,
  Partials,
  MessageFlags,
  Options,
  PermissionFlagsBits,
  TextInputBuilder,
  TextInputStyle,
} = require('discord.js');
const rates = require('./config/rates');
const {
  robuxToReais,
  reaisToRobux,
  gamepassPrice,
  formatBRL,
  formatRobux,
} = require('./utils/robuxConverter');

const PREFIX = process.env.PREFIX || '!';

if (!process.env.DISCORD_TOKEN) {
  console.error('❌ DISCORD_TOKEN não definido. Crie um arquivo .env baseado no .env.example.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    // GatewayIntentBits.GuildMembers removido de propósito: baixaria TODOS os
    // membros de todos os servidores para a RAM sem necessidade. Sem ele, o
    // cache só guarda o que for buscado pontualmente (fetch individual;
    // memberCount continua disponível via metadata do guild).
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
  // Necessário para receber mensagens e interações em DM (canal parcial)
  partials: [Partials.Channel],
  // Teto para os caches internos: sem isso o discord.js guarda tudo que passa
  // (mensagens, membros, reações) e o RSS cresce sem limite com o uso.
  makeCache: Options.cacheWithLimits({
    ...Options.DefaultMakeCacheSettings,
    MessageManager: 25,
    PresenceManager: 0,
    GuildMemberManager: { maxSize: 50, keepOverLimit: (m) => m.id === client.user?.id },
    GuildBanManager: 0,
    GuildInviteManager: 0,
    ReactionManager: 0,
    ReactionUserManager: 0,
    StageInstanceManager: 0,
    VoiceStateManager: 0,
  }),
  // Sweepers: limpa automaticamente do cache mensagens e reações antigas,
  // impedindo que a RAM cresça sem limite com o uso.
  sweepers: {
    messages: { interval: 300, filter: () => (msg) => !msg.pinned && Date.now() - msg.createdTimestamp > 3600_000 },
    reactions: { interval: 600, filter: () => () => true },
    presence: { interval: 600, filter: () => () => true },
  },
});

// O bot registra um listener de interactionCreate por feature (painéis, lock/unlock,
// mensagem, perm, etc.) — mais do que o limite padrão de 10 do Node》。
// Aumenta o limite para evitar o MaxListenersExceededWarning no boot。
client.setMaxListeners(25);

// Slash commands (/)
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

// Comandos de prefixo (!)
client.prefixCommands = new Collection();
const prefixPath = path.join(__dirname, 'prefixCommands');
for (const file of fs.readdirSync(prefixPath).filter((f) => f.endsWith('.js'))) {
  const command = require(path.join(prefixPath, file));
  client.prefixCommands.set(command.name, command);
  for (const alias of command.aliases || []) {
    client.prefixCommands.set(alias, command);
  }
}

// Status do bot com a taxa atual (atualiza sozinho quando muda via !settaxa/!configtaxa)
function atualizarStatus() {
  client.user.setActivity(
    `☁️ Conversor de valores & estoque • criado por Finix.Yin • use !ajuda`,
    { type: 3 } // 3 = Watching
  );
}

client.once(Events.ClientReady, () => {
  atualizarStatus();
  console.log(`✅ Bot online como ${client.user.username}`);

  // Sincroniza os slash commands (/) com o código atual sempre que o bot
  // sobe. A Discloud inicia via MAIN=src/index.js (nao via npm start), e o
  // deploy-commands.js sozinho nunca rodaria no boot. Aqui usamos o id da
  // propria aplicacao (client.application.id), obtido do login — sem depender
  // de CLIENT_ID manual no .env — e em segundo plano, sem travar o ready.

  (async () => {
    try {
      const fsDeploy = require('node:fs');
      const pathDeploy = require('node:path');
      const { REST, Routes } = require('discord.js');
      const clientId = client.application?.id || process.env.CLIENT_ID;
      if (!process.env.DISCORD_TOKEN || !clientId) return;
      const PUBLICOS = require('./config/comandosPublicos');
      const commands = [];
      const commandsPath = pathDeploy.join(__dirname, 'commands');
      for (const file of fsDeploy.readdirSync(commandsPath).filter((f) => f.endsWith('.js'))) {
        const cmd = require(pathDeploy.join(commandsPath, file)).data.toJSON();
        cmd.integration_types = PUBLICOS.has(cmd.name) ? [0, 1] : [0];
        cmd.contexts = [0, 1, 2];
        commands.push(cmd);
      }
      await new REST().setToken(process.env.DISCORD_TOKEN)
        .put(Routes.applicationCommands(clientId), { body: commands });
      console.log(`✅ ${commands.length} comandos (/) sincronizados automaticamente no boot.`);
    } catch (error) {
      console.error('⚠️ Falha ao sincronizar comandos (/) no boot:', error?.message || error);
    }
  })();
});

// Evita que o bot morra por erros não tratados (ex: interação expirada após restart)
// Também grava em arquivo para diagnóstico na Discloud (o console não persiste);
// nome: data/logs/erros.log (gitignored, não vai no ZIP de upload).
const pathLogErros = path.join(__dirname, '..', 'data', 'logs', 'erros.log');
function logErroRotulo(motivo, erro) {
  try {
    const fsLog = require('node:fs');
    fsLog.mkdirSync(path.dirname(pathLogErros), { recursive: true });
    fsLog.appendFileSync(
      pathLogErros,
      `[${new Date().toISOString()}] ${motivo}: ${(erro && (erro.stack || erro.message)) || 'sem detalhe'}\n`
    );
  } catch {}
}
process.on('unhandledRejection', (error) => {
  console.error('[Erro não tratado]', error?.code || error?.message || error);
  logErroRotulo('unhandledRejection', error);
});
process.on('uncaughtException', (error) => {
  console.error('[Exceção não capturada]', error?.code || error?.message || error);
  logErroRotulo('uncaughtException', error);
});
client.on('error', (error) => {
  console.error('[Erro do client]', error?.message || error);
  logErroRotulo('client', error);
});

// Responde slash commands
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  try {
    const command = client.commands.get(interaction.commandName);

    if (!command) {
      // Comandos personalizados agora sao prefixo (!) e nao slash (/). Se o
      // slash foi registrado mas o handler nao existe nesta instancia (zip
      // desatualizado), respondemos aviso em vez de deixar a interacao sem
      // resposta ("aplicativo nao respondeu" / "fica carregando").
      return interaction.reply({
        content: '❌ Este comando não está disponível nesta versão do bot. Atualize o ZIP no host e rode `node deploy-commands.js`.',
        flags: MessageFlags.Ephemeral,
      }).catch(() => {});
    }

    // Restrição de canal (mesma regra dos prefix): admins/cargos passam, usuário
    // comum limitado aos canais configurados via /canalcomando.
    if (interaction.guild && interaction.channel) {
      const { podeUsarNoCanal } = require('./utils/permissions');
      const canaisCheck = podeUsarNoCanal(
        interaction.channelId,
        interaction.guildId,
        interaction.member,
        interaction.user.id,
        command.data.name
      );
      if (!canaisCheck.ok) {
        return interaction.reply({ content: canaisCheck.msg, flags: MessageFlags.Ephemeral });
      }
    }

    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    try {
      const mensagem = { content: '❌ Ocorreu um erro ao executar este comando.', flags: MessageFlags.Ephemeral };
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(mensagem).catch(() => {});
      } else {
        await interaction.reply(mensagem);
      }
    } catch {}
  }
});

// ----- Painel de conversão: botões abrem modais, respostas sempre privadas -----

const MODAIS = {
  robux: { titulo: 'Robux para Reais', label: 'Quantidade de Robux', placeholder: '500' },
  reais: { titulo: 'Reais para Robux', label: 'Valor em reais (R$)', placeholder: '10,00' },
  gamepass: { titulo: 'Calcular Game Pass', label: 'Robux que deseja receber', placeholder: '1000' },
};

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('panel:')) {
      const acao = interaction.customId.split(':')[1];

    if (acao === 'taxas') {
      const taxa = Math.round(rates.GAMEPASS_FEE * 100);
      const embed = new EmbedBuilder()
        .setColor(0xbeb6ff)
        .setTitle('Taxas atuais')
        .addFields(
          {
            name: '100 a 999 Robux',
            value: `**${formatBRL(rates.TIER1_PRICE_PER_100)}** a cada 100 Robux`,
          },
          {
            name: '1.000 Robux ou mais',
            value: `**${formatBRL(rates.TIER2_PRICE_PER_1000)}** a cada 1.000 Robux`,
          },
          { name: 'Game Pass', value: `Roblox desconta **${taxa}%** (você recebe ${100 - taxa}%)` }
        );
      return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }

    const config = MODAIS[acao];
    if (!config) return;

    const modal = new ModalBuilder()
      .setCustomId(`modal:${acao}`)
      .setTitle(config.titulo)
      .addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId('valor')
            .setLabel(config.label)
            .setPlaceholder(config.placeholder)
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );

    return interaction.showModal(modal);
  }

  // ---- Botão do !proof: abre o modal de preenchimento ----
  if (interaction.isButton() && interaction.customId === 'proofiniciar') {
    if (!interaction.guild || !comandoPode(interaction.member, interaction.user.id, 'comprar')) {
      return interaction.reply({ content: '🔒 Somente administradores ou equipe autorizada.', flags: MessageFlags.Ephemeral });
    }

    const rascunho = proofStore.obterRascunho(interaction.guildId, interaction.user.id);
    if (!rascunho?.urls?.length) {
      return interaction.reply({
        content: '❌ Suas imagens expiraram. Envie `!proof` novamente anexando as imagens.',
        flags: MessageFlags.Ephemeral,
      });
    }

    return interaction.showModal(buildProofModal(interaction.guildId));
  }

  // ---- Modal do /proof (admin): coleta numero/produto/valor, depois apresenta
// o painel com os seletores de cliente (@com busca) e canal ----
  if (interaction.isModalSubmit() && interaction.customId === 'proofmodal') {
    const respostaPrivada = (payload) => interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });

    if (!interaction.guild || !comandoPode(interaction.member, interaction.user.id, 'comprar')) {
      return respostaPrivada({ content: '🔒 Somente administradores ou equipe autorizada.' });
    }
    const guildId = interaction.guildId;

    const rascunho = proofStore.obterRascunho(interaction.guildId, interaction.user.id);
    const urls = rascunho?.urls || [];
    if (!urls.length) {
      return respostaPrivada({ content: '❌ Suas imagens expiraram. Anexe novamente no `/proof`.', });
    }

    const numeroRaw = (interaction.fields.getTextInputValue('numero') || '').trim();
    const numero = parseInt(numeroRaw.replace(/\D/g, ''), 10);
    if (isNaN(numero) || numero < 0) {
      return respostaPrivada({ content: '❌ Número do proof inválido. Digite só o número, ex: `26`.', });
    }
    const produto = (interaction.fields.getTextInputValue('produto') || '').trim();
    const valor = (interaction.fields.getTextInputValue('valor') || '').trim();

    // Canal padrão já entra escolhido (o usuário pode trocar no select)
    const dados = salvarFluxo(interaction.guildId, interaction.user.id, {
      urls,
      nomes: rascunho.nomes || [],
      numero,
      produto,
      valor,
      clienteId: null,
      canalId: proofStore.obter(guildId),
    });

    const painel = buildProofFormulario(interaction.user.id, interaction.guild, dados);
    return interaction.reply(painel);
  }

  // ---- Seletores do painel de proof ----
  const handlerProofSel = async (interaction) => {
    const autorizado = interaction.guild && comandoPode(interaction.member, interaction.user.id, 'comprar');
    if (!autorizado) return interaction.reply({ content: '🔒 Somente administradores ou equipe autorizada.', flags: MessageFlags.Ephemeral });

    const dados = obterFluxo(interaction.guildId, interaction.user.id);
    if (!dados) {
      return interaction.reply({ content: '❌ Sessão expirada. Envie `/proof` ou `!proof` novamente com as imagens.', flags: MessageFlags.Ephemeral });
    }

    if (interaction.isChannelSelectMenu() && interaction.customId === 'proofsel:canal') {
      dados.canalId = interaction.values[0] || null;
    } else if (interaction.isUserSelectMenu() && interaction.customId === 'proofsel:cliente') {
      dados.clienteId = interaction.values[0] || null;
      dados.clienteNome = null; // selecionado por @ — limpa nome externo
    } else if (interaction.isStringSelectMenu() && interaction.customId === 'proofsel:produto') {
      // Busca apenas o nome do produto no estoque (não altera quantidade/estoque)
      const prodId = interaction.values[0] || null;
      if (prodId) {
        for (const cat of estoqueCompras.categorias(interaction.guildId)) {
          const p = (cat.produtos || []).find((x) => x.id === prodId);
          if (p) { dados.produto = p.nome; break; }
        }
      } else {
        dados.produto = null;
      }
    }

    const painel = buildProofFormulario(interaction.user.id, interaction.guild, dados);
    if (interaction.isChannelSelectMenu() || interaction.isUserSelectMenu() || interaction.isStringSelectMenu()) {
      return interaction.update(painel);
    }
    return interaction.reply(painel);
  };

  if (interaction.isChannelSelectMenu() && interaction.customId === 'proofsel:canal') return handlerProofSel(interaction);
  if (interaction.isUserSelectMenu() && interaction.customId === 'proofsel:cliente') return handlerProofSel(interaction);
  if (interaction.isStringSelectMenu() && interaction.customId === 'proofsel:produto') return handlerProofSel(interaction);

  // ---- Botão "Fora do Discord": pede o nome do cliente/plataforma ----
  if (interaction.isButton() && interaction.customId === 'proofsel:plataforma') {
    const dados = obterFluxo(interaction.guildId, interaction.user.id);
    if (!dados) {
      return interaction.reply({ content: '❌ Sessão expirada. Envie `/proof` ou `!proof` novamente com as imagens.', flags: MessageFlags.Ephemeral });
    }
    return interaction.showModal(modalClientePlataforma(dados.clienteNome || ''));
  }

  // ---- Submit do modal "Fora do Discord": grava o nome do cliente externo ----
  if (interaction.isModalSubmit() && interaction.customId === 'proofsel:plataformamodal') {
    const respostaPrivada = (payload) => interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
    if (!interaction.guild || !comandoPode(interaction.member, interaction.user.id, 'comprar')) {
      return respostaPrivada({ content: '🔒 Somente administradores ou equipe autorizada.' });
    }
    const dados = obterFluxo(interaction.guildId, interaction.user.id);
    if (!dados) {
      return respostaPrivada({ content: '❌ Sessão expirada. Envie `/proof` ou `!proof` novamente com as imagens.' });
    }
    dados.clienteNome = (interaction.fields.getTextInputValue('clienteNome') || '').trim().slice(0, 80);
    dados.clienteId = null; // nome externo substitui a menção do Discord
    return interaction.update(buildProofFormulario(interaction.user.id, interaction.guild, dados));
  }

  // ---- Botão confirmar: posta o proof no canal escolhido ----
  if (interaction.isButton() && interaction.customId === 'proofsel:confirmar') {
    // Responde a interação imediatamente (15min de margem) para o envio dos
    // anexos não estourar os 3s do botão. A mensagem efêmera original é
    // atualizada depois via editReply.
    if (typeof interaction.deferUpdate === 'function') {
      await interaction.deferUpdate().catch(() => {});
    }

    const respostaPrivada = async (payload) => {
      if (typeof interaction.editReply === 'function') {
        await interaction.editReply({ ...payload, components: [] }).catch(() => {});
      } else if (typeof interaction.update === 'function') {
        await interaction.update({ ...payload, components: [] }).catch(() => {});
      }
    };

    if (!interaction.guild || !comandoPode(interaction.member, interaction.user.id, 'comprar')) {
      return respostaPrivada({ content: '🔒 Somente administradores ou equipe autorizada.' });
    }
    const dados = obterFluxo(interaction.guildId, interaction.user.id);
    if (!dados) {
      return respostaPrivada({ content: '❌ Sessão expirada. Envie `/proof` ou `!proof` novamente com as imagens.', });
    }

    let canalAlvo = null;
    if (dados.canalId) {
      canalAlvo = interaction.guild.channels.cache.get(dados.canalId) ||
        (await interaction.guild.channels.fetch(dados.canalId).catch(() => null));
    }
    const canalConfig = proofStore.obter(interaction.guildId);
    if (!canalAlvo && canalConfig) {
      canalAlvo = interaction.guild.channels.cache.get(canalConfig) ||
        (await interaction.guild.channels.fetch(canalConfig).catch(() => null));
    }

    if (!canalAlvo || !canalAlvo.isTextBased()) {
      return respostaPrivada({
        content: '❌ Canal de destinos inválido. Selecione um canal no menu acima e tente de novo.',
      });
    }

    // ----- Monta o texto -----
    const linhas = [];
    if (dados.produto) linhas.push(`📦 Produto: ${dados.produto}`);
    if (dados.valor) {
      const v = dados.valor.toLowerCase().startsWith('r$') ? dados.valor : `R$ ${dados.valor}`;
      linhas.push(`💰 Valor: ${v}`);
    }
    if (dados.clienteNome) {
      linhas.push(`👤 Cliente: ${dados.clienteNome}`);
    } else if (dados.clienteId) {
      linhas.push(`👤 Cliente: <@${dados.clienteId}>`);
      linhas.push(`🆔 ID: \`${dados.clienteId}\``);
    }
    const content = `# PROOF #${dados.numero}${linhas.length ? '\n\n' + linhas.join('\n') : ''}`;

    // ----- Posta no canal (re-envia os arquivos anexados no /proof) -----
    const files = dados.urls.map((url, i) => ({ attachment: url, name: `proof-${dados.numero}-${i + 1}.png` }));
    let postado = true;
    try {
      await canalAlvo.send({ content, files, allowedMentions: { parse: [] } });
    } catch (e) {
      postado = false;
      console.error('[ProofModal] Erro ao postar:', e?.message || e);
      limparFluxo(interaction.guildId, interaction.user.id);
      proofStore.limparRascunho(interaction.guildId, interaction.user.id);
      return respostaPrivada({ content: '❌ Erro ao postar o proof: ' + (e?.message || 'erro desconhecido'), });
    }

    limparFluxo(interaction.guildId, interaction.user.id);
    proofStore.limparRascunho(interaction.guildId, interaction.user.id);

    if (postado) {
      return respostaPrivada({
        content: `✅ Proof **#${dados.numero}** postado em ${canalAlvo} com **${files.length} imagem(ns)**.`,
      });
    }
  }

  // ---- Botão cancelar do painel de proof ----
  if (interaction.isButton() && interaction.customId === 'proofsel:cancelar') {
    limparFluxo(interaction.guildId, interaction.user.id);
    proofStore.limparRascunho(interaction.guildId, interaction.user.id);
    return interaction.update({ content: '❌ Proof cancelado.', embeds: [], components: [] });
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith('modal:')) {
    const acao = interaction.customId.split(':')[1];
    const bruto = interaction.fields.getTextInputValue('valor').trim();
    const numero = parseFloat(bruto.replace(/\./g, '').replace(',', '.'));
    const respostaPrivada = (payload) => interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });

    if (isNaN(numero) || numero <= 0) {
      return respostaPrivada({ content: '❌ Valor inválido. Tente novamente com um número, ex: `500` ou `10,50`.' });
    }

    if (acao === 'robux') {
      const robux = Math.floor(numero);
      if (robux < rates.MIN_ROBUX) {
        return respostaPrivada({ content: `❌ O valor mínimo é **${formatRobux(rates.MIN_ROBUX)} Robux**.` });
      }
      const embed = new EmbedBuilder()
        .setColor(0xbeb6ff)
        .setTitle('Conversão de Robux')
        .setDescription(`**${formatRobux(robux)} Robux**\n= **${formatBRL(robuxToReais(robux))}**`);
      return respostaPrivada({ embeds: [embed] });
    }

    if (acao === 'reais') {
      if (numero < rates.TIER1_PRICE_PER_100) {
        return respostaPrivada({ content: `❌ O valor mínimo é **${formatBRL(rates.TIER1_PRICE_PER_100)}**.` });
      }
      const embed = new EmbedBuilder()
        .setColor(0xbeb6ff)
        .setTitle('Conversão de Reais')
        .setDescription(`**${formatBRL(numero)}**\n= **${formatRobux(reaisToRobux(numero))} Robux**`);
      return respostaPrivada({ embeds: [embed] });
    }

    if (acao === 'gamepass') {
      const robux = Math.floor(numero);
      const embed = new EmbedBuilder()
        .setColor(0xbeb6ff)
        .setTitle('Cálculo de Game Pass')
        .setDescription(
          `Para receber **${formatRobux(robux)} Robux**, crie o Game Pass por\n**${formatRobux(gamepassPrice(robux))} Robux**`
        )
        .setFooter({ text: 'O Roblox desconta 30% • você recebe 70%' });
      return respostaPrivada({ embeds: [embed] });
    }
    }
  } catch (error) {
    console.error('[Painel de conversão] Erro na interação:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Painel de configuração de taxas (somente admin, sempre privado) -----

const { buildConfigPanel } = require('./utils/configPanel');
const { publishOrUpdatePanel, refreshSavedPanel } = require('./utils/panelStore');
const { isAdmin } = require('./prefixCommands/settaxa');

const MODAIS_CFG = {
  tier1: {
    titulo: 'Alterar Faixa 1',
    label: 'R$ a cada 100 Robux (ex: 3,50)',
    placeholder: '3,50',
    chave: 'TIER1_PRICE_PER_100',
    resumo: (v) => `Faixa 1 (100 a 999 Robux) → **${formatBRL(v)}** a cada 100 Robux`,
  },
  tier2: {
    titulo: 'Alterar Faixa 2',
    label: 'R$ a cada 1.000 Robux (ex: 34,99)',
    placeholder: '34,99',
    chave: 'TIER2_PRICE_PER_1000',
    resumo: (v) => `Faixa 2 (1.000+ Robux) → **${formatBRL(v)}** a cada 1.000 Robux`,
  },
  gamepass: {
    titulo: 'Alterar Game Pass',
    label: 'Desconto do Roblox em % (ex: 30)',
    placeholder: '30',
    chave: 'GAMEPASS_FEE',
    porcentagem: true,
    resumo: (v) => `Game Pass → **${Math.round(v * 100)}%** de desconto`,
  },
};

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('cfg:')) {
      const acao = interaction.customId.split(':')[1];

      if (!permitido(interaction)) {
        return interaction.reply({
          content: '🔒 Somente administradores podem configurar as taxas.',
          flags: MessageFlags.Ephemeral,
        });
      }

      if (acao === 'refresh') {
        return await interaction.update(buildConfigPanel());
      }

      if (acao === 'close') {
        return await interaction.update({ content: '✅ Painel de configuração fechado.', embeds: [], components: [] });
      }

      const config = MODAIS_CFG[acao];
      if (!config) return;

      const modal = new ModalBuilder()
        .setCustomId(`cfgmodal:${acao}`)
        .setTitle(config.titulo)
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('valor')
              .setLabel(config.label)
              .setPlaceholder(config.placeholder)
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
          )
        );

      return await interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('cfgmodal:')) {
      const acao = interaction.customId.split(':')[1];
      const config = MODAIS_CFG[acao];
      if (!config) return;

      if (!permitido(interaction)) {
        return interaction.reply({
          content: '🔒 Somente administradores podem configurar as taxas.',
          flags: MessageFlags.Ephemeral,
        });
      }

      const bruto = interaction.fields.getTextInputValue('valor').trim();
      let numero = parseFloat(bruto.replace(/\./g, '').replace(',', '.'));

      if (isNaN(numero) || numero <= 0) {
        return interaction.reply({
          content: '❌ Valor inválido. Tente novamente com um número, ex: `3,50` ou `30`.',
          flags: MessageFlags.Ephemeral,
        });
      }

      if (config.porcentagem) {
        if (numero >= 100) {
          return interaction.reply({ content: '❌ A porcentagem deve ser menor que 100.', flags: MessageFlags.Ephemeral });
        }
        numero = numero / 100;
      }

      rates.setOverride(config.chave, numero);
      atualizarStatus();
      await refreshSavedPanel(client);

      // Atualiza o proprio painel de taxas com os novos valores
      return interaction.update(buildConfigPanel());
    }
  } catch (error) {
    console.error('[Painel de taxas] Erro na interação:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Menu de ajuda: botões de navegação -----

const { buildAjuda } = require('./utils/ajudaPanel');

client.on('interactionCreate', async (interaction) => {
  try {
    // ----- Menu de ajuda: botões de navegação -----
    if (interaction.isButton() && interaction.customId.startsWith('ajuda:')) {
      const partes = interaction.customId.split(':');
      // formatos: ajuda:cat:<pagina> | ajuda:nav:prev:<pagina> | ajuda:nav:home:<pagina>
      const pagina = partes.length >= 3 ? partes[partes.length - 1] : partes[1];
      const admin = interaction.guild ? permitido(interaction) : false;
      const pag = (pagina === 'admin' || pagina === 'painel' || pagina === 'personalizados') && !admin ? 'inicio' : pagina;
      return interaction.update(buildAjuda(pag, admin, interaction.guildId || null));
    }
  } catch (error) {
    console.error('[Ajuda] Erro na interação:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Estoque: navegação pública e painel admin -----

const estoqueDb = require('./utils/estoque');
const estoquePanel = require('./utils/estoquePanel');
const { publicarOuAtualizar, refreshPainelEstoque } = require('./utils/estoquePanelStore');
const { montarConfirmacao } = require('./utils/confirm');
const painelCategoria = require('./prefixCommands/painelcategoria');
const painelCenter = require('./utils/painelCenter');
const { buildPainelCentral } = painelCenter;
const { avisar } = require('./utils/avisos');

client.on('interactionCreate', async (interaction) => {
  try {
    // ----- painel fixo de estoque: estfixo:* (botões e menus de seleção) -----
    // Clique no PAINEL PUBLICO -> responde ephemeral (so quem clicou ve)
    // Clique DENTRO da resposta ephemeral -> EDITA a mesma mensagem
    if ((interaction.isButton() || interaction.isStringSelectMenu()) && interaction.customId.startsWith('estfixo:')) {
      const partes = interaction.customId.split(':');
      const acao = partes[1];
      const dentroDeEphemeral = Boolean(interaction.message?.flags?.has?.('Ephemeral'));

      // Select de categoria: abre os produtos da categoria escolhida
      if (acao === 'selcat') {
        const catId = (interaction.values || [])[0] || null;
        if (!catId) return;
        const payload = estoquePanel.publicoProdutos(interaction.guildId, catId);
        if (dentroDeEphemeral) return interaction.update(payload);
        return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }

      // Navegação entre páginas de categoria (lista de categorias)
      if (acao === 'prevcat' || acao === 'nextcat') {
        const payload = estoquePanel.publicoCategorias(interaction.guildId, parseInt(partes[2] || '0', 10));
        if (dentroDeEphemeral) return interaction.update(payload);
        return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }

      // Navegação entre páginas de produtos dentro da categoria
      if (acao === 'pprev' || acao === 'pnext') {
        const catId = partes[2];
        const payload = estoquePanel.publicoProdutos(interaction.guildId, catId, parseInt(partes[3] || '0', 10));
        if (dentroDeEphemeral) return interaction.update(payload);
        return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
      }

      const [, , catId] = partes;
      const payload =
        acao === 'voltar'
          ? estoquePanel.publicoCategorias(interaction.guildId)
          : acao === 'cat' || acao === 'prev' || acao === 'next'
            ? estoquePanel.publicoProdutos(interaction.guildId, catId)
            : null;
      if (!payload) return;

      if (dentroDeEphemeral) {
        return interaction.update(payload); // edita a mesma mensagem privada
      }
      return interaction.reply({ ...payload, flags: MessageFlags.Ephemeral }); // primeira resposta privada
    }

    // ----- gerenciamento central de paineis (!painel / /painel) -----
    // Botões do seletor de canal (painelcenter:selcanal:*:atual/cancelar)
    // são tratados no handler específico logo abaixo — não entram aqui
    // (entrar aqui causava "Ação desconhecida" ao publicar).
    const ehSeletorCanal = interaction.customId?.startsWith('painelcenter:selcanal:');
    if (interaction.isButton() && interaction.customId.startsWith('painelcenter:') && !ehSeletorCanal) {
      if (!interaction.guild || !permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const alvo = interaction.customId.split(':')[1];

      if (alvo === 'conversao' || alvo === 'estoque') {
        // Escolha de canal antes de publicar (sistema comum de seleção de canal).
        const selId = `painelcenter:selcanal:${alvo}`;
        const canais = linhaSelecaoCanalDe(interaction.guild, selId, interaction.channel.id, `📣 Onde publicar o painel de ${alvo}?`);
        if (!canais.canais.length) {
          return interaction.reply({ content: '❌ Não encontrei nenhum canal de texto em que eu possa publicar.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update({
          content: `🗂️ **Onde deseja publicar o painel de ${alvo === 'conversao' ? 'conversão' : 'estoque'}?**\n_Selecione um canal ou use **📌 Canal atual**._`,
          embeds: [],
          components: [canais.row, canais.botoes],
        });
      }

      if (alvo === 'criarcategoria') {
        const selecao = painelCategoria.construirPainelSelecao(interaction.guildId);
        await interaction.update({ embeds: selecao.embeds, components: selecao.components });
        return;
      }

      if (alvo === 'cat') {
        const catId = interaction.customId.split(':')[2];
        const embed = painelCategoria.buildCategoria(interaction.guildId, catId);
        if (!embed) {
          return interaction.reply({ content: `❌ Categoria **${catId}** não encontrada.`, flags: MessageFlags.Ephemeral });
        }
        // O envio no canal pode demorar >3s; responde imediatamente e edita depois.
        await interaction.deferUpdate().catch(() => {});
        const msg = await interaction.channel.send({ embeds: [embed] });
        painelCategoria.salvar(msg.id, catId, interaction.channel.id, interaction.guildId);
        await interaction.editReply(buildPainelCentral(interaction.guildId)).catch(() => {});
        return interaction.followUp({
          content: `✅ Painel da categoria **${catId}** publicado no canal atual.`,
          flags: MessageFlags.Ephemeral,
        });
      }

      // ----- remover painel fixo (com confirmação) -----
      if (alvo === 'remconversao' || alvo === 'remestoque') {
        const nome = alvo === 'remconversao' ? 'de conversão' : 'de estoque';
        return interaction.update(
          montarConfirmacao(
            `🗑️ **Remover o painel fixo ${nome}?**\n\n_A mensagem fixada será apagada e o registro removido._`,
            `painelcenter:${alvo}-confirm`,
            'painelcenter:remcancel'
          )
        );
      }
      if (alvo === 'remcancel') {
        return interaction.update(buildPainelCentral(interaction.guildId));
      }
      if (alvo === 'remconversao-confirm' || alvo === 'remestoque-confirm') {
        // Buscar/apagar a mensagem antiga pode demorar >3s; responde já.
        await interaction.deferUpdate().catch(() => {});
        const ref = alvo.startsWith('remconversao') ? painelCenter.readConversao(interaction.guildId) : painelCenter.readEstoque(interaction.guildId);
        if (ref) {
          try {
            const canal = await client.channels.fetch(ref.channelId);
            const msg = await canal.messages.fetch(ref.messageId);
            await msg.delete().catch(() => {});
          } catch {}
        }
        if (alvo.startsWith('remconversao')) painelCenter.salvarConversao(interaction.guildId, null);
        else painelCenter.salvarEstoque(interaction.guildId, null);
        await interaction.editReply(buildPainelCentral(interaction.guildId)).catch(() => {});
        return interaction.followUp({
          content: `✅ Painel fixo ${alvo.startsWith('remconversao') ? 'de conversão' : 'de estoque'} removido.`,
          flags: MessageFlags.Ephemeral,
        });
      }
      if (alvo === 'remcategoria') {
        const [, , msgId, catId] = interaction.customId.split(':');
        return interaction.update(
          montarConfirmacao(
            `🗑️ **Remover o painel fixo da categoria **${catId}**?**\n\n_A mensagem fixada será apagada e o registro removido._`,
            `painelcenter:remcategoria-confirm:${msgId}:${catId}`,
            'painelcenter:remcancel'
          )
        );
      }
      if (alvo === 'remcategoria-confirm') {
        const [, , msgId, catId] = interaction.customId.split(':');
        // Buscar/apagar a mensagem antiga pode demorar >3s; responde já.
        await interaction.deferUpdate().catch(() => {});
        const cats = painelCenter.readCategorias(interaction.guildId);
        const info = cats[msgId];
        if (info && typeof info === 'object' && info.canal) {
          try {
            const canal = await client.channels.fetch(info.canal || info.channelId);
            const msg = await canal.messages.fetch(msgId);
            await msg.delete().catch(() => {});
          } catch {}
        }
        delete cats[msgId];
        painelCenter.salvarCategoria(interaction.guildId, msgId, null, null);
        await interaction.editReply(buildPainelCentral(interaction.guildId)).catch(() => {});
        return interaction.followUp({
          content: `✅ Painel fixo da categoria **${catId}** removido.`,
          flags: MessageFlags.Ephemeral,
        });
      }

      return interaction.reply({ content: '❌ Ação desconhecida.', flags: MessageFlags.Ephemeral });
    }

    // ----- escolha de canal do gerenciador central de paineis -----
    if ((interaction.isStringSelectMenu() || interaction.isButton()) && interaction.customId.startsWith('painelcenter:selcanal:')) {
      if (!interaction.guild || !permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const partes = interaction.customId.split(':');
      const tipo = partes[2];

      if (interaction.isButton() && partes[3] === 'cancelar') {
        return interaction.update(buildPainelCentral(interaction.guildId));
      }

      let canal = null;
      if (interaction.isStringSelectMenu()) {
        canal = interaction.guild?.channels.cache.get(interaction.values[0]) || null;
      } else if (partes[3] === 'atual') {
        canal = interaction.channel;
      }
      if (!canal) {
        return interaction.update(buildPainelCentral(interaction.guildId));
      }

      if (tipo === 'conversao') {
        // Publicar/atualizar no canal pode demorar >3s; responde já e edita depois.
        await interaction.deferUpdate().catch(() => {});
        const { atualizado } = await publishOrUpdatePanel(canal);
        const embedNovo = new EmbedBuilder()
          .setColor(0xbeb6ff)
          .setDescription(atualizado
            ? `✅ Painel de conversão **atualizado** em <#${canal.id}>.`
            : `✅ Painel de conversão **publicado** em <#${canal.id}>! Qualquer pessoa pode usar os botões.`);
        return interaction.editReply({ embeds: [embedNovo], components: [] });
      }

      if (tipo === 'estoque') {
        // Publicar/atualizar no canal pode demorar >3s; responde já e edita depois.
        await interaction.deferUpdate().catch(() => {});
        const { atualizado } = await publicarOuAtualizar(canal);
        const embedNovo = new EmbedBuilder()
          .setColor(0xbeb6ff)
          .setDescription(atualizado
            ? `✅ Painel de estoque **atualizado** em <#${canal.id}>.`
            : `✅ Painel de estoque **publicado** em <#${canal.id}>! Qualquer pessoa pode clicar nas categorias — cada um vê de forma privada.`);
        return interaction.editReply({ embeds: [embedNovo], components: [] });
      }

      return interaction.update({ content: '❌ Tipo desconhecido.', embeds: [], components: [] });
    }

    // ----- fixar painel de categoria (selecao visual do !painelcategoria) -----
    if ((interaction.isButton() || interaction.isStringSelectMenu()) && interaction.customId.startsWith('painelcat:')) {
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const partes = interaction.customId.split(':');
      const catId = partes[1];
      // Seletor de categorias agora também dá acesso ao gerenciamento (editar emoji/descrição/reordenar)

      if (catId === 'pag') {
        return interaction.update(painelCategoria.construirPainelSelecao(parseInt(partes[2])));
      }
      if (catId === 'gercat') {
        return interaction.update(estoquePanel.adminGerenciarCategorias(interaction.guildId));
      }

      // Painel de categoria: ao clicar na categoria, abre o seletor de canal
      // (em vez de publicar direto no canal atual).
      if (partes[2] === 'canal') {
        if (interaction.isButton() && partes[3] === 'cancelar') {
          return interaction.update(painelCategoria.construirPainelSelecao(interaction.guildId));
        }
        // Defer imediato: o envio no canal pode demorar >3s e o interaction expirar.
        await interaction.deferUpdate().catch(() => {});
        const responder = async (payload) => {
          try {
            if (interaction.deferred) return await interaction.editReply(payload);
            return await interaction.update(payload);
          } catch {}
        };

        let canal = null;
        if (!interaction.channel) {
          return responder({ content: '❌ Não consegui identificar o canal.', embeds: [], components: [] });
        }
        if (interaction.isStringSelectMenu()) {
          canal = interaction.guild?.channels.cache.get((interaction.values || [])[0] || '') || null;
        } else if (partes[3] === 'atual') {
          canal = interaction.channel;
        }
        if (!canal || !canal.isTextBased() || !canal.permissionsFor(interaction.guild?.members.me)?.has('SendMessages')) {
          return responder({ content: `❌ Não posso publicar em ${canal ? `<#${canal.id}>` : 'nenhum canal'}. Verifique minha permissão de envio.`, embeds: [], components: [] });
        }

        const embed = painelCategoria.buildCategoria(interaction.guildId, catId);
        if (!embed) {
          return responder({ content: `❌ Categoria \`${catId}\` não encontrada.`, embeds: [], components: [] });
        }
        try {
          const msg = await canal.send({ embeds: [embed] });
          painelCategoria.salvar(msg.id, catId, canal.id, interaction.guildId);
        } catch (sendError) {
          console.error('[PainelCategoria] Falha ao enviar:', sendError?.message || sendError);
          return responder({ content: `❌ Não consegui enviar em <#${canal.id}>. Verifique minha permissão nesse canal.`, embeds: [], components: [] });
        }
        return responder({ content: `✅ Painel da categoria **${catId}** fixado em <#${canal.id}>.`, embeds: [], components: [] });
      }

      if (!interaction.channel) {
        return interaction.reply({ content: '❌ Não consegui identificar o canal.', flags: MessageFlags.Ephemeral });
      }
      const embed = painelCategoria.buildCategoria(interaction.guildId, catId);
      if (!embed) {
        return interaction.reply({ content: '❌ Categoria não encontrada.', flags: MessageFlags.Ephemeral });
      }
      // Agora sempre pergunta em qual canal publicar (seletor visual).
      return interaction.update(painelCategoria.construirSelecaoCanal(interaction.guild, catId, interaction.channel?.id || null));
    }

    // ----- admin: estadm:* (botões e menus de seleção) -----
    if ((interaction.isButton() || interaction.isStringSelectMenu()) && interaction.customId.startsWith('estadm:')) {
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      let partes = interaction.customId.split(':');
      let acao = partes[1];

      // Menus de seleção do admin (categoria/produto): traduz para a ação
      // equivalente que o fluxo já conhece, para não duplicar a lógica.
      //   estadm:selcat:<acao>:<pag>          -> acao espera a categoria em partes[2]
      //   estadm:selprod:<acao>:<catId>:<pag> -> acao espera categoria/produto em partes[2]/[3]
      if (acao === 'selcat' || acao === 'selprod') {
        const escolhido = (interaction.values || [])[0] || null;
        if (!escolhido) {
          return interaction.reply({ content: '❌ Seleção inválida.', flags: MessageFlags.Ephemeral });
        }
        if (acao === 'selcat') {
          acao = partes[2];
          partes = ['estadm', acao, escolhido];
        } else {
          const catId = partes[3];
          if (!catId) {
            return interaction.reply({ content: '❌ Categoria não encontrada.', flags: MessageFlags.Ephemeral });
          }
          acao = partes[2];
          partes = ['estadm', acao, catId, escolhido];
        }
      }

      if (acao === 'menu') return interaction.update(estoquePanel.adminMenu(interaction.guildId));
      if (acao === 'lista') return interaction.update(estoquePanel.adminLista(interaction.guildId));
      if (acao === 'gercatpag') return interaction.update(estoquePanel.adminGerenciarCategorias(interaction.guildId, parseInt(partes[2])));
      // Paginação da escolha de categoria/produto (estadm:catpag:<acao>:<pag> e estadm:prodpag:<acao>:<catId>:<pag>)
      if (acao === 'catpag') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, partes[2], parseInt(partes[3])));
      if (acao === 'prodpag') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, partes[2], partes[3], parseInt(partes[4])));

      if (acao === 'addcat') {
        const modal = new ModalBuilder().setCustomId('estmodal:addcat').setTitle('Nova categoria').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('nome').setLabel('Nome da categoria (ex: MM2)')
              .setStyle(TextInputStyle.Short).setRequired(true)
          )
        );
        return interaction.showModal(modal);
      }

      if (acao === 'addprod') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'addprod2'));
      if (acao === 'addprod2') {
        const catId = partes[2];
        const modal = new ModalBuilder().setCustomId(`estmodal:addprod:${catId}`).setTitle('Novo produto').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('nome').setLabel('Nome do produto').setStyle(TextInputStyle.Short).setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('valor').setLabel('Valor em R$ (ex: 15,00)').setStyle(TextInputStyle.Short).setRequired(true)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('qtd').setLabel('Quantidade (vazio = sem controle)').setStyle(TextInputStyle.Short).setRequired(false)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('descricao').setLabel('Descrição (opcional, ex: entrega imediata)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100)
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('imagem').setLabel('Link da imagem (opcional; com http)').setStyle(TextInputStyle.Short).setRequired(false)
          )
        );
        return interaction.showModal(modal);
      }

      if (acao === 'qtd') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'qtd2'));
      if (acao === 'toggle') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'toggle2'));
      if (acao === 'remover') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'remover2'));

      if (acao === 'qtd2') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, 'qtd3', partes[2]));
      if (acao === 'toggle2') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, 'toggle3', partes[2]));
      if (acao === 'remover2') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, 'remover3', partes[2]));

      if (acao === 'qtd3') {
        const [, , catId, prodId] = partes;
        const modal = new ModalBuilder().setCustomId(`estmodal:qtd:${catId}:${prodId}`).setTitle('Alterar quantidade').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('qtd').setLabel('Nova quantidade').setStyle(TextInputStyle.Short).setRequired(true)
          )
        );
        return interaction.showModal(modal);
      }
      if (acao === 'toggle3') {
        const [, , catId, prodId] = partes;
        const p = estoqueDb.toggleAtivo(interaction.guildId, catId, prodId);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        if (!p) return interaction.reply({ content: '❌ Produto não encontrado.', flags: MessageFlags.Ephemeral });
        const s = estoqueDb.status(p);
        return interaction.update({
          content: `✅ **${p.nome}** agora está: ${s.emoji} ${s.texto}`,
          embeds: [],
          components: [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('estadm:menu').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary)
            ),
          ],
        });
      }
      if (acao === 'remover3') {
        const [, , catId, prodId] = partes;
        const p = estoqueDb.produto(interaction.guildId, catId, prodId);
        if (!p) return interaction.update({ content: '❌ Produto não encontrado.', embeds: [], components: [] });
        return interaction.update(
          montarConfirmacao(
            `🗑️ **Confirmar exclusão do produto**\n\n${p.nome} — ${formatBRL(p.valor)}?\n\n_Os painéis fixos serão atualizados._`,
            `estadm:remover-confirm:${catId}:${p.id}`,
            `estadm:remover-cancel:${catId}:${p.id}`
          )
        );
      }
      if (acao === 'remover-cancel') {
        const [, , catId, prodId] = partes;
        return interaction.update(estoquePanel.adminProdDetalhe(interaction.guildId, catId, prodId));
      }
      if (acao === 'remover-confirm') {
        const [, , catId, prodId] = partes;
        const p = estoqueDb.produto(interaction.guildId, catId, prodId);
        const ok = estoqueDb.removeProduto(interaction.guildId, catId, prodId);
        if (ok) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return interaction.update({
          content: ok ? `🗑️ Produto **${p?.nome || ''}** removido.` : '❌ Produto não encontrado.',
          embeds: [],
          components: [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('estadm:menu').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary)
            ),
          ],
        });
      }

      // ----- remover categoria -----
      if (acao === 'remcat') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'remcat2'));
      if (acao === 'remcat2') {
        const catId = partes[2];
        const cat = estoqueDb.categoria(interaction.guildId, catId);
        if (!cat) return interaction.update({ content: '❌ Categoria não encontrada.', embeds: [], components: [] });
        return interaction.update(
          montarConfirmacao(
            `🗑️ **Confirmar exclusão da categoria**\n\n${cat.nome} (${cat.produtos.length} produto(s))?\n\n_Os painéis fixos serão atualizados._`,
            `estadm:remcat-confirm:${catId}`,
            `estadm:menu`
          )
        );
      }
      if (acao === 'remcat-confirm') {
        const catId = partes[2];
        const cat = estoqueDb.categoria(interaction.guildId, catId);
        const ok = estoqueDb.removeCategoria(interaction.guildId, catId);
        if (ok) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return interaction.update({
          content: ok
            ? `🗑️ Categoria **${cat?.nome || ''}** removida (com ${cat?.produtos?.length || 0} produto(s)).`
            : '❌ Categoria não encontrada.',
          embeds: [],
          components: [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('estadm:menu').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary)
            ),
          ],
        });
      }

      // ----- vender: diminui 1 da quantidade -----
      if (acao === 'vender') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'vender2'));
      if (acao === 'vender2') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, 'vender3', partes[2]));
      if (acao === 'vender3') {
        const [, , catId, prodId] = partes;
        const atual = estoqueDb.produto(interaction.guildId, catId, prodId);

        // Defer imediato para ganhar tempo (evita timeout de 3s)
        await interaction.deferUpdate().catch(() => {});

        const responder = async (payload) => {
          try {
            if (interaction.deferred) {
              return await interaction.editReply(payload);
            }
            return await interaction.update(payload);
          } catch {
            try {
              return await interaction.reply({ ...payload, flags: MessageFlags.Ephemeral });
            } catch {}
          }
        };

        if (!atual) return responder({ content: '❌ Produto não encontrado.', embeds: [], components: [] });
        if (!atual.controlarQtd) return responder({ content: `❌ **${atual.nome}** não tem controle de quantidade.`, embeds: [], components: [] });

        const novaQtd = Math.max(0, atual.quantidade - 1);
        const p = estoqueDb.setQuantidade(interaction.guildId, catId, prodId, novaQtd);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        // Aviso de esgotado em background (nao trava a resposta)
        if (p && p.quantidade === 0) {
          avisar(client, interaction.guildId, `⚠️ **${p.nome}** esgotou no estoque!`).catch(() => {});
        }
        return responder({
          content: `📦 Venda registrada: **${p.nome}** agora tem **${p.quantidade}** em estoque.`,
          embeds: [],
          components: [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('estadm:menu').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary)
            ),
          ],
        });
      }

      // ----- editar nome produto -----
      if (acao === 'nome') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'nome2'));
      if (acao === 'nome2') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, 'nome3', partes[2]));
      if (acao === 'nome3') {
        const [, , catId, prodId] = partes;
        const modal = new ModalBuilder().setCustomId(`estmodal:nome:${catId}:${prodId}`).setTitle('Editar nome do produto').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('nome').setLabel('Novo nome').setStyle(TextInputStyle.Short).setRequired(true)
          )
        );
        return interaction.showModal(modal);
      }

      // ----- renomear categoria -----
      if (acao === 'rencat') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'rencat2'));
      if (acao === 'rencat2') {
        const catId = partes[2];
        const modal = new ModalBuilder().setCustomId(`estmodal:rencat:${catId}`).setTitle('Renomear categoria').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('nome').setLabel('Novo nome da categoria').setStyle(TextInputStyle.Short).setRequired(true)
          )
        );
        return interaction.showModal(modal);
      }

      // ----- gerenciar categorias (emoji, descrição, reordenar) -----
      if (acao === 'gercat') return interaction.update(estoquePanel.adminGerenciarCategorias(interaction.guildId));
      if (acao === 'gercat2') return interaction.update(estoquePanel.adminGerCatDetalhe(interaction.guildId, partes[2]));

      if (acao === 'catemoji') {
        const catId = partes[2];
        const modal = new ModalBuilder().setCustomId(`estmodal:catemoji:${catId}`).setTitle('Emoji da categoria').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('emoji').setLabel('Emoji (ex: 🗡️)').setStyle(TextInputStyle.Short).setRequired(true)
          )
        );
        return interaction.showModal(modal);
      }
      if (acao === 'catdesc') {
        const catId = partes[2];
        const modal = new ModalBuilder().setCustomId(`estmodal:catdesc:${catId}`).setTitle('Descrição da categoria').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('descricao').setLabel('Descrição (máx. 100 caracteres)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100)
          )
        );
        return interaction.showModal(modal);
      }
      if (acao === 'catsubir') {
        const catId = partes[2];
        estoqueDb.moverCategoria(interaction.guildId, catId, -1);
        painelCategoria.refresh(client).catch(() => {});
        return interaction.update(estoquePanel.adminGerCatDetalhe(interaction.guildId, catId));
      }
      if (acao === 'catdescer') {
        const catId = partes[2];
        estoqueDb.moverCategoria(interaction.guildId, catId, 1);
        painelCategoria.refresh(client).catch(() => {});
        return interaction.update(estoquePanel.adminGerCatDetalhe(interaction.guildId, catId));
      }

      // ----- info do produto (descrição, imagem, preço) -----
      if (acao === 'prodinfo') return interaction.update(estoquePanel.adminEscolherCategoria(interaction.guildId, 'prodinfo2'));
      if (acao === 'prodinfo2') return interaction.update(estoquePanel.adminEscolherProduto(interaction.guildId, 'prodinfo3', partes[2]));
      if (acao === 'prodinfo3') {
        const [, , catId, prodId] = partes;
        return interaction.update(estoquePanel.adminProdDetalhe(interaction.guildId, catId, prodId));
      }

      if (acao === 'proddtl-desc') {
        const [, , catId, prodId] = partes;
        const modal = new ModalBuilder().setCustomId(`estmodal:proddtl-desc:${catId}:${prodId}`).setTitle('Descrição do produto').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('descricao').setLabel('Descrição (deixe vazio para remover)').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(100)
          )
        );
        return interaction.showModal(modal);
      }
      if (acao === 'proddtl-img') {
        const [, , catId, prodId] = partes;
        const modal = new ModalBuilder().setCustomId(`estmodal:proddtl-img:${catId}:${prodId}`).setTitle('Imagem do produto').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('imagem').setLabel('Link da imagem (vazio = remove)').setStyle(TextInputStyle.Short).setRequired(false)
          )
        );
        return interaction.showModal(modal);
      }
      if (acao === 'proddtl-valor') {
        const [, , catId, prodId] = partes;
        const modal = new ModalBuilder().setCustomId(`estmodal:proddtl-valor:${catId}:${prodId}`).setTitle('Preço do produto').addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('valor').setLabel('Valor em R$ (ex: 15,00)').setStyle(TextInputStyle.Short).setRequired(true)
          )
        );
        return interaction.showModal(modal);
      }
      return;
    }

    // ----- modais do estoque -----
    if (interaction.isModalSubmit() && interaction.customId.startsWith('estmodal:')) {
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const partes = interaction.customId.split(':');
      const acao = partes[1];

      // Edita o proprio painel com o resultado, em vez de criar mensagem nova.
      // botoesExtras ficam na mesma linha do "Voltar ao menu".
      const voltarMenu = (texto, botoesExtras = []) =>
        interaction.update({
          content: texto,
          embeds: [],
          components: [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder().setCustomId('estadm:menu').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary),
              ...botoesExtras
            ),
          ],
        });

      if (acao === 'addcat') {
        const nome = interaction.fields.getTextInputValue('nome').trim();
        const cat = estoqueDb.addCategoria(interaction.guildId, nome);
        if (cat) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(cat ? `✅ Categoria **${nome}** criada.` : `❌ A categoria **${nome}** já existe.`);
      }

      if (acao === 'addprod') {
        const catId = partes[2];
        const nome = interaction.fields.getTextInputValue('nome').trim();
        const valor = parseFloat(interaction.fields.getTextInputValue('valor').trim().replace(/\./g, '').replace(',', '.'));
        const qtdBruta = (interaction.fields.getTextInputValue('qtd') || '').trim();
        const controlarQtd = qtdBruta !== '';
        const quantidade = controlarQtd ? parseInt(qtdBruta, 10) : null;

        if (isNaN(valor) || valor <= 0) {
          return voltarMenu('❌ Valor inválido.');
        }
        if (controlarQtd && (isNaN(quantidade) || quantidade < 0)) {
          return voltarMenu('❌ Quantidade inválida.');
        }

        const descricao = (interaction.fields.getTextInputValue('descricao') || '').trim();
        const imagem = (interaction.fields.getTextInputValue('imagem') || '').trim();
        if (imagem && !imagem.startsWith('http')) {
          return voltarMenu('❌ Link de imagem inválido. Use um link começando com http.');
        }
        const p = estoqueDb.addProduto(interaction.guildId, catId, { nome, valor, controlarQtd, quantidade, descricao, imagem });
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          p
            ? `✅ Produto **${nome}** adicionado por ${formatBRL(valor)}${controlarQtd ? ` (estoque: ${quantidade})` : ' (sem controle de quantidade)'}.`
            : '❌ Já existe um produto com esse nome nessa categoria.',
          p
            ? [new ButtonBuilder().setCustomId(`estadm:addprod2:${catId}`).setLabel('➕ Adicionar outro produto').setStyle(ButtonStyle.Success)]
            : []
        );
      }

      if (acao === 'qtd') {
        const [, , catId, prodId] = partes;
        const qtd = parseInt(interaction.fields.getTextInputValue('qtd').trim(), 10);
        if (isNaN(qtd) || qtd < 0) {
          return voltarMenu('❌ Quantidade inválida.');
        }
        const p = estoqueDb.setQuantidade(interaction.guildId, catId, prodId, qtd);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        // Avisa quando o produto esgota
        if (p && p.quantidade === 0) {
          avisar(client, interaction.guildId, `⚠️ **${p.nome}** esgotou no estoque!`).catch(() => {});
        }
        return voltarMenu(
          p ? `✅ **${p.nome}** agora tem **${p.quantidade}** em estoque.` : '❌ Produto não encontrado ou sem controle de quantidade.'
        );
      }

      if (acao === 'nome') {
        const [, , catId, prodId] = partes;
        const novoNome = interaction.fields.getTextInputValue('nome').trim();
        if (!novoNome) return voltarMenu('❌ Nome inválido.');
        const antes = estoqueDb.produto(interaction.guildId, catId, prodId)?.nome;
        const p = estoqueDb.setNome(interaction.guildId, catId, prodId, novoNome);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          p ? `✅ Produto renomeado: **${antes}** → **${novoNome}**` : '❌ Produto não encontrado.'
        );
      }

      if (acao === 'rencat') {
        const catId = partes[2];
        const novoNome = interaction.fields.getTextInputValue('nome').trim();
        if (!novoNome) return voltarMenu('❌ Nome inválido.');
        const cat = estoqueDb.renomearCategoria(interaction.guildId, catId, novoNome);
        if (cat) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          cat ? `✅ Categoria renomeada para **${novoNome}**` : '❌ Categoria não encontrada.'
        );
      }

      if (acao === 'catemoji') {
        const catId = partes[2];
        const { sanitizarEmoji } = require('./utils/sanitizarEmoji');
        const emoji = sanitizarEmoji(interaction.fields.getTextInputValue('emoji'));
        const cat = estoqueDb.setEmojiCategoria(interaction.guildId, catId, emoji);
        if (cat) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          cat ? `✅ Emoji da categoria **${cat.nome}** definido para ${emoji || 'nenhum'}.` : '❌ Categoria não encontrada.'
        );
      }

      if (acao === 'catdesc') {
        const catId = partes[2];
        const descricao = (interaction.fields.getTextInputValue('descricao') || '').trim();
        const cat = estoqueDb.setDescricaoCategoria(interaction.guildId, catId, descricao);
        if (cat) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          cat ? `✅ Descrição de **${cat.nome}** ${descricao ? `definida: _${descricao}_` : 'removida'}.` : '❌ Categoria não encontrada.'
        );
      }

      if (acao === 'proddtl-desc') {
        const [, , catId, prodId] = partes;
        const descricao = (interaction.fields.getTextInputValue('descricao') || '').trim();
        const p = estoqueDb.setDescricaoProduto(interaction.guildId, catId, prodId, descricao);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          p ? `✅ Descrição de **${p.nome}** ${descricao ? `definida: _${descricao}_` : 'removida'}.` : '❌ Produto não encontrado.'
        );
      }

      if (acao === 'proddtl-img') {
        const [, , catId, prodId] = partes;
        const imagem = (interaction.fields.getTextInputValue('imagem') || '').trim();
        if (imagem && !imagem.startsWith('http')) {
          return voltarMenu('❌ Link de imagem inválido. Use um link começando com http.');
        }
        const p = estoqueDb.setImagemProduto(interaction.guildId, catId, prodId, imagem);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          p ? `✅ Imagem de **${p.nome}** ${imagem ? 'atualizada.' : 'removida.'}` : '❌ Produto não encontrado.'
        );
      }

      if (acao === 'proddtl-valor') {
        const [, , catId, prodId] = partes;
        const valor = parseFloat(interaction.fields.getTextInputValue('valor').trim().replace(/\./g, '').replace(',', '.'));
        if (isNaN(valor) || valor <= 0) {
          return voltarMenu('❌ Valor inválido.');
        }
        const p = estoqueDb.setValor(interaction.guildId, catId, prodId, valor);
        if (p) refreshPainelEstoque(client).catch(() => {});
        painelCategoria.refresh(client).catch(() => {});
        return voltarMenu(
          p ? `✅ Preço de **${p.nome}** atualizado para ${formatBRL(valor)}.` : '❌ Produto não encontrado.'
        );
      }
      return;
    }
  } catch (error) {
    console.error('[Estoque] Erro na interação:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Botões de conteúdo copiável (comandos personalizados) -----

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('custom:copy:')) {
      const custom = require('./utils/customCommands');
      const partes = interaction.customId.split(':');
      const nomeCmd = partes[2];
      const idx = parseInt(partes[3], 10);

      const cmd = custom.obter(interaction.guildId, nomeCmd);
      if (!cmd || !cmd.copiaveis[idx]) {
        return interaction.reply({ content: '❌ Conteúdo não encontrado.', flags: MessageFlags.Ephemeral });
      }

      const item = cmd.copiaveis[idx];
      // Resposta ephemeral com o valor em texto puro (sem rotulo/backticks)
      return interaction.reply({
        content: item.valor,
        flags: MessageFlags.Ephemeral,
      });
    }
  } catch (error) {
    console.error('[Copiar]', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Erro ao copiar.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});
// ----- Excluir comando personalizado via caixinha (select) do /gerenciarcomandos -----
client.on('interactionCreate', async (interaction) => {
  try {
    // O painel do /gerenciarcomandos so aparece para quem tem permissao, mas o
    // handler tambem revalida no servidor (defesa em profundidade contra uso
    // manual de customId).
    if (interaction.customId && interaction.customId.startsWith('gerencmd:') && !permitido(interaction)) {
      return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
    }
    if (interaction.isAnySelectMenu() && interaction.customId === 'gerencmd:excluir') {
      const custom = require('./utils/customCommands');
      const nome = interaction.values[0];
      return interaction.update(
        montarConfirmacao(
          `🗑️ **Confirmar exclusão do comando_**/**${nome}**?`,
          `gerencmd:confirm:${nome}`,
          'gerencmd:cancel'
        )
      );
    }

    // Confirmação de exclusão do comando personalizado
    if (interaction.isButton() && interaction.customId.startsWith('gerencmd:confirm:')) {
      const custom = require('./utils/customCommands');
      const nome = (interaction.customId.split(':')[2] || '' ).trim();
      const ok = custom.excluir(interaction.guildId, nome);
      return interaction.update({
        content: ok ? '✅ Comando !' + nome + ' excluído.' : '❌ Comando !' + nome + ' não encontrado.',
        components: [],
      });
    }
    if (interaction.isButton() && interaction.customId === 'gerencmd:cancel') {
      return interaction.update({
        content: '✅ Exclusão cancelada.',
        components: [],
      });
    }
  } catch (error) {
    console.error('[Excluir custom]', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Erro ao excluir.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// Guarda palavra+resposta entre o submit do modal de criação e a escolha
// de canais (ChannelSelectMenu), pois o modal não pode conter select menus.
// Key: `${userId}:${guildId}`; limpo em 2min ou após resolver.
const autorespCriacaoCache = new Map();
function cacheCriacao(interaction, palavra, resposta) {
  const key = interaction.user.id + ':' + interaction.guildId;
  const dados = { palavra, resposta };
  autorespCriacaoCache.set(key, dados);
  setTimeout(() => {
    if (autorespCriacaoCache.get(key) === dados) autorespCriacaoCache.delete(key);
  }, 120000);
  return dados;
}

// ----- Editar auto-resposta via select/modal (!autoresposta / /autoresposta) -----
client.on('interactionCreate', async (interaction) => {
  try {
    // Qualquer botao/select/modal do painel de auto-respostas exige a mesma
    // permissao do comando. O painel via !autoresposta e uma mensagem publica,
    // entao sem esta checagem qualquer membro poderia editar/apagar as
    // auto-respostas do servidor clicando nos botoes.
    if (interaction.customId && interaction.customId.startsWith('autoresp') && !permitido(interaction)) {
      return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
    }
    if (interaction.isButton() && interaction.customId === 'autoresp:voltar') {
      const { painelCentral } = require('./utils/autoRespostaPanel');
      const menu = painelCentral(interaction.guildId, interaction.guild);
      if (!menu.components.length) return interaction.update({ content: menu.content, components: [] });
      return interaction.update({ content: menu.content, components: menu.components });
    }

    if (interaction.isChannelSelectMenu() && interaction.customId === 'autoresp:pickcanais') {
      const store = require('./utils/autoRespostaStore');
      const dados = autorespCriacaoCache.get(interaction.user.id + ':' + interaction.guildId);
      if (!dados) return interaction.update({ content: '❌ Sessão expirada. Execute /autoresposta ou !autoresposta novamente.', components: [] });
      autorespCriacaoCache.delete(interaction.user.id + ':' + interaction.guildId);
      const canaisIds = [...new Set((interaction.values || []) .filter((id) => /^\d+$/.test(id)))];
      const res = store.adicionar(interaction.guildId, dados.palavra, dados.resposta, canaisIds);
      const sucesso = res.ok ? '✅ ' + res.msg + (canaisIds.length ? ' (canais: ' + canaisIds.map((id) => '<#' + id + '>').join(', ') + ')' : '') : '❌ ' + res.msg;
      return interaction.update({
        content: sucesso,
        components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))],
      });
    }

    if (interaction.isButton() && interaction.customId === 'autoresp:picksalvar') {
      const store = require('./utils/autoRespostaStore');
      const dados = autorespCriacaoCache.get(interaction.user.id + ':' + interaction.guildId);
      if (!dados) return interaction.update({ content: '❌ Sessão expirada. Execute /autoresposta ou !autoresposta novamente.', components: [] });
      autorespCriacaoCache.delete(interaction.user.id + ':' + interaction.guildId);
      const res = store.adicionar(interaction.guildId, dados.palavra, dados.resposta, []);
      return interaction.update({ content: res.ok ? '✅ ' + res.msg : '❌ ' + res.msg, components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))] });
    }

    if (interaction.isAnySelectMenu() && interaction.customId === 'autoresp:editar') {
      const store = require('./utils/autoRespostaStore');
      const { modalEditar } = require('./utils/autoRespostaPanel');
      const palavra = interaction.values[0];
      const item = store.listar(interaction.guildId).find((r) => r.palavra.toLowerCase() === palavra);
      if (!item) {
        return interaction.reply({ content: '❌ Auto-resposta não encontrada.', flags: MessageFlags.Ephemeral });
      }
      return interaction.showModal(modalEditar(item));
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('autoresp:editmodal:')) {

      const store = require('./utils/autoRespostaStore');
      const palavraAntiga = (interaction.customId.split(':')[2] || '' );
      const novaPalavra = interaction.fields.getTextInputValue('palavra').trim();
      const novaResposta = interaction.fields.getTextInputValue('resposta').trim();
      const res = store.editar(interaction.guildId, palavraAntiga, novaPalavra, novaResposta);
      return interaction.reply({ content: res.ok ? '✅ ' + res.msg : '❌ ' + res.msg, flags: MessageFlags.Ephemeral });
    }

    if ((interaction.isStringSelectMenu() || interaction.isButton()) && interaction.customId.startsWith('autorespcanal')) {
      const { resolverSelecaoCanal } = require('./utils/channelPicker');
      const store = require('./utils/autoRespostaStore');
      const { canal, cancelado } = resolverSelecaoCanal(interaction, 'autorespcanal');
      if (cancelado) {
        return interaction.reply({ content: '❌ Operação cancelada.', flags: MessageFlags.Ephemeral });
      }
      if (!canal || !canal.isTextBased() || !canal.permissionsFor(interaction.guild.members.me)?.has('SendMessages')) {
        return interaction.reply({ content: '❌ Canal não encontrado ou sem permissão para eu enviar mensagens.', flags: MessageFlags.Ephemeral });
      }
      const atuais = store.canais(interaction.guildId);
      if (atuais.includes(canal.id)) {
        const nova = atuais.filter((id) => id !== canal.id);
        store.definirCanais(interaction.guildId, nova);
        return interaction.reply({ content: '🚫 Removido ' + canal + (nova.length ? '' : ' Agora responde em qualquer canal.'), flags: MessageFlags.Ephemeral });
      }
      const nova = [...atuais, canal.id];
      store.definirCanais(interaction.guildId, nova);
      return interaction.reply({ content: '✅ Adicionado ' + canal + (nova.length === 1 ? ' Agora responde **somente** neste canal.' : ''), flags: MessageFlags.Ephemeral });
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'autoresp:canalrapido') {

      const store = require('./utils/autoRespostaStore');
      const valores = Array.isArray(interaction.values) ? interaction.values : [];
      const atuais = store.canais(interaction.guildId);
      const novo = [...new Set([...atuais, ...valores])];
      store.definirCanais(interaction.guildId, novo);
      return interaction.reply({ content: '✅ Canais comuns atualizados: ' + (novo.length ? novo.map((id) => '<#' + id + '>').join(', ') : 'todos os canais'), flags: MessageFlags.Ephemeral });
    }

    if (interaction.isButton() && interaction.customId === 'autoresp:canalrapido:todos') {

      const store = require('./utils/autoRespostaStore');
      store.definirCanais(interaction.guildId, []);
      return interaction.update({ content: '🌐 Agora responde em **qualquer canal** do servidor.', components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))] });
    }

    if (interaction.isButton() && interaction.customId === 'autoresp:canalrapido:limpar') {

      const store = require('./utils/autoRespostaStore');
      store.definirCanais(interaction.guildId, []);
      return interaction.reply({ content: '🧹 Lista de canais comum limpa — responde em **qualquer canal**.', flags: MessageFlags.Ephemeral });
    }

    if (interaction.isAnySelectMenu() && interaction.customId === 'autoresp:acao') {
      const { ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
      const store = require('./utils/autoRespostaStore');
      const { modalAdicionar, menuEditar, selectRemover, painelCentral } = require('./utils/autoRespostaPanel');
      const acao = (interaction.values || [])[0] || '';
      if (acao === 'adicionar') {
        return interaction.showModal(modalAdicionar(true));
      }
      if (acao === 'editar') {
        const menu = menuEditar(interaction.guildId);
        if (!menu.components.length) return interaction.reply({ content: menu.content, flags: MessageFlags.Ephemeral });
        return interaction.update({ content: menu.content, components: menu.components });
      }
      if (acao === 'remover') {
        const menu = selectRemover(interaction.guildId);
        if (!menu.components.length) return interaction.reply({ content: menu.content, flags: MessageFlags.Ephemeral });
        return interaction.update({ content: menu.content, components: menu.components });
      }
      if (acao === 'ver') {
        const lista = store.listar(interaction.guildId);
        const canaisIds = store.canais(interaction.guildId);
        const canaisTxt = canaisIds.length ? canaisIds.map((id) => '<#' + id + '>').join(', ') : 'todos os canais';
        if (!lista.length) return interaction.update({ content: '📭 Nenhuma auto-resposta ainda.\n**Canais:** ' + canaisTxt, components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))] });
        const linhas = lista.map((r, i) => '`' + (i + 1) + '` **' + r.palavra + '** → ' + r.resposta).join('\n');
        return interaction.update({ content: '**Auto-respostas (' + lista.length + '):**\n' + linhas + '\n**Canais:** ' + canaisTxt, components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))] });
      }
      if (acao === 'limpar') {
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('autoresp:limparsim').setLabel('✅ Sim, apagar tudo').setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId('autoresp:limparnao').setLabel('❌ Não').setStyle(ButtonStyle.Secondary)
        );
        const rowVoltar = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary));
        return interaction.update({ content: '🧹 **Apagar TODAS as auto-respostas?**\nEssa ação não pode ser desfeita.', components: [row, rowVoltar] });
      }
      if (acao === 'canais') {
        const { canaisPublicaveis } = require('./utils/channelPicker');
        const { StringSelectMenuBuilder } = require('discord.js');
        const canais = canaisPublicaveis(interaction.guild);
        const atuais = store.canais(interaction.guildId);
        const sel = new StringSelectMenuBuilder()
          .setCustomId('autoresp:canalrapido')
          .setPlaceholder('📣 Escolha um ou mais canais (comuns)…')
          .setMinValues(1)
          .setMaxValues(Math.min(canais.length, 25))
          .addOptions(canais.map((c) => ({
            label: (atuais.includes(c.id) ? '✅ ' : '') + c.name,
            description: atuais.includes(c.id) ? 'Clique para remover' : 'Clique para adicionar',
            value: c.id,
          })));
        const row = new ActionRowBuilder().addComponents(sel);
        const rowVoltar = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary));
        if (!canais.length) return interaction.update({ content: '❌ Nenhum canal de texto disponível.', components: [rowVoltar] });
        return interaction.update({ content: '📣 **Canais comuns** — escolha abaixo (pode marcar vários).\nAtual: ' + (atuais.length ? atuais.map((id) => '<#' + id + '>').join(', ') : 'todos os canais'), components: [row, rowVoltar] });
      }
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith('autoresp:addmodal')) {
      const store = require('./utils/autoRespostaStore');
      const { telaEscolherCanais } = require('./utils/autoRespostaPanel');
      const palavra = interaction.fields.getTextInputValue('palavra').trim();
      const resposta = interaction.fields.getTextInputValue('resposta').trim();
      if (!palavra || !resposta) return interaction.reply({ content: '❌ Informe palavra e resposta.', flags: MessageFlags.Ephemeral });
      let canaisIds = [];
      if (interaction.customId === 'autoresp:addmodal:canais') {
        const bruto = interaction.fields.getTextInputValue('canais') || '';
        canaisIds = bruto.split(/[,\s]+/) .map((s) => s.trim().replace(/[<#>]/g, '' )).filter((s) => /^\d+$/.test(s));
        canaisIds = [...new Set(canaisIds)];
      }
      // Canais já informados no modal (ou modal sem campo de canais)→ salva direto (fluxo atual preservado).
      if (canaisIds.length || interaction.customId === 'autoresp:addmodal') {

        const res = store.adicionar(interaction.guildId, palavra, resposta, canaisIds);
        return interaction.reply({ content: res.ok ? '✅ ' + res.msg + (canaisIds.length ? ' (canais: ' + canaisIds.map((id) => '<#' + id + '>').join(', ') + ')' : '') : '❌ ' + res.msg, flags: MessageFlags.Ephemeral });
      }
      // Sem canais no modal: oferece o seletor de canais da guild (sem digitar IDs.

      cacheCriacao(interaction, palavra, resposta);
      return interaction.reply(telaEscolherCanais(interaction.guild, palavra, resposta));
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'autoresp:remover') {
      const store = require('./utils/autoRespostaStore');
      const palavra = interaction.values[0];
      const res = store.remover(interaction.guildId, palavra);
      return interaction.reply({ content: res.ok ? '✅ ' + res.msg : '❌ ' + res.msg, flags: MessageFlags.Ephemeral });
    }

    if (interaction.isButton() && interaction.customId === 'autoresp:limparsim') {
      const store = require('./utils/autoRespostaStore');
      store.definirCanais(interaction.guildId, []);
      const fs = require('node:fs');
      const path = require('node:path');
      const arq = path.join(__dirname, '..', 'data', 'autorespostas', interaction.guildId + '.json');
      try { fs.rmSync(arq); } catch (e) {}
      return interaction.update({ content: '🧹 Todas as auto-respostas foram apagadas.', components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))] });
    }

    if (interaction.isButton() && interaction.customId === 'autoresp:limparnao') {
      return interaction.update({ content: '✅ Operação cancelada.', components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('autoresp:voltar').setLabel('⬅️ Voltar ao menu').setStyle(ButtonStyle.Secondary))] });
    }
  } catch (error) {
    console.error('[Auto-resposta editar]', error);
    try {
      if (!interaction.replied && !interaction.deferred) {

        await interaction.reply({ content: '❌ Erro ao editar.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Permissões por cargo (!permissoes / /permissoes) -----
const { buildPermissionsPanel, buildGrupoPanel, buildRemoverPanel } = require('./utils/permissionsPanel');
const { setCargo, eDono, comandoPode } = require('./utils/permissions');

// Mapeia o customId de uma interação para o comando que ela representa,
// permitindo que o sistema de permissões por cargo restrinja botões/menus.
function comandoDoCustomId(interaction) {
  const id = interaction.customId || '';
  // O select de remover item do carrinho (/comprar) nao representa um comando
  // administrativo: a posse do carrinho e validada no proprio handler.
  if (id === 'comp:removeritem') return null;
  if (id.startsWith('estadm:') || id.startsWith('estmodal:')) return 'configestoque';
  if (id.startsWith('estfixo:')) return 'estoque';
  if (id.startsWith('painelcenter:')) return 'painel';
  if (id.startsWith('painelcat:')) return 'painelcategoria';
  if (id.startsWith('cfg:') || id.startsWith('cfgmodal:')) return 'configtaxa';
  if (id.startsWith('embedpainel:') || id.startsWith('embedmodal:') || id.startsWith('embedcanal:')) return 'embed';
  if (id.startsWith('msgpainel:') || id.startsWith('msgmodal:') || id.startsWith('msgcanal:')) return 'mensagem';
  if (id.startsWith('lockconf:')) return 'lock';
  if (id.startsWith('unlockconf:')) return 'unlock';
  if (id.startsWith('modelos:')) return 'embed';
  if (id.startsWith('gerencmd:')) return 'gerenciarcomandos';
  if (id.startsWith('autorespcanal')) return 'autoresposta';
  if (id.startsWith('autoresp:')) return 'autoresposta';
  if (id.startsWith('custom:copy:')) return 'criarcomando';
  if (id.startsWith('metaspainel:') || id.startsWith('metasmodal:')) return 'metas';
  return null;
}
function permitido(interaction) {
  const cmd = comandoDoCustomId(interaction);
  if (!cmd) return true;
  return comandoPode(interaction.member, interaction.user.id, cmd);
}


client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('perm:')) {
      const partes = interaction.customId.split(':');
      const acao = partes[1];
      const donoId = partes[partes.length - 1];

      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!isAdmin(interaction.member, interaction.user.id) && !eDono(interaction.user.id)) {
        return interaction.reply({ content: '🔒 Somente administradores podem gerenciar permissões.', flags: MessageFlags.Ephemeral });
      }
      if (!interaction.guild) {
        return interaction.reply({ content: '🔒 Isso só funciona no servidor.', flags: MessageFlags.Ephemeral });
      }

      if (acao === 'voltar') {
        return interaction.update(buildPermissionsPanel(interaction.guild, donoId));
      }

      if (acao === 'grupo') {
        const grupoId = partes[2];
        return interaction.update(buildGrupoPanel(interaction.guild, grupoId, donoId));
      }

      if (acao === 'remover') {
        const grupoId = partes[2];
        return interaction.update(buildRemoverPanel(interaction.guild, grupoId, donoId));
      }

      if (acao === 'remover2') {
        const grupoId = partes[2];
        const roleId = partes[3];
        setCargo(interaction.guildId, grupoId, roleId, false);
        return interaction.update(buildGrupoPanel(interaction.guild, grupoId, donoId));
      }

      return interaction.reply({ content: '❌ Ação desconhecida.', flags: MessageFlags.Ephemeral });
    }

    // Seletor de cargos para adicionar ao grupo
    if (interaction.isRoleSelectMenu() && interaction.customId.startsWith('perm:cargos:')) {
      const partes = interaction.customId.split(':');
      const grupoId = partes[2];
      const donoId = partes[3];

      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!isAdmin(interaction.member, interaction.user.id) && !eDono(interaction.user.id)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }

      for (const roleId of interaction.values) {
        setCargo(interaction.guildId, grupoId, roleId, true);
      }
      return interaction.update(buildGrupoPanel(interaction.guild, grupoId, donoId));
    }
  } catch (error) {
    console.error('[Permissões] Erro:', error?.message || error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});
// ----- Comandos por canal (!canalcomando) -----
client.on('interactionCreate', async (interaction) => {
  try {
    const id = interaction.customId || '';
    if (!id.startsWith('canalcmd:')) return;

    const { buildCanalComandoPanel, buildCanalComandoLista, buildCanalComandoDetalhe, buildCanalComandoCanais } = require('./utils/canalComandoPanel');
    const canalStore = require('./utils/canalComandoStore');

    const partes = id.split(':');
    const acao = partes[1];
    const donoId = partes[partes.length - 1];

    if (interaction.user.id !== donoId) {
      return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
    }
    if (!isAdmin(interaction.member, interaction.user.id) && !eDono(interaction.user.id)) {
      return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
    }
    if (!interaction.guild) {
      return interaction.reply({ content: '🔒 Isso só funciona no servidor.', flags: MessageFlags.Ephemeral });
    }

    if (acao === 'voltar') {
      return interaction.update(buildCanalComandoPanel(interaction.guildId, donoId));
    }

    if (acao === 'escolhercat') {
      const categoriaId = interaction.values[0];
      return interaction.update(buildCanalComandoLista(interaction.guildId, donoId, categoriaId));
    }

    if (acao === 'escolher') {
      const comando = interaction.values[0];
      return interaction.update(buildCanalComandoDetalhe(interaction.guildId, donoId, comando));
    }

    if (acao === 'canais') {
      const comando = partes[2];
      return interaction.update(buildCanalComandoCanais(interaction.guild, donoId, comando));
    }

    if (acao === 'todos') {
      const comando = partes[2];
      canalStore.definir(interaction.guildId, comando, null);
      return interaction.update(buildCanalComandoDetalhe(interaction.guildId, donoId, comando));
    }

    if (acao === 'nenhum') {
      const comando = partes[2];
      canalStore.definir(interaction.guildId, comando, []);
      return interaction.update(buildCanalComandoDetalhe(interaction.guildId, donoId, comando));
    }

    if (acao === 'setcanais') {
      const comando = partes[2];
      canalStore.definir(interaction.guildId, comando, interaction.values);
      return interaction.update(buildCanalComandoDetalhe(interaction.guildId, donoId, comando));
    }

    if (acao === 'mensagem') {
      const atualMsg = canalStore.mensagemGlobal(interaction.guildId) || '';
      const modal = new ModalBuilder()
        .setCustomId(`canalcmd:mensagemmodal:${donoId}`)
        .setTitle('✏️ Mensagem de bloqueio')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('mensagem')
              .setLabel('Mensagem fora dos canais ({canais} = canais)')
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(false)
              .setMaxLength(500)
              .setPlaceholder('Ex.: ❌ Você não pode usar comandos aqui! Faça em {canais}')
              .setValue(atualMsg)
          )
        );
      return interaction.showModal(modal);
    }

    return interaction.reply({ content: '❌ Ação desconhecida.', flags: MessageFlags.Ephemeral });
  } catch (error) {
    console.error('[CanalComando] Erro:', error?.message || error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// Modal da mensagem global de bloqueio dos comandos por canal.
client.on('interactionCreate', async (interaction) => {
  try {
    if (!interaction.isModalSubmit()) return;
    if (!interaction.customId.startsWith('canalcmd:mensagemmodal:')) return;

    const canalStore = require('./utils/canalComandoStore');
    const { buildCanalComandoPanel } = require('./utils/canalComandoPanel');
    const donoId = interaction.customId.split(':').slice(-1)[0];

    if (interaction.user.id !== donoId) {
      return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
    }
    if (!isAdmin(interaction.member, interaction.user.id) && !eDono(interaction.user.id)) {
      return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
    }

    const mensagem = interaction.fields?.getTextInputValue?.('mensagem') || '';
    canalStore.definirMensagemGlobal(interaction.guildId, mensagem || null);

    return interaction.reply({
      content: mensagem
        ? '✅ Mensagem de bloqueio atualizada!'
        : '✅ Mensagem de bloqueio **removida** (volta à padrão).',
      ...buildCanalComandoPanel(interaction.guildId, donoId),
      flags: MessageFlags.Ephemeral,
    });
  } catch (error) {
    console.error('[CanalComandoModal] Erro:', error?.message || error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Painel visual de embed -----

const { getSessao, limparSessao, buildEmbed, buildPainel, buildPreview, buildFieldsPainel, buildConteudoPrivado, urlValida, botoesEmLinhas } = require('./utils/embedPainel');
const { buildBotoesPainel, buildBotaoModal, buildBotaoPrivadoPainel } = require('./utils/botoesPainel');
const { buildModelosPainel, buildCategoriaPainel } = require('./utils/modelosPainel');
const modelosStore = require('./utils/embedModelos');
const welcomeStore = require('./utils/welcomeStore');
const welcomeVars = require('./utils/welcomeVars');
const welcomePainel = require('./utils/welcomePainel');
const { interpolar, interpolarEmbed } = require('./utils/interpolar');
const cttStore = require('./utils/cttStore');
const { linhaSelecaoCanalDe } = require('./utils/channelPicker');
const extrasHandlers = require('./utils/extras');

client.on('interactionCreate', async (interaction) => {
  try {
    if (interaction.isButton() && interaction.customId.startsWith('embedpainel:')) {
      const partes = interaction.customId.split(':');
      const acao = partes[1];
      const donoId = partes[2];

      // So o dono do painel pode usar
      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu. Use `!embed` para criar o seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }

      const estado = getSessao(donoId);

      // Abre modal para editar um campo
      const abrirModal = (campo, titulo, label, multiline = false) => {
        const atual = estado[campo] || '';
        const valorStr = multiline ? String(atual).slice(0, 4000) : String(atual).slice(0, 1024);
        const modal = new ModalBuilder()
          .setCustomId(`embedmodal:${campo}:${donoId}`)
          .setTitle(titulo)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('valor')
                .setLabel(label)
                .setStyle(multiline ? TextInputStyle.Paragraph : TextInputStyle.Short)
                .setRequired(campo !== 'titulo' && campo !== 'imagem' && campo !== 'thumbnail' && campo !== 'autor' && campo !== 'rodape' && campo !== 'textofora' && campo !== 'fields' && campo !== 'cargos')
                .setValue(valorStr)
            )
          );
        return interaction.showModal(modal);
      };

      const abrirPaginaModal = (idx, pi = -1) => {
        const atual = pi >= 0 ? (estado.botoes[idx].paginas[pi] || {}) : {};
        const modalPag = new ModalBuilder()
          .setCustomId(pi >= 0 ? `embedmodal:botpagedit:${donoId}:${idx}:${pi}` : `embedmodal:botpagnew:${donoId}:${idx}`)
          .setTitle(pi >= 0 ? `✏️ Editar pagina ${pi + 1}` : '➕ Nova pagina do botao privado')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('ptitulo')
                .setLabel('Titulo da pagina (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(256)
                .setValue(String(atual.titulo || '').slice(0, 256))
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('pdescricao')
                .setLabel('Descricao da pagina (opcional)')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(false)
                .setMaxLength(4000)
                .setValue(String(atual.descricao || '').slice(0, 4000))
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('pimagem')
                .setLabel('Link da imagem (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(1024)
                .setValue(String(atual.imagem || '').slice(0, 1024))
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('pthumb')
                .setLabel('Link do thumbnail (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(1024)
                .setValue(String(atual.thumbnail || '').slice(0, 1024))
            )
        );
        return interaction.showModal(modalPag);
      };

      if (acao === 'titulo') return abrirModal('titulo', '📝 Título', 'Título da embed');
      if (acao === 'descricao') return abrirModal('descricao', '📄 Descrição', 'Texto da embed', true);
      if (acao === 'cor') return abrirModal('cor', '🎨 Cor', 'Nome ou #hex (ex: lilas ou #beb6ff)');
      // Dica: upload por anexo e aceito ao chamar '!embed' com uma foto na mensagem
      if (acao === 'imagem') return abrirModal('imagem', '🖼️ Imagem', 'Link da imagem (ou anexe a foto no !embed)');
      if (acao === 'thumbnail') return abrirModal('thumbnail', '🔳 Thumbnail', 'Link da thumbnail (opcional)');
      if (acao === 'autor') return abrirModal('autor', '👤 Autor', 'Nome do autor (opcional)');
      if (acao === 'rodape') return abrirModal('rodape', '📝 Rodapé', 'Texto do rodapé (opcional)');
      if (acao === 'textofora') return abrirModal('textofora', '💬 Texto fora', 'Mensagem fora da embed (opcional)');
      if (acao === 'botoes') return interaction.update(buildBotoesPainel(donoId, interaction.guildId));
      if (acao === 'botaoadd') return interaction.showModal(buildBotaoModal(donoId));
      if (acao === 'botaoed') {
        const bts = Array.isArray(estado.botoes) ? estado.botoes : [];
        if (!bts.length) return interaction.reply({ content: '❌ Nenhum botão para editar.', flags: MessageFlags.Ephemeral });
        const sel = buildBotoesPainel(donoId, interaction.guildId);
        const linhas = Array.isArray(sel.components) ? [...sel.components] : [];
        // Reexibe a tela de botões destacando o select de escolha
        return interaction.update({
          content: '✏️ **Escolha o botão que deseja editar no menu abaixo:**',
          embeds: sel.embeds,
          components: linhas,
        });
      }
      if (acao === 'botaorem') {
        const bts = Array.isArray(estado.botoes) ? estado.botoes : [];
        if (!bts.length) return interaction.reply({ content: '❌ Nenhum botão para remover.', flags: MessageFlags.Ephemeral });
        bts.pop();
        estado.botoes = bts;
        return interaction.update(buildBotoesPainel(donoId, interaction.guildId));
      }
      if (acao === 'botpagadd') return abrirPaginaModal(Number(partes[3]));
      if (acao === 'botpaglimpar') {
        const bts = Array.isArray(estado.botoes) ? estado.botoes : [];
        const bi = Number(partes[3]);
        if (!bts[bi]) return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral });
        bts[bi].paginas = [];
        return interaction.update(buildBotaoPrivadoPainel(donoId, bi));
      }


      if (acao === 'salvar') {
        if (!interaction.guild) {
          return interaction.reply({ content: '❌ Só funciona no servidor.', flags: MessageFlags.Ephemeral });
        }
        const modalSalvar = new ModalBuilder()
          .setCustomId(`embedmodal:salvar:${donoId}`)
          .setTitle('💾 Salvar modelo')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('mnome')
                .setLabel('Nome do modelo')
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
                .setMaxLength(80)
                .setPlaceholder('Ex: Promoção de 500 Robux')
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('mcategoria')
                .setLabel('Categoria da guild (e.g.: Boas-vindas, Loja)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(24)
                .setValue('outros')
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('mdesc')
                .setLabel('Descrição interna (opcional)')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(false)
                .setMaxLength(1024)
            )
          );
        return interaction.showModal(modalSalvar);
      }

      if (acao === 'fields') return interaction.update(buildFieldsPainel(donoId));
        if (acao === 'fieldsadd') {
          const modal = new ModalBuilder()
            .setCustomId(`embedmodal:fieldnew:${donoId}`)
            .setTitle('➕ Novo Field')
            .addComponents(
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('fname')
                  .setLabel('Nome do campo')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
                  .setMaxLength(256)
                  .setPlaceholder('Ex: Preço')
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('fvalue')
                  .setLabel('Valor do campo')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(true)
                  .setMaxLength(1024)
                  .setPlaceholder('Ex: R$ 10,00')
              ),
              new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                  .setCustomId('finline')
                  .setLabel('Em linha? (sim ou não)')
                  .setStyle(TextInputStyle.Short)
                  .setRequired(false)
                  .setMaxLength(3)
                  .setValue('sim')
              )
            );
          return interaction.showModal(modal);
        }
        if (acao === 'fieldsclear') {
          estado.fields = [];
          return interaction.update(buildFieldsPainel(donoId));
        }
      if (acao === 'cargos') {
        // Botao legado: nao faz nada (a selecao agora e pelo menu nativo abaixo)
        return interaction.reply({ content: '👥 Use o **menu de seleção de cargos** abaixo dos botões para escolher.', flags: MessageFlags.Ephemeral });
      }

      if (acao === 'preview') {
        // Preview real: mostra apenas a embed final (sem o editor) com opções
        // de voltar a editar, enviar ou cancelar.

        return interaction.reply({ ...buildPreview(donoId, interaction.guildId), flags: MessageFlags.Ephemeral });
      }

      if (acao === 'voltar') {
        return interaction.update(buildPainel(donoId, interaction.guildId));
      }

      if (acao === 'enviar') {
        if (!buildEmbed(estado)) {
          return interaction.reply({ content: '❌ Preencha algo válido antes de enviar: **descrição**, **fields**, **imagem**, **thumbnail**, **rodapé**, **autor** ou **botões**. O **título** é opcional.', flags: MessageFlags.Ephemeral });
        }
        if (!interaction.guild) {
          return interaction.reply({ content: '❌ Não dá para publicar no servidor pela DM. Use o comando no servidor.', flags: MessageFlags.Ephemeral });
        }
        const canais = linhaSelecaoCanalDe(interaction.guild, `embedcanal:${donoId}`, interaction.channel.id, '📣 Escolha o canal para publicar…');
        if (!canais.canais.length) {
          return interaction.reply({ content: '❌ Não encontrei nenhum canal de texto em que eu possa publicar.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update({
          content: '🗂️ **Onde deseja publicar a embed?**\n_Selecione um canal abaixo ou use **📌 Canal atual**._',
          embeds: [new EmbedBuilder().setColor(0xbeb6ff).setDescription('👁️ Esta é a embed que será enviada:') , buildEmbed(estado)].filter(Boolean),
          components: [canais.row, canais.botoes],
        });
      }

      if (acao === 'cancelar') {
        limparSessao(donoId);
        return interaction.update({ content: '❌ Montagem cancelada.', embeds: [], components: [] });
      }
      return;
    }

    // Menu de selecao de cargos (RoleSelectMenu nativo)
    if (interaction.isRoleSelectMenu() && interaction.customId.startsWith('embedpainel:selcargos:')) {
      const donoId = interaction.customId.split(':')[2];
      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const estado = getSessao(donoId);
      estado.cargos = [...interaction.values]; // IDs dos cargos selecionados
      return interaction.update(buildPainel(donoId, interaction.guildId));
    }

    // Select menu para editar um field da embed
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('embedpainel:fieldsel:')) {
      const donoId = interaction.customId.split(':')[2];
      if (interaction.user.id !== donoId) {

        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {

        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const estado = getSessao(donoId);
      const idx = parseInt(interaction.values[0], 10);
      if (Number.isNaN(idx) || idx < 0 || idx >= (estado.fields || []).length) {

        return interaction.reply({ content: '❌ Field inválido.', flags: MessageFlags.Ephemeral });
      }
      const f = estado.fields[idx];
      const modal = new ModalBuilder()
        .setCustomId(`embedmodal:fieldedit:${donoId}:${idx}`)
        .setTitle(`✏️ Editar Field ${idx + 1}`)
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('fname')
              .setLabel('Nome do campo')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setMaxLength(256)
              .setValue(String(f.name || '').slice(0, 256))
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('fvalue')
              .setLabel('Valor do campo')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setMaxLength(1024)
              .setValue(String(f.value || '').slice(0, 1024))
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('finline')
              .setLabel('Em linha? (sim ou não)')
              .setStyle(TextInputStyle.Short)
              .setRequired(false)
              .setMaxLength(3)
              .setValue(f.inline ? 'sim' : 'não')
          )
        );
      return interaction.showModal(modal);
    }

    // Select menu para escolher um botão (editar/conteúdo privado)
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('embedpainel:botaosel:')) {
      const donoId = interaction.customId.split(':')[2];
      if (interaction.user.id !== donoId) {

        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const estado = getSessao(donoId);
      const idx = parseInt(interaction.values[0], 10);
      const bts = Array.isArray(estado.botoes) ? estado.botoes : [];
      if (Number.isNaN(idx) || idx < 0 || idx >= bts.length) {
        return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral });
      }
      const b = bts[idx];
      if (b && (b.acao === 'privado' || b.paginas || b._privado)) {
        if (!Array.isArray(b.paginas)) b.paginas = [];
        return interaction.update(buildBotaoPrivadoPainel(donoId, idx));
      }
      return interaction.showModal(buildBotaoModal(donoId, idx));
    }

    // Select menu para REMOVER uma única página (conteúdo) do botão privado
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('embedpainel:botpagdel:')) {
      const partesSel = interaction.customId.split(':');
      const donoId = partesSel[2];
      const bi = Number(partesSel[3]);
      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const estado = getSessao(donoId);
      const bts = Array.isArray(estado.botoes) ? estado.botoes : [];
      if (!bts[bi] || !Array.isArray(bts[bi].paginas)) {
        return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral });
      }
      const pi = parseInt(interaction.values[0], 10);
      if (Number.isNaN(pi) || pi < 0 || pi >= bts[bi].paginas.length) {
        return interaction.reply({ content: '❌ Conteúdo inválido.', flags: MessageFlags.Ephemeral });
      }
      bts[bi].paginas.splice(pi, 1);
      return interaction.update(buildBotaoPrivadoPainel(donoId, bi));
    }

    // Select menu para escolher um conteúdo (página) do botão privado
    if (interaction.isStringSelectMenu() && interaction.customId.startsWith('embedpainel:botpagsel:')) {
      const partesSel = interaction.customId.split(':');
      const donoId = partesSel[2];
      const bi = Number(partesSel[3]);
      if (interaction.user.id !== donoId) {

        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }
      const estado = getSessao(donoId);
      const bts = Array.isArray(estado.botoes) ? estado.botoes : [];
      if (!bts[bi] || !Array.isArray(bts[bi].paginas)) {
        return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral });
      }
      const pi = parseInt(interaction.values[0], 10);
      if (Number.isNaN(pi) || pi < 0 || pi >= bts[bi].paginas.length) {

        return interaction.reply({ content: '❌ Conteúdo inválido.', flags: MessageFlags.Ephemeral });
      }
      const atual = bts[bi].paginas[pi] || {};
        const modalPag = new ModalBuilder()
          .setCustomId(`embedmodal:botpagedit:${donoId}:${bi}:${pi}`)
          .setTitle(`✏️ Editar conteúdo ${pi + 1}`)
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('ptitulo')
                .setLabel('Titulo do conteudo (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(256)
                .setValue(String(atual.titulo || '').slice(0, 256))
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('pdescricao')
                .setLabel('Descricao do conteudo (opcional)')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(false)
                .setMaxLength(4000)
                .setValue(String(atual.descricao || '').slice(0, 4000))
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('pimagem')
                .setLabel('Link da imagem (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(1024)
                .setValue(String(atual.imagem || '').slice(0, 1024))
            ),
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('pthumb')
                .setLabel('Link do thumbnail (opcional)')
                .setStyle(TextInputStyle.Short)
                .setRequired(false)
                .setMaxLength(1024)
                .setValue(String(atual.thumbnail || '').slice(0, 1024))
            )
          );
        return interaction.showModal(modalPag);
    }

    // Modais do painel de embed
    if (interaction.isModalSubmit() && interaction.customId.startsWith('embedmodal:')) {
      const partes = interaction.customId.split(':');
      const campo = partes[1];
      const donoId = partes[2];

      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      // ---- Modais dos botões do editor ----
      if (campo === 'botaosave') {
        const estado = getSessao(donoId);
        const botoes = Array.isArray(estado.botoes) ? estado.botoes : [];
        const rotulo = (interaction.fields.getTextInputValue('rotulo') || '').trim();
        const { sanitizarEmoji } = require('./utils/sanitizarEmoji');
        const emoji = sanitizarEmoji(interaction.fields.getTextInputValue('emoji'));
        const estilo = (interaction.fields.getTextInputValue('estilo') || '' ).trim().toLowerCase();
        const acao = ((interaction.fields.getTextInputValue('acao') || '' ).trim().toLowerCase() === 'privado') ? 'privado' : 'link';
        const valor = (interaction.fields.getTextInputValue('valor') || '' ).trim();
        if (!rotulo) return interaction.reply({ content: '❌ Informe o **nome** do botão.', flags: MessageFlags.Ephemeral });
        const estilosValidos = ['primario','secundario','sucesso','perigo','link','primary','secondary','success','danger'];
        const estiloNorm = estilosValidos.includes(estilo) ? estilo : (acao === 'privado' ? 'secundario' : 'link');
        const novo = { rotulo: rotulo.slice(0, 80), emoji, estilo: estiloNorm, acao, valor: valor.slice(0, 4000) };
        const idx = partes[3];
        if (idx !== undefined && Number.isInteger(Number(idx))) {
          const i = Number(idx);
          if (i < 0 || i >= botoes.length) return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral });
          if (acao === 'privado' && !Array.isArray(botoes[i].paginas)) botoes[i].paginas = [];
          botoes[i] = { ...botoes[i], ...novo };
        } else {
          if (acao === 'privado') novo.paginas = [];
          botoes.push(novo);
        }
        estado.botoes = botoes;
        return interaction.update(buildBotoesPainel(donoId, interaction.guildId));
      }

      if (campo === 'botpagnew' || campo === 'botpagedit') {

        const estado = getSessao(donoId);
        const botoes = Array.isArray(estado.botoes) ? estado.botoes : [];
        const i = Number(partes[3]);
        if (!botoes[i]) return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral });
        if (!Array.isArray(botoes[i].paginas)) botoes[i].paginas = [];
        const tituloP = (interaction.fields.getTextInputValue('ptitulo') || '' ).trim();
        const descricaoP = (interaction.fields.getTextInputValue('pdescricao') || '' ).trim();
        const imagemP = (interaction.fields.getTextInputValue('pimagem') || '' ).trim();
        const thumbP = (interaction.fields.getTextInputValue('pthumb') || '' ).trim();
        if (!tituloP && !descricaoP && !imagemP && !thumbP) {
          return interaction.reply({ content: '❌ Preencha ao menos um campo da página.', flags: MessageFlags.Ephemeral });
        }
        const pagina = { titulo: tituloP || null, descricao: descricaoP || null, imagem: imagemP || null, thumbnail: thumbP || null, fields: [] };
        if (campo === 'botpagnew') {
          botoes[i].paginas.push(pagina);
        } else {
          const pi = Number(partes[4]);
          if (Number.isNaN(pi) || pi < 0 || pi >= botoes[i].paginas.length) {
            return interaction.reply({ content: '❌ Página inválida.', flags: MessageFlags.Ephemeral });
          }
          botoes[i].paginas[pi] = pagina;
        }
        return interaction.update(buildBotaoPrivadoPainel(donoId, i));
      }

      if (campo === 'salvar') {
        if (!interaction.guildId) return interaction.reply({ content: '❌ Só funciona no servidor.', flags: MessageFlags.Ephemeral });
        const nomeM = (interaction.fields.getTextInputValue('mnome') || '' ).trim();
        const catM = (interaction.fields.getTextInputValue('mcategoria') || '' ).trim().toLowerCase();
        const descM = (interaction.fields.getTextInputValue('mdesc') || '' ).trim() || null;
        const sessao = getSessao(donoId);
        const dadosModelo = JSON.parse(JSON.stringify({ ...sessao, botoes: sessao.botoes || [], fields: sessao.fields || [], cargos: sessao.cargos || [], paginas: undefined }));
        const res = modelosStore.criar(interaction.guildId, { nome: nomeM, categoria: catM, descricao: descM, dados: dadosModelo });
        if (!res.ok) return interaction.reply({ content: '❌ ' + (res.msg || 'Erro ao salvar.'), flags: MessageFlags.Ephemeral });
        return interaction.update({ content: '💾 Modelo **' + res.modelo.nome + '** salvo! Use `!modelos` para ver e usar.', embeds: [], components: [] });
      }

      if (campo === 'modeloed') {
        if (!interaction.guildId) return interaction.reply({ content: '❌ Só funciona no servidor.', flags: MessageFlags.Ephemeral });
        const mid = partes[2] || partes[3];
        const m = modelosStore.obter(interaction.guildId, mid);
        if (!m) return interaction.reply({ content: '❌ Modelo não encontrado.', flags: MessageFlags.Ephemeral });
        const nomeM = (interaction.fields.getTextInputValue('mnome') || '' ).trim();
        const catM = (interaction.fields.getTextInputValue('mcategoria') || '' ).trim().toLowerCase();
        const descM = (interaction.fields.getTextInputValue('mdesc') || '' ).trim() || null;
        const res = modelosStore.atualizar(interaction.guildId, mid, { nome: nomeM, categoria: catM, descricao: descM });
        if (!res.ok) return interaction.reply({ content: '❌ ' + (res.msg || 'Erro.'), flags: MessageFlags.Ephemeral });
        return interaction.update({ content: '✅ Modelo **' + res.modelo.nome + '** atualizado.', embeds: [], components: [] });
      }

// Modais visuais de fields (sem o separador "|": campos separados Nome/Valor/Em linha)
      if (campo === 'fieldnew' || campo === 'fieldedit') {
        const estado = getSessao(donoId);
        const fname = (interaction.fields.getTextInputValue('fname') || '').trim();
        const fvalue = (interaction.fields.getTextInputValue('fvalue') || '').trim();
        const finline = (interaction.fields.getTextInputValue('finline') || 'sim').trim().toLowerCase();
        if (!fname || !fvalue) {
          return interaction.reply({ content: '❌ Preencha o **nome** e o **valor** do campo.', flags: MessageFlags.Ephemeral });
        }
        const novo = { name: fname.slice(0, 256), value: fvalue.slice(0, 1024), inline: !['não','nao','false','0','off'].includes(finline) };
        if (campo === 'fieldnew') {
          estado.fields = [...(estado.fields || []), novo];
        } else {
          const idxEdit = parseInt(partes[3], 10);
          if (Number.isNaN(idxEdit) || idxEdit < 0 || idxEdit >= (estado.fields || []).length) {
            return interaction.reply({ content: '❌ Field inválido.', flags: MessageFlags.Ephemeral });
          }
          estado.fields[idxEdit] = novo;
        }
        return interaction.update(buildFieldsPainel(donoId));
      }

      const estado = getSessao(donoId);
      const valor = interaction.fields.getTextInputValue('valor').trim();

      if (campo === 'cargos') {
        // Parse IDs de cargo separados por virgula
        estado.cargos = valor
          ? valor.split(',').map((s) => s.trim()).filter((s) => /^\d+$/.test(s))
          : [];
      } else if (campo === 'fields') {
        // Formato: "Titulo | valor" por linha (robusto: ignora linhas invalidas,
        // trunca para os limites da API e nunca deixa name/value vazios).
        const { camposValidos } = require('./utils/embedPainel');
        const parseados = valor
          .split('\n')
          .map((l) => l.trim())
          .filter(Boolean)
          .map((l) => {
            const [name, ...v] = l.split('|');
            return { name: name.trim(), value: v.join('|').trim(), inline: true };
          });
        const fields = camposValidos(parseados);
        estado.fields = fields;
        if (!fields.length) {
          return interaction.reply({
            content: '❌ Nenhum field válido. Use o formato: `Título | valor` por linha.',
            flags: MessageFlags.Ephemeral,
          });
        }
        return interaction.update(buildPainel(donoId, interaction.guildId));
      } else if (campo === 'imagem' || campo === 'thumbnail') {
        const url = valor || null;
        if (url && !urlValida(url)) {

          return interaction.reply({
            content: `❌ Link de **${campo === 'imagem' ? 'imagem' : 'thumbnail'}** inválido. Use um link completo começando com \`http(s)://\` (ex: \`https://...png\`). Deixe vazio para remover.`,
            flags: MessageFlags.Ephemeral,
          });
        }
        estado[campo] = url;
      } else {
        estado[campo] = valor || null;
      }

      return interaction.update(buildPainel(donoId, interaction.guildId));
    }

    // Seleção de canal para publicar a embed (fluxo do botão "Enviar")
    if ((interaction.isStringSelectMenu() || interaction.isButton()) && interaction.customId.startsWith('embedcanal:')) {
      const partes = interaction.customId.split(':');
      const donoId = partes[1];

      if (interaction.user.id !== donoId) {
        return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
      }
      if (!permitido(interaction)) {
        return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
      }

      if (interaction.isButton() && partes[2] === 'cancelar') {
        return interaction.reply({ content: '❌ Envio cancelado.', flags: MessageFlags.Ephemeral });
      }

      // Defer imediato: o envio no canal pode demorar>3s e o interaction expirar
      // (erro "não respondeu a tempo") sem ack antecipado.

      await interaction.deferUpdate().catch(() => {});
      const responder = async (payload) => {
        try {
          if (interaction.deferred) {
            return await interaction.editReply(payload);
          }
          return await interaction.update(payload);
        } catch {}
      };

      // Canais: seleção (select) ou botão "canal atual"
      let canal = null;
      if (interaction.isStringSelectMenu()) {
        canal = interaction.guild?.channels.cache.get(interaction.values[0]) || null;
      } else if (partes[2] === 'atual') {
        canal = interaction.channel;
      }
      if (!canal) {
        return responder({ content: '❌ Canal não encontrado.', embeds: [], components: [] });
      }

      const estado = getSessao(donoId);
      const embed = buildEmbed(estado);
      const mencoes = estado.cargos.map((c) => `<@&${c}>`).join(' ');
      const conteudo = [estado.textoFora, mencoes].filter(Boolean).join(' ') || null;
      try {
        await canal.send({
          content: conteudo,
          embeds: [embed],
          components: (linhasBotoes = botoesEmLinhas(estado.botoes, interaction.guildId || '', true, estado.cor)).length ? linhasBotoes : [],
          allowedMentions: estado.cargos.length ? { roles: estado.cargos } : { parse: [] },
        });
      } catch (sendError) {
        console.error('[Embed] Falha ao enviar no canal:', sendError?.message || sendError);
        return responder({ content: `❌ Não consegui enviar em <#${canal.id}>. Verifique minha permissão nesse canal.`, embeds: [], components: [] });
      }
      limparSessao(donoId);
      return responder({
        content: `✅ Embed enviada em <#${canal.id}>!`,
        embeds: [],
        components: [],
      });
    }
  } catch (error) {
    console.error('[Embed painel] Erro:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});


// ----- Botões de conteúdo privado (cttopen) -----
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() || !interaction.customId.startsWith('cttopen:')) return;
  try {
    const partesCtt = interaction.customId.split(':');
    const guildId = partesCtt[1];
    const token = partesCtt[2];
    if (!guildId || !token) {
      return interaction.reply({ content: '❌ Botão inválido.', flags: MessageFlags.Ephemeral }).catch(() => {});
    }
    if (interaction.guild && interaction.guild.id !== guildId) {

      return interaction.reply({ content: '❌ Este conteúdo não pode ser aberto neste servidor.', flags: MessageFlags.Ephemeral }).catch(() => {});
    }
    const dados = cttStore.obter(token);
    if (!dados) return interaction.reply({ content: '❌ Conteúdo expirado ou inválido.', flags: MessageFlags.Ephemeral });
    const conteudoPrivado = buildConteudoPrivado(dados.paginas || [], 0, interaction.user.id, guildId, token, dados.cor || null);
    return interaction.reply(conteudoPrivado).catch(() => {});
  } catch (error) {
    console.error('[cttopen] Erro:', error);
   try {
      if (!interaction.replied && !interaction.deferred) {
        return interaction.reply({ content: '❌ Erro ao abrir este conteúdo. Tente novamente.', flags: MessageFlags.Ephemeral }).catch(() => {});
      }
   } catch {}
  }
});



// ----- Painel de modelos de embed (!modelos ///modelos) -----
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() || !interaction.customId.startsWith('modelos:')) return;
  try {
    const partes = interaction.customId.split(':');
    const acao = partes[1];
    const guildId = partes[2];
    const uid = partes[3];
    if (!interaction.guild || interaction.guild.id !== guildId) return;
    if (interaction.user.id !== uid) return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
    const mId = partes[4];
    if (acao === 'voltar') return interaction.update(buildModelosPainel(guildId, uid));
    if (acao === 'cat') return interaction.update(buildCategoriaPainel(guildId, mId, uid));
    if (acao === 'novacat') {
      const modalNova = new ModalBuilder()
        .setCustomId(`modeloscat:nova:${guildId}:${uid}`)
        .setTitle('➕ Nova categoria')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('cname')
              .setLabel('Nome da categoria')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setMaxLength(24)
          )
        );
      return interaction.showModal(modalNova);
    }
    if (acao === 'catedit') {
      const cat = modelosStore.obterCategoria(guildId, mId);
      if (!cat) return interaction.reply({ content: '❌ Categoria não encontrada.', flags: MessageFlags.Ephemeral });
      const modalEdit = new ModalBuilder()
        .setCustomId(`modeloscat:edit:${guildId}:${uid}:${mId}`)
        .setTitle('✏️ Renomear categoria')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('cname')
              .setLabel('Nome da categoria')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setMaxLength(24)
              .setValue(String(cat.nome || '').slice(0, 24))
          )
        );
      return interaction.showModal(modalEdit);
    }
    if (acao === 'catexcluir') {
      const res2 = modelosStore.excluirCategoria(guildId, mId);
      return interaction.update({ content: res2.ok ? '🗑️ Categoria excluída. Modelos movidos para **Sem categoria**.' : '❌ ' + (res2.msg || 'Erro.'), embeds: [], components: [] });
    }
    const modelo = modelosStore.obter(guildId, mId);
    if (!modelo) return interaction.reply({ content: '❌ Modelo não encontrado.', flags: MessageFlags.Ephemeral });
    if (acao === 'ver') {
      const dados = modelo.dados || {};
      const embedVer = buildEmbed(JSON.parse(JSON.stringify(dados)));
      return interaction.reply({ embeds: embedVer ? [embedVer] : [], content: embedVer ? null : '⚠️ Modelo sem conteúdo visível.', components: [], flags: MessageFlags.Ephemeral });
    }
    if (acao === 'usar') {
      const sessao = getSessao(uid);
      const carregado = JSON.parse(JSON.stringify(modelo.dados || {}));
      carregado.botoes = Array.isArray(carregado.botoes) ? carregado.botoes : [];
      carregado.fields = Array.isArray(carregado.fields) ? carregado.fields : [];
      Object.assign(sessao, carregado);
      return interaction.update(buildPainel(uid, interaction.guildId));
    }
    if (acao === 'editar') {
      const modalEd = new ModalBuilder()
        .setCustomId(`embedmodal:modeloed:${mId}:${guildId}:${uid}`)
        .setTitle('✏️ Editar modelo')
        .addComponents(
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('mnome')
              .setLabel('Nome do modelo')
              .setStyle(TextInputStyle.Short)
              .setRequired(true)
              .setMaxLength(80)
              .setValue(String(modelo.nome || '').slice(0, 80))
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('mcategoria')
              .setLabel('Categoria da guild (e.g.: Boas-vindas, Loja)')
              .setStyle(TextInputStyle.Short)
              .setRequired(false)
              .setMaxLength(24)
              .setValue(String(modelo.categoria || 'outros'))
          ),
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId('mdesc')
              .setLabel('Descrição interna (opcional)')
              .setStyle(TextInputStyle.Paragraph)
              .setRequired(false)
              .setMaxLength(1024)
              .setValue(String(modelo.descricao || '').slice(0, 1024))
          ),
        );
      return interaction.showModal(modalEd);
    }
    if (acao === 'excluir') {
      modelosStore.excluir(guildId, mId);
      return interaction.update({ content: `🗑️ Modelo **${modelo.nome}** excluído.`, embeds: [], components: [] });
    }

  } catch (error) {
    console.error('[modelos] Erro:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});

// ----- Modais de categorias de modelos -----
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit() || !interaction.customId.startsWith('modeloscat:')) return;
  try {
    const partes = interaction.customId.split(':');
    const modo = partes[1];
    const guildId = partes[2];
    const uid = partes[3];
    if (interaction.user.id !== uid) return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
    const nome = (interaction.fields.getTextInputValue('cname') || '' ).trim();
    if (!nome) return interaction.reply({ content: '❌ Informe um nome para a categoria.', flags: MessageFlags.Ephemeral });
    if (modo === 'nova') {
      const res = modelosStore.criarCategoria(guildId, nome);
      if (!res.ok) return interaction.reply({ content: '❌ ' + (res.msg || 'Erro ao criar.'), flags: MessageFlags.Ephemeral });
      return interaction.update(buildModelosPainel(guildId, uid));
    }
    if (modo === 'edit') {
      const catId = partes[4];
      const res = modelosStore.editarCategoria(guildId, catId, nome)
      if (!res.ok) return interaction.reply({ content: '❌ ' + (res.msg || 'Erro ao renomear.'), flags: MessageFlags.Ephemeral });
      return interaction.update(buildCategoriaPainel(guildId, catId, uid));
    }
  } catch (error) {
    console.error('[modeloscat] Erro:', error);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({ content: '❌ Ocorreu um erro. Tente novamente.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});


// Responde comandos de prefixo
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  // Auto-respostas por palavra-chave: disparam em qualquer mensagem do chat
  // (sem precisar de prefixo,, somente em servidor e nos canais configurados.


  if (!message.content.startsWith(PREFIX) && message.guild) {

    const autoStore = require('./utils/autoRespostaStore');
    const { acharResposta } = require('./utils/autoRespostaHandler');
    const canaisPermitidos = autoStore.canais(message.guildId);
    const resposta = acharResposta(autoStore.listar(message.guildId), message.content);
    if (resposta) {
      // Canais da resposta tem prioridade; se vazios, usa a lista comum; se
      // ambas vazias, responde em qualquer canal do servidor.

      const canaisDaResposta = Array.isArray(resposta.canais) ? resposta.canais : [];
      const canalPermitido = canaisDaResposta.length
        ? canaisDaResposta.includes(message.channelId)
        : (!canaisPermitidos.length || canaisPermitidos.includes(message.channelId));
      if (canalPermitido) {
        try {
          return await message.channel.send({ content: resposta.resposta || resposta, allowedMentions: { parse: [] } });
        } catch (error) {
          console.error('[Auto resposta]', error);
        }
      }
    }
  }

  if (!message.content.startsWith(PREFIX)) return;


  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const commandName = args.shift().toLowerCase();
  const command = client.prefixCommands.get(commandName);
  // Comandos personalizados: respondem por prefixo (!) e a resposta e publica;
  // apenas o botao copiavel e ephemeral. A descricao curta e so para o menu de ajuda.
  if (!command) {
    const custom = require('./utils/customCommands');
    const { buildResposta } = require('./utils/customCommandsPanel');
    // Comandos personalizados sao por-servidor: so existem no guild em que
    // foram criados (message.guildId). Em DM (ou outro servidor) nao respondem.

    const cmdCustom = message.guild ? custom.obter(message.guildId, commandName) : null;
    if (cmdCustom) {
      try {
        const payload = buildResposta(cmdCustom);
        return await message.reply(payload);
      } catch (error) {
        console.error('[Comando custom !]', error);
        return message.reply('❌ Erro ao executar o comando.');
      }
    }
    return;
  }

  // Restrição de canal: admins/cargos sempre passam; usuário comum pode ser
  // limitado aos canais configurados via !canalcomando (persistidos no store).
  if (message.guild) {
    const { podeUsarNoCanal } = require('./utils/permissions');
    const canaisCheck = podeUsarNoCanal(
      message.channelId,
      message.guildId,
      message.member,
      message.author.id,
      command.name // usa o nome canônico (aliases como !help -> ajuda seguem a mesma regra)
    );
    if (!canaisCheck.ok) {
      return message.reply(canaisCheck.msg);
    }
  }

  try {
    await command.execute(message, args, client);
  } catch (error) {
    console.error(error);
    await message.reply('❌ Ocorreu um erro ao executar este comando.');
  }
});


// ----- Boas-vindas ao entrar no servidor -----
client.on(Events.GuildMemberAdd, async (member) => {
  try {
    const conf = welcomeStore.obter(member.guild.id);
    if (!conf) return;
    if (!conf.ativo) return;
    if (!conf.canalId) return;
    const canal = await client.channels.fetch(conf.canalId).catch(() => null);
    if (!canal) return;
    if (!canal.isTextBased()) return;
    const botMembro = canal.guild?.members?.me;
    const permissoes = canal.permissionsFor(botMembro);
    if (!permissoes || !permissoes.has(PermissionFlagsBits.SendMessages)) return;

    const conteudo = conf.tipo === 'embed' ? null : welcomeVars.interpolar(conf.mensagem || '', member, member.guild);
    const embed = conf.tipo === 'embed' ? welcomePainel.buildWelcomeEmbed(conf, member.displayAvatarURL()) : null;
    if (embed) welcomeVars.interpolarEmbed(embed, member, member.guild);

    await canal.send({
      content: conteudo || undefined,
      embeds: embed ? [embed] : [],
      allowedMentions: { parse: ['users', 'roles', 'everyone'] },
    });
  } catch (error) {
    console.error('[Welcome] Erro:', error);
  }
});


// ----- Painel de configuracao de boas-vindas -----
client.on(Events.InteractionCreate, async (interaction) => {
  try {
    const id = interaction.customId || '';
    if (!id.startsWith('welcome:')) return;

    const partes = id.split(':');
    const acao = partes[1];
    const donoId = partes[partes.length - 1];
    if (interaction.user.id !== donoId) return;

    const sessao = welcomePainel.getSessaoWelcome(
      donoId,
      interaction.guildId
    );
    const conf = sessao.config;
    const responderPainel = () => {
      const painel = welcomePainel.buildWelcomePainel(
        donoId,
        interaction.guildId
      );
      return interaction.update({
        embeds: painel.embeds,
        components: painel.components
      });
    };

    if (interaction.isButton()) {
      if (acao === 'ativar' || acao === 'desativar') {
        conf.ativo = acao === 'ativar';
        return responderPainel();
      }
      if (acao === 'tipo') {
        conf.tipo = conf.tipo === 'embed' ? 'mensagem' : 'embed';
        if (!conf.mensagem) conf.mensagem = welcomeStore.padrao().mensagem;
        return responderPainel();
      }
      if (acao === 'canal') {
        const sel = welcomePainel.canalSelecao(
          interaction.guildId,
          `welcome:canalsel:${donoId}`,
          conf.canalId
        );
        return interaction.update({
          components: [sel.row, sel.botoes]
        });
      }
      if (acao === 'variaveis') {
        return interaction.reply({
          content: welcomeVars.listarVariaveis().join('\\n'),
          flags: MessageFlags.Ephemeral
        });
      }
      if (acao === 'salvar') {
        welcomeStore.salvar(
          interaction.guildId,
          conf
        );
        welcomePainel.limparSessaoWelcome(
          donoId,
          interaction.guildId
        );
        return interaction.reply({
          content: 'Salvo com sucesso.',
          flags: MessageFlags.Ephemeral
        });
      }
      if (acao === 'padrao') {
        const padrao = welcomeStore.padrao(
          conf.canalId
        );
        Object.assign(conf, padrao);
        return responderPainel();
      }
      if (acao === 'preview') {
        const memberExemplo = {
          id: interaction.user.id,
          username: interaction.user.username,
          displayName: interaction.member?.displayName || interaction.user.username,
          displayAvatarURL: () => interaction.user.displayAvatarURL(),
        };
        const conteudo = conf.tipo === 'embed'
          ? null
          : welcomeVars.interpolar(
              conf.mensagem || '',
              memberExemplo,
              interaction.guild
            );
        const embed = conf.tipo === 'embed'
          ? welcomePainel.buildWelcomeEmbed(
              conf,
              interaction.user.displayAvatarURL()
            )
          : null;
        if (embed) {
          welcomeVars.interpolarEmbed(
            embed,
            memberExemplo,
            interaction.guild
          );
        }
        return interaction.reply({
          content: conteudo || 'Pre-visualizacao:',
          embeds: embed ? [embed] : [],
          ephemeral: true,
          allowedMentions: { parse: [] }
        });
      }

if (acao === 'editar') {
        const alvo = partes[2];
        if (alvo === 'mensagem') {
          const modal = welcomePainel.modalCampo(
            donoId,
            'mensagem',
            'Editar mensagem',
            'Mensagem',
            true,
            conf.mensagem || '',
            'Ola, <@user>! Bem-vinda ao <@server>.'
          );
          return interaction.showModal(modal);
        }
        if (alvo === 'embed') {
          const painel = welcomePainel.buildWelcomeEmbedEdit(
            donoId,
            interaction.guildId
          );
          return interaction.update({
            embeds: painel.embeds,
            components: painel.components
          });
        }
      }
      if (acao === 'embed') {
        const campoEd = partes[2];
        if (campoEd === 'voltar') {
          return responderPainel();
        }
        if (campoEd === 'fields') {
          const painel = welcomePainel.buildWelcomeFieldsPainel(
            donoId,
            interaction.guildId
          );
          return interaction.update({
            embeds: painel.embeds,
            components: painel.components
          });
        }
        if (campoEd === 'timestamp') {
          conf.embed.timestamp = !conf.embed.timestamp;
          const painel = welcomePainel.buildWelcomeEmbedEdit(
            donoId,
            interaction.guildId
          );
          return interaction.update({
            embeds: painel.embeds,
            components: painel.components
          });
        }
        const rotulos = {
          titulo: ['Titulo da embed', 'Titulo'],
          descricao: ['Descricao da embed', 'Descricao'],
          cor: ['Cor da embed', 'Cor'],
          imagem: ['URL da imagem', 'Imagem'],
          thumbnail: ['Thumbnail', 'Thumbnail'],
          rodape: ['Texto do rodape', 'Rodape'],
        };
        const confEd = rotulos[campoEd];
        if (!confEd) return;
        const atual = campoEd === 'cor'
          ? (conf.embed.cor || '#beb6ff')
          : (conf.embed[campoEd] || '');
        const placeholder = campoEd === 'cor'
          ? 'Ex: #beb6ff'
          : (campoEd === 'imagem' || campoEd === 'thumbnail')
            ? 'Ex: https://...'
            : 'Aceita variaveis como <user>';
        const modal = welcomePainel.modalCampo(
          donoId,
          campoEd,
          confEd[0],
          confEd[1],
          campoEd === 'descricao' || campoEd === 'mensagem',
          atual,
          placeholder
        );
        return interaction.showModal(modal);
      }
      if (acao === 'fieldadd') {
        return interaction.showModal(
          welcomePainel.modalField(
            donoId
          )
        );
      }
      if (acao === 'fieldclear') {
        conf.embed.fields = [];
        const painel = welcomePainel.buildWelcomeFieldsPainel(
          donoId,
          interaction.guildId
        );
        return interaction.update({
          embeds: painel.embeds,
          components: painel.components
        });
      }
    }

if (interaction.isStringSelectMenu() || interaction.isButton()) {
      if (id.startsWith('welcome:canalsel:')) {
        if (interaction.isButton() && partes[3] === 'cancelar') {
          return responderPainel();
        }
        let canal = null;
        if (interaction.isStringSelectMenu()) {
          canal = interaction.guild?.channels.cache.get(interaction.values[0]) || null;
        } else if (interaction.isButton() && partes[3] === 'atual') {
          canal = interaction.channel;
        }
        if (!canal) {
          return interaction.reply({
            content: 'Canal nao encontrado.',
            flags: MessageFlags.Ephemeral
          });
        }
        conf.canalId = canal.id;
        return responderPainel();
      }
      if (interaction.isStringSelectMenu() && id.startsWith('welcome:fieldsel:')) {
        const idx = parseInt(
          interaction.values[0],
          10
        );
        const campos = (conf.embed.fields || []).filter(
          (f) => f && f.name && f.value
        );
        const campo = campos[idx] || null;
        return interaction.showModal(
          welcomePainel.modalField(
            donoId,
            idx,
            campo
          )
        );
      }
    }

    if (interaction.isModalSubmit() && id.startsWith('welcome:modal:')) {
      const alvo = partes[2];

      if (alvo === 'mensagem') {
        conf.mensagem = interaction.fields.getTextInputValue(
          'valor'
        );
        return responderPainel();
      }

      if (alvo === 'titulo' || alvo === 'descricao' || alvo === 'cor' || alvo === 'imagem' || alvo === 'thumbnail' || alvo === 'rodape') {
        const valor = interaction.fields.getTextInputValue(
          'valor'
        ).trim();
        if (alvo === 'cor' && valor && !/^#?[0-9a-fA-F]{6}$/.test(
          valor
        )) {
          return interaction.reply({
            content: 'Cor invalida.',
            flags: MessageFlags.Ephemeral
          });
        }
        if ((alvo === 'imagem' || alvo === 'thumbnail') && valor && !(valor.startsWith('http://') || valor.startsWith('https://'))) {
          return interaction.reply({
            content: 'URL invalida.',
            flags: MessageFlags.Ephemeral
          });
        }
        conf.embed[alvo] = valor || null;
        const painel = welcomePainel.buildWelcomeEmbedEdit(
          donoId,
          interaction.guildId
        );
        return interaction.update({
          embeds: painel.embeds,
          components: painel.components
        });
      }

      if (alvo === 'fieldnew' || alvo === 'fieldedit') {
        const nome = interaction.fields.getTextInputValue(
          'fname'
        ).trim();
        const valor = interaction.fields.getTextInputValue(
          'fvalue'
        ).trim();
        const inlineL = interaction.fields.getTextInputValue(
          'finline'
        ).trim().toLowerCase();
        if (!nome || !valor) {
          return interaction.reply({
            content: 'Nome e valor obrigatorios.',
            flags: MessageFlags.Ephemeral
          });
        }
        const novoCampo = {
          name: nome,
          value: valor,
          inline: inlineL === 'sim',
        };
        if (alvo === 'fieldnew') {
          conf.embed.fields.push(
            novoCampo
          );
        } else {
          const idx = parseInt(
            partes[4],
            10
          );
          if (idx >=   0 && idx < conf.embed.fields.length) {
            conf.embed.fields[idx] = novoCampo;
          }
        }
        const painel = welcomePainel.buildWelcomeFieldsPainel(
          donoId,
          interaction.guildId
        );
        return interaction.update({
          embeds: painel.embeds,
          components: painel.components
        });
      }
    }
  } catch (error) {
    console.error('[Welcome Painel] Erro:', error);
    try {
      if (interaction.isRepliable()) {
        if (interaction.deferred || interaction.replied) return;
        return interaction.reply({
          content: 'Erro ao processar o painel.',
          flags: MessageFlags.Ephemeral
        });
      }
    } catch {}
  }
});


// ----- Compra: painel /comprar, pedidos, confirmacao/cancelamento e metas -----
const { escolherCategoria, escolherProduto, escolherQuantidade, modalQuantidade, montarCarrinho, editarItemCarrinho, finalizarCarrinho, mensagemPedido, confirmacaoCancelamento, itensDoPedido, logDoPedido } = require('./utils/comprarPanel');
const carrinhoStore = require('./utils/carrinhoStore');
const pedidoStore = require('./utils/pedidoStore');
const pedidoComprasStore = require('./utils/pedidoComprasStore');
const estoqueCompras = require('./utils/estoque');
const comprasStore = require('./utils/comprasStore');
const logComprasStore = require('./utils/logComprasStore');
const proofStore = require('./utils/proofStore');
const { buildProofModal, buildProofFormulario, modalClientePlataforma, salvarFluxo, obterFluxo, limparFluxo } = require('./utils/proofModal');
const metasStoreCompra = require('./utils/metasStore');
const { buildMetasPainel, telaEscolherCargo, telaEscolherTipo } = require('./utils/metasPanel');

async function cargoDaInteracao(interaction, roleId) {
  let role = interaction.guild?.roles?.cache?.get(roleId) || null;
  if (!role && interaction.guild?.roles?.fetch) {
    try { role = await interaction.guild.roles.fetch(roleId).catch(() => null); } catch { role = null; }
  }
  return role;
}

// Avaliação das metas e concessão dos cargos: lógica compartilhada com o
// lançamento manual de venda (!venda / /venda) em src/utils/metasVenda.js.
const { metasConquistadas, concederCargosDasMetas } = require('./utils/metasVenda');

client.on('interactionCreate', async (interaction) => {
  try {
    const id = interaction.customId || '';
    if (!id.startsWith('comp:') && !id.startsWith('metaspainel:') && !id.startsWith('metasmodal:')) return;

    const partes = id.split(':');
    const acao = partes[1];
    const guildId = interaction.guildId || '';

    // ----- Painel de compra (/comprar) -----
    if (id.startsWith('comp:')) {
      if (!interaction.guild) {
        return interaction.reply({ content: '❌ Isso só funciona no servidor.', flags: MessageFlags.Ephemeral });
      }

      // O painel e publico no ticket, mas so o cliente que iniciou pode alterar
      // o carrinho. O dono vem da referencia registrada no /comprar (sem criar
      // novo sistema de permissao). Painel sem dono registrado nao e de ninguem.
      //
      // So as acoes que EDITAM a mensagem compartilhada do painel precisam do
      // dono (evita um intruso trocar o painel do cliente). addcarrinho/
      // modaldigitar sao auto-escopados (modal do proprio usuario).
      const msgIdAtual = interaction.message?.id || null;
      const donoPainel = carrinhoStore.donoDoPainel(guildId, msgIdAtual);
      const acoesDoDono = ['cat', 'voltar', 'prod', 'carrinho', 'removeritem', 'iteditar', 'limpar', 'finalizar', 'qtd', 'qmais', 'qmenos', 'qrem', 'selcat', 'selprod', 'catpag', 'prodpag'];
      if (acoesDoDono.includes(acao)) {
        if (!donoPainel) {
          return interaction.reply({
            content: '🔒 Não foi possível identificar o dono deste carrinho. Abra o painel novamente com `/comprar`.',
            flags: MessageFlags.Ephemeral,
          });
        }
        if (donoPainel !== interaction.user.id) {
          return interaction.reply({
            content: '🔒 Este carrinho pertence a outro usuário. Você pode visualizar, mas não alterar.',
            flags: MessageFlags.Ephemeral,
          });
        }
      }

      // Publica o carrinho no ticket: edita a propria mensagem do painel
      // (sem spam de mensagens). O modal nao pode editar, entao responde uma
      // nova mensagem publica e passa a referencia-la.
      async function publicarCarrinho() {
        const conteudo = montarCarrinho(guildId, interaction.user.id);
        if (interaction.isModalSubmit()) {
          const enviada = await interaction.reply({ ...conteudo, fetchReply: true });
          carrinhoStore.setRef(guildId, interaction.user.id, interaction.channelId, enviada.id);
          return;
        }
        await interaction.update(conteudo);
        carrinhoStore.setRef(guildId, interaction.user.id, interaction.channelId, interaction.message?.id || null);
      }

      if (acao === 'cat') {
        return interaction.update(escolherProduto(guildId, partes[2], interaction.user.id));
      }
      if (acao === 'voltar') {
        return interaction.update(escolherCategoria(guildId, interaction.user.id));
      }
      if (acao === 'prod') {
        return interaction.update(escolherQuantidade(guildId, partes[2], partes[3]));
      }

      // ----- Menus de seleção (categoria/produto) -----
      if (acao === 'selcat') {
        const catId = (interaction.values || [])[0] || null;
        if (!catId) {
          return interaction.reply({ content: '❌ Categoria inválida.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update(escolherProduto(guildId, catId, interaction.user.id));
      }
      if (acao === 'selprod') {
        const catId = partes[2];
        const prodId = (interaction.values || [])[0] || null;
        if (!catId || !prodId) {
          return interaction.reply({ content: '❌ Produto inválido.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update(escolherQuantidade(guildId, catId, prodId));
      }
      if (acao === 'catpag') {
        return interaction.update(escolherCategoria(guildId, interaction.user.id, parseInt(partes[2] || '0', 10)));
      }
      if (acao === 'prodpag') {
        return interaction.update(escolherProduto(guildId, partes[2], interaction.user.id, parseInt(partes[3] || '0', 10)));
      }

      // ----- Carrinho -----
      if (acao === 'carrinho') {
        return interaction.update(montarCarrinho(guildId, interaction.user.id));
      }
      if (acao === 'rem') {
        carrinhoStore.remover(guildId, interaction.user.id, partes[2], partes[3]);
        return interaction.update(montarCarrinho(guildId, interaction.user.id));
      }
      // Select do carrinho (formato atual): seleciona o item e abre as acoes.
      if (acao === 'iteditar') {
        const escolhido = String(interaction.values?.[0] || '');
        const [catId, prodId] = escolhido.split(':');
        if (!catId || !prodId) {
          return interaction.reply({ content: '❌ Item inválido.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update(editarItemCarrinho(guildId, interaction.user.id, catId, prodId));
      }
      // Select antigo (mensagens ja publicadas nos tickets): remove o item.
      if (acao === 'removeritem') {
        const escolhido = String(interaction.values?.[0] || '');
        const [catId, prodId] = escolhido.split(':');
        if (!catId || !prodId) {
          return interaction.reply({ content: '❌ Item inválido.', flags: MessageFlags.Ephemeral });
        }
        carrinhoStore.remover(guildId, interaction.user.id, catId, prodId);
        return publicarCarrinho();
      }

      // ----- Editar a quantidade de um item do carrinho -----
      // A reserva de estoque continua acontecendo so em comp:finalizar.
      if (acao === 'qmais' || acao === 'qmenos') {
        const catId = partes[2];
        const prodId = partes[3];
        const p = estoqueCompras.produto(guildId, catId, prodId);
        if (!p || !p.ativo) {
          return interaction.reply({ content: '❌ Produto não encontrado ou desativado.', flags: MessageFlags.Ephemeral });
        }
        if (acao === 'qmais' && p.controlarQtd) {
          // Disponivel ja desconta as reservas pendentes; somamos o que o proprio
          // cliente ja tem no carrinho para validar a nova quantidade.
          const noCarrinho = carrinhoStore.quantidadeNoCarrinho(guildId, interaction.user.id, catId, prodId);
          const disponivel = pedidoStore.disponivel(guildId, p, catId, prodId);
          if (disponivel !== null && noCarrinho + 1 > disponivel) {
            return interaction.update(editarItemCarrinho(
              guildId, interaction.user.id, catId, prodId,
              '❌ Estoque insuficiente para adicionar essa quantidade.'
            ));
          }
        }
        const r = carrinhoStore.alterarQuantidade(guildId, interaction.user.id, catId, prodId, acao === 'qmais' ? 1 : -1);
        if (!r.ok && r.motivo === 'minimo') {
          return interaction.update(editarItemCarrinho(
            guildId, interaction.user.id, catId, prodId,
            '❌ A quantidade mínima é 1. Para retirar o produto, use 🗑️ **Remover produto**.'
          ));
        }
        if (!r.ok) {
          return interaction.update(montarCarrinho(guildId, interaction.user.id));
        }
        return interaction.update(editarItemCarrinho(guildId, interaction.user.id, catId, prodId));
      }
      if (acao === 'qrem') {
        carrinhoStore.remover(guildId, interaction.user.id, partes[2], partes[3]);
        return publicarCarrinho();
      }
      if (acao === 'limpar') {
        carrinhoStore.limpar(guildId, interaction.user.id);
        return publicarCarrinho();
      }
      if (acao === 'addcarrinho') {
        const catId = partes[2];
        const prodId = partes[3];
        const p = estoqueCompras.produto(guildId, catId, prodId);
        if (!p) {
          return interaction.reply({ content: '❌ Produto não encontrado.', flags: MessageFlags.Ephemeral });
        }
        // Abre modal de quantidade para adicionar ao carrinho
        return interaction.showModal(modalQuantidade(catId, prodId, interaction.user.id));
      }

      if (acao === 'finalizar') {
        const itens = carrinhoStore.listar(guildId, interaction.user.id);
        if (!itens.length) {
          return interaction.reply({ content: '❌ Seu carrinho está vazio.', flags: MessageFlags.Ephemeral });
        }
        const pedido = finalizarCarrinho(guildId, interaction.user.id, interaction.user.globalName || interaction.user.username || null);
        if (!pedido) {
          return interaction.reply({ content: '❌ Não foi possível finalizar: itens podem ter ficado sem estoque ou desativados.', flags: MessageFlags.Ephemeral });
        }

        // O pedido continua sendo registrado no canal de logs (historico).
        const logCriado = logDoPedido(pedido, { acao: 'criado' });
        logComprasStore.enviar(interaction.client, guildId, logCriado);

        // O pedido aparece no ticket (publico): reaproveita a mensagem do carrinho.
        const conteudoPedido = mensagemPedido(guildId, pedido, interaction.channelId);
        await interaction.update(conteudoPedido).catch(async () => {
          await interaction.reply({ ...conteudoPedido, fetchReply: true }).catch(() => {});
        });
        carrinhoStore.setRef(guildId, interaction.user.id, null, null);
        return;
      }

      // Modal de quantidade personalizada (adicionar ao carrinho)
      if (interaction.isModalSubmit() && acao === 'modaldigitar') {
        const catId = partes[2];
        const prodId = partes[3];
        const qtd = parseInt(interaction.fields.getTextInputValue('quantidade'), 10) || 0;
        const p = estoqueCompras.produto(guildId, catId, prodId);
        if (!p || !p.ativo || qtd <= 0) {
          return interaction.reply({ content: '❌ Produto indisponível ou quantidade inválida.', flags: MessageFlags.Ephemeral });
        }
        const jaNoCarrinho = carrinhoStore.listar(guildId, interaction.user.id)
          .filter((i) => i.catId === catId && i.prodId === prodId)
          .reduce((acc, i) => acc + i.quantidade, 0);
        if (p.controlarQtd && pedidoStore.disponivel(guildId, p, catId, prodId) < jaNoCarrinho + qtd) {
          return interaction.reply({ content: '❌ Estoque insuficiente agora.', flags: MessageFlags.Ephemeral });
        }
        carrinhoStore.adicionar(guildId, interaction.user.id, {
          catId,
          prodId,
          nome: p.nome,
          quantidade: qtd,
          valorUnitario: p.valor || 0,
        });
        return publicarCarrinho();
      }

      if (acao === 'qtd') {
        const catId = partes[2];
        const prodId = partes[3];
        const qtd = parseInt(partes[4], 10) || 0;
        const p = estoqueCompras.produto(guildId, catId, prodId);
        if (!p || !p.ativo || qtd <= 0) {
          return interaction.reply({ content: '❌ Produto indisponível ou quantidade inválida.', flags: MessageFlags.Ephemeral });
        }
        // Valida somando o que ja esta no carrinho: a reserva de estoque so
        // acontece na finalizacao, entao a checagem aqui usa o disponivel atual.
        const jaNoCarrinho = carrinhoStore.listar(guildId, interaction.user.id)
          .filter((i) => i.catId === catId && i.prodId === prodId)
          .reduce((acc, i) => acc + i.quantidade, 0);
        if (p.controlarQtd && pedidoStore.disponivel(guildId, p, catId, prodId) < jaNoCarrinho + qtd) {
          return interaction.reply({ content: '❌ Estoque insuficiente agora. A quantidade reservada pode ter mudado. Tente novamente.', flags: MessageFlags.Ephemeral });
        }
        // Adiciona ao carrinho em vez de criar o pedido imediatamente.
        // A finalização (e a reserva de estoque) só acontece em comp:finalizar.
        carrinhoStore.adicionar(guildId, interaction.user.id, {
          catId,
          prodId,
          nome: p.nome,
          quantidade: qtd,
          valorUnitario: p.valor || 0,
        });
        return publicarCarrinho();
      }

      // ----- Cancelar pedido (pede confirmacao antes) -----
      if (acao === 'cancelar') {
        if (!comandoPode(interaction.member, interaction.user.id, 'comprar')) {
          return interaction.reply({
            content: '🔒 Somente administradores ou equipe autorizada podem confirmar ou cancelar pedidos.',
            flags: MessageFlags.Ephemeral,
          });
        }
        const pedido = pedidoStore.obter(guildId, partes[2]);
        if (!pedido) {
          return interaction.reply({ content: '❌ Pedido não encontrado.', flags: MessageFlags.Ephemeral });
        }
        if (pedido.status !== 'pendente') {
          return interaction.reply({
            content: '❌ Este pedido já foi processado (não é mais possível alterá-lo).',
            flags: MessageFlags.Ephemeral,
          });
        }
        return interaction.update(confirmacaoCancelamento(pedido.id));
      }

      // Volta da confirmacao para o pedido, sem cancelar.
      if (acao === 'voltcanc') {
        const pedido = pedidoStore.obter(guildId, partes[2]);
        if (!pedido) {
          return interaction.reply({ content: '❌ Pedido não encontrado.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update(mensagemPedido(guildId, pedido, interaction.channelId));
      }

      // Cancelamento confirmado: libera a reserva (pedido deixa de ser pendente).
      if (acao === 'confcanc') {
        if (!comandoPode(interaction.member, interaction.user.id, 'comprar')) {
          return interaction.reply({
            content: '🔒 Somente administradores ou equipe autorizada podem confirmar ou cancelar pedidos.',
            flags: MessageFlags.Ephemeral,
          });
        }
        const pedidoId = partes[2];
        const pedido = pedidoStore.obter(guildId, pedidoId);
        if (!pedido) {
          return interaction.reply({ content: '❌ Pedido não encontrado.', flags: MessageFlags.Ephemeral });
        }
        if (pedido.status !== 'pendente') {
          return interaction.reply({
            content: '❌ Este pedido já foi processado (não é mais possível alterá-lo).',
            flags: MessageFlags.Ephemeral,
          });
        }
        pedidoStore.atualizar(guildId, pedidoId, {
          status: 'cancelado',
          canceladoEm: Date.now(),
          canceladoPor: interaction.user.id,
        });
        const logCancelado = logDoPedido(pedido, { acao: 'cancelado', por: interaction.user.id });
        logComprasStore.enviar(interaction.client, guildId, logCancelado);
        return interaction.update(mensagemPedido(guildId, pedidoStore.obter(guildId, pedidoId), interaction.channelId));
      }

      // ----- Confirmacao do pagamento (uma unica vez) -----
      if (acao === 'confirmar') {
        if (!comandoPode(interaction.member, interaction.user.id, 'comprar')) {
          return interaction.reply({
            content: '🔒 Somente administradores ou equipe autorizada podem confirmar ou cancelar pedidos.',
            flags: MessageFlags.Ephemeral,
          });
        }
        const pedidoId = partes[2];
        const pedido = pedidoStore.obter(guildId, pedidoId);
        if (!pedido) {
          return interaction.reply({ content: '❌ Pedido não encontrado.', flags: MessageFlags.Ephemeral });
        }
        if (pedido.status !== 'pendente') {
          return interaction.reply({
            content: '❌ Este pedido já foi processado (não é mais possível alterá-lo).',
            flags: MessageFlags.Ephemeral,
          });
        }

        // Dar cargo/metas envolve buscar membro e adicionar cargo (rede); pode
        // passar dos 3s. Responde já e edita a mensagem depois.
        await interaction.deferUpdate().catch(() => {});

        // Baixa de estoque conforme a logica existente, item por item.
        let semEstoque = false;
        for (const item of itensDoPedido(pedido)) {
          const produto = estoqueCompras.produto(guildId, item.catId, item.prodId);
          if (!produto || !produto.controlarQtd) continue;
          const reservadosOutros = pedidoStore.reservado(guildId, item.catId, item.prodId) - item.quantidade;
          const disponivelReal = (produto.quantidade || 0) - reservadosOutros;
          if (disponivelReal < item.quantidade) { semEstoque = true; break; }
          estoqueCompras.setQuantidade(guildId, item.catId, item.prodId, (produto.quantidade || 0) - item.quantidade);
        }
        if (semEstoque) {
          return interaction.editReply({
            content: '❌ Estoque insuficiente para este pedido agora. Peça ao cliente para aguardar reposição ou cancele o pedido.',
            components: [],
          }).catch(() => {});
        }

        const conquistadas = metasConquistadas(guildId, pedido.clienteId, pedido.valor);
        comprasStore.registrarVenda(guildId, pedido.clienteId, pedido.valor, conquistadas.map((m) => m.cargoNome || `<@&${m.cargoId}>`));
        pedidoStore.atualizar(guildId, pedidoId, {
          status: 'confirmado',
          confirmadoEm: Date.now(),
          confirmadoPor: interaction.user.id,
        });
        const logConfirmado = logDoPedido(pedido, { acao: 'confirmado', por: interaction.user.id });
        logComprasStore.enviar(interaction.client, guildId, logConfirmado);

        // Adiciona os cargos conquistados(acumulativo, sem remover nenhum)
        await concederCargosDasMetas(
          interaction.client,
          interaction.guild,
          guildId,
          pedido.clienteId,
          conquistadas,
          pedido.clienteTag
        );

        return interaction.editReply(mensagemPedido(guildId, pedidoStore.obter(guildId, pedidoId), interaction.channelId)).catch(() => {});
      }

      return interaction.reply({ content: '❌ Ação desconhecida.', flags: MessageFlags.Ephemeral });
    }

    // ----- Painel de metas (/metas) -----
    const userId = partes[partes.length - 1];
    if (interaction.user.id !== userId) {
      return interaction.reply({ content: '🔒 Este painel não é seu.', flags: MessageFlags.Ephemeral });
    }
    if (!comandoPode(interaction.member, interaction.user.id, 'metas')) {
      return interaction.reply({ content: '🔒 Somente administradores ou equipe autorizada.', flags: MessageFlags.Ephemeral });
    }
    if (!interaction.guild) {
      return interaction.reply({ content: '❌ Isso só funciona no servidor.', flags: MessageFlags.Ephemeral });
    }

    if (id.startsWith('metaspainel:')) {
      if (acao === 'add') {
        return interaction.update(telaEscolherCargo(interaction.guild, userId, 'add', ''));
      }
      if (acao === 'edit') {
        const metaId = partes[2];
        const meta = metasStoreCompra.meta(guildId, metaId);
        if (!meta) {
          return interaction.reply({ content: '❌ Meta não encontrada.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update(telaEscolherCargo(interaction.guild, userId, 'edit', metaId, meta.cargoId));
      }
      if (acao === 'rm') {
        metasStoreCompra.removerMeta(guildId, partes[2]);
        return interaction.update(buildMetasPainel(interaction.guild, userId));
      }
      if (acao === 'refresh') {
        return interaction.update(buildMetasPainel(interaction.guild, userId));
      }
      if (acao === 'cancel') {
        return interaction.update(buildMetasPainel(interaction.guild, userId));
      }

      if (interaction.isRoleSelectMenu() && acao === 'role') {
        const modo = partes[2];
        const metaId = modo === 'edit' ? partes[3] : '';
        const roleId = interaction.values[0];
        const role = await cargoDaInteracao(interaction, roleId);
        if (!role) {
          return interaction.reply({ content: '❌ Cargo não encontrado neste servidor.', flags: MessageFlags.Ephemeral });
        }
        return interaction.update(telaEscolherTipo(interaction.guild, userId, modo, metaId, role.id, role.name));
      }

      if (interaction.isStringSelectMenu() && acao === 'tipo') {
        const modo = partes[2];
        const metaId = modo === 'edit' ? partes[3] : '';
        const roleId = partes[partes.length - 2];
        const tipo = interaction.values[0];
        const modal = new ModalBuilder()
          .setCustomId(`metasmodal:${modo}:${tipo}:${metaId}:${roleId}:${userId}`)
          .setTitle(modo === 'edit' ? '✏️ Editar meta' : '➕ Nova meta')
          .addComponents(
            new ActionRowBuilder().addComponents(
              new TextInputBuilder()
                .setCustomId('meta')
                .setLabel(tipo === 'valor' ? 'Valor total gasto (R$)' : 'Quantidade de vendas')
                .setPlaceholder(tipo === 'valor' ? 'Ex:  50' : 'Ex:  10')
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
            )
          );
        if (modo === 'edit') {
          const metaAtual = metasStoreCompra.meta(guildId, metaId);
          if (metaAtual) modal.components[0].components[0].setValue(String(metaAtual.meta));
        }
        return interaction.showModal(modal);
      }
    }

    if (interaction.isModalSubmit() && id.startsWith('metasmodal:')) {
      const modo = partes[1];
      const tipo = partes[2] === 'valor' ? 'valor' : 'vendas';
      const metaId = modo === 'edit' ? partes[3] : '';
      const roleId = partes[partes.length - 2];
      const role = await cargoDaInteracao(interaction, roleId);
      if (!role) {
        return interaction.reply({ content: '❌ Cargo não encontrado neste servidor.', flags: MessageFlags.Ephemeral });
      }
      const bruto = interaction.fields.getTextInputValue('meta').trim().replace(/\./g, '').replace(/,/g, '.')
      const metaNum = parseFloat(bruto);
      if (isNaN(metaNum) || metaNum <=  0) {
        return interaction.reply({ content: '❌ Meta inválida. Informe um número maior que zero.', flags: MessageFlags.Ephemeral });
      }

      if (modo === 'edit') {
        metasStoreCompra.atualizarMeta(guildId, metaId, {
          cargoId: role.id,
          cargoNome: role.name,
          tipo,
          meta: metaNum,
        });
      } else {
        metasStoreCompra.addMeta(guildId, {
          cargoId: role.id,
          cargoNome: role.name,
          tipo,
          meta: metaNum,
        });
      }
      return interaction.update(buildMetasPainel(interaction.guild, userId));
    }
  } catch (error) {
    console.error('[Comprar/Metas] Erro na interação:', error?.message || error);
    try {
      if (interaction.isRepliable()) {
        if (interaction.deferred || interaction.replied) return;
        return interaction.reply({ content: '❌ Ocorreu um erro ao processar esta interação.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});


// ----- Encomendas (/encomenda) -----
// Fluxo SEPARADO do /comprar: listener proprio (customId `enc:`), sem tocar em
// nada do fluxo de compras. Nao reserva/baixa estoque e nao registra venda.
const { escolherCategoria: encCategoria, escolherProduto: encProduto, escolherQuantidade: encQuantidade, resumoEncomenda, mensagemEncomenda, confirmacaoCancelamentoEncomenda, logDaEncomenda } = require('./utils/encomendaPanel');
const encomendaStore = require('./utils/encomendaStore');

client.on('interactionCreate', async (interaction) => {
  try {
    const id = interaction.customId || '';
    if (!id.startsWith('enc:')) return;

    const partes = id.split(':');
    const acao = partes[1];
    const guildId = interaction.guildId || '';

    if (!interaction.guild) {
      return interaction.reply({ content: '❌ Isso só funciona no servidor.', flags: MessageFlags.Ephemeral });
    }

    // Acoes administrativas: mesma permissao de vendas/pedidos do /comprar
    // (grupo `vendas`), verificada A CADA clique — nao apenas quando o painel
    // foi criado. O cliente nao consegue iniciar/receber/entregar/cancelar.
    const acoesEquipe = ['iniciar', 'recebido', 'entregar', 'cancelar', 'confcanc'];
    if (acoesEquipe.includes(acao)) {
      if (!comandoPode(interaction.member, interaction.user.id, 'comprar')) {
        return interaction.reply({
          content: '🔒 Somente administradores ou equipe autorizada podem gerenciar encomendas.',
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    // Acoes de edicao do painel publico: so quem iniciou o /encomenda pode
    // navegar/confirmar (painel sem dono registrado nao pertence a ninguem).
    const msgIdAtual = interaction.message?.id || null;
    const acoesDoDono = ['cat', 'prod', 'voltar', 'qtd', 'conf'];
    if (acoesDoDono.includes(acao)) {
      const dono = encomendaStore.donoDoPainel(guildId, msgIdAtual);
      if (!dono) {
        return interaction.reply({
          content: '🔒 Não foi possível identificar o dono desta encomenda. Abra o painel novamente com `/encomenda`.',
          flags: MessageFlags.Ephemeral,
        });
      }
      if (dono !== interaction.user.id) {
        return interaction.reply({
          content: '🔒 Esta encomenda pertence a outro usuário. Você pode visualizar, mas não alterar.',
          flags: MessageFlags.Ephemeral,
        });
      }
    }

    // ----- Navegacao de criacao -----
    if (acao === 'cat') return interaction.update(encProduto(guildId, partes[2]));
    if (acao === 'voltar') return interaction.update(encCategoria(guildId));
    if (acao === 'prod') return interaction.update(encQuantidade(guildId, partes[2], partes[3]));

    if (acao === 'qtd') {
      const catId = partes[2];
      const prodId = partes[3];
      const qtd = parseInt(partes[4], 10);
      const p = estoqueCompras.produto(guildId, catId, prodId);
      if (!p || !p.ativo || !Number.isFinite(qtd) || qtd < 1) {
        return interaction.reply({ content: '❌ Item indisponível ou quantidade inválida.', flags: MessageFlags.Ephemeral });
      }
      const resumo = resumoEncomenda(guildId, { catId, prodId, quantidade: qtd, clienteId: interaction.user.id });
      if (!resumo) return interaction.update(encCategoria(guildId));
      return interaction.update(resumo);
    }

    // ----- Confirmar a encomenda (cria o registro publico no ticket) -----
    if (acao === 'conf') {
      const catId = partes[2];
      const prodId = partes[3];
      const qtd = parseInt(partes[4], 10);
      const p = estoqueCompras.produto(guildId, catId, prodId);
      if (!p || !p.ativo || !Number.isFinite(qtd) || qtd < 1) {
        return interaction.reply({ content: '❌ Item indisponível ou quantidade inválida.', flags: MessageFlags.Ephemeral });
      }
      const enc = encomendaStore.criar(guildId, {
        clienteId: interaction.user.id,
        clienteTag: interaction.user.globalName || interaction.user.username || null,
        catId,
        prodId,
        itemNome: p.nome,
        quantidade: qtd,
        valorUnitario: p.valor || 0,
        canalId: interaction.channelId,
        msgId: interaction.message?.id || null,
      });
      await interaction.update(mensagemEncomenda(guildId, enc));
      logComprasStore.enviar(interaction.client, guildId, logDaEncomenda(enc, { acao: 'criada' }));
      return;
    }

    // ----- Etapas da equipe -----
    if (acao === 'iniciar' || acao === 'recebido' || acao === 'entregar') {
      const encId = partes[2];
      const enc = encomendaStore.obter(guildId, encId);
      if (!enc) return interaction.reply({ content: '❌ Encomenda não encontrada.', flags: MessageFlags.Ephemeral });
      // Cada acao so vale na etapa correspondente (impede pular/inverter etapas).
      const esperado = { iniciar: 'aguardando', recebido: 'em_andamento', entregar: 'item_recebido' }[acao];
      if (enc.status !== esperado) {
        return interaction.reply({ content: '❌ Esta ação não corresponde ao estado atual da encomenda.', flags: MessageFlags.Ephemeral });
      }
      const r = encomendaStore.avancar(guildId, encId, interaction.user.id);
      if (!r.ok) return interaction.reply({ content: '❌ Não foi possível avançar esta encomenda.', flags: MessageFlags.Ephemeral });
      await interaction.update(mensagemEncomenda(guildId, r.encomenda));
      const evento = { iniciar: 'iniciada', recebido: 'recebida', entregar: 'entregue' }[acao];
      logComprasStore.enviar(interaction.client, guildId, logDaEncomenda(r.encomenda, { acao: evento, por: interaction.user.id }));
      return;
    }

    // ----- Cancelamento (com confirmacao) -----
    if (acao === 'cancelar') {
      const enc = encomendaStore.obter(guildId, partes[2]);
      if (!enc) return interaction.reply({ content: '❌ Encomenda não encontrada.', flags: MessageFlags.Ephemeral });
      if (enc.status === 'cancelada' || enc.status === 'entregue') {
        return interaction.reply({ content: '❌ Esta encomenda já foi finalizada (não é mais possível alterá-la).', flags: MessageFlags.Ephemeral });
      }
      return interaction.update(confirmacaoCancelamentoEncomenda({ ...enc, guildId }));
    }
    if (acao === 'voltcanc') {
      const enc = encomendaStore.obter(guildId, partes[2]);
      if (!enc) return interaction.reply({ content: '❌ Encomenda não encontrada.', flags: MessageFlags.Ephemeral });
      return interaction.update(mensagemEncomenda(guildId, enc));
    }
    if (acao === 'confcanc') {
      const encId = partes[2];
      const r = encomendaStore.cancelar(guildId, encId, interaction.user.id);
      if (!r.ok) {
        const msg = r.motivo === 'ja_cancelada' ? '❌ Esta encomenda já foi cancelada.'
          : r.motivo === 'ja_entregue' ? '❌ Esta encomenda já foi entregue.'
            : '❌ Encomenda não encontrada.';
        return interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
      }
      await interaction.update(mensagemEncomenda(guildId, r.encomenda));
      logComprasStore.enviar(interaction.client, guildId, logDaEncomenda(r.encomenda, { acao: 'cancelada', por: interaction.user.id }));
      return;
    }

    return interaction.reply({ content: '❌ Ação desconhecida.', flags: MessageFlags.Ephemeral });
  } catch (error) {
    console.error('[Encomenda] Erro na interação:', error?.message || error);
    try {
      if (interaction.isRepliable() && !interaction.deferred && !interaction.replied) {
        return interaction.reply({ content: '❌ Ocorreu um erro ao processar esta interação.', flags: MessageFlags.Ephemeral });
      }
    } catch {}
  }
});
extrasHandlers.registrar(client);
const customEditHandlers = require('./utils/customEditHandler');
customEditHandlers.registrar(client);

// Sem o intent GuildMembers, guild.members.me fica vazio até um fetch. Buscar
// só o próprio bot por servidor preenche o cache sem baixar a lista completa
// de membros.
client.once('ready', () => {
  console.log(`✅ Bot on-line como ${client.user?.tag} em ${client.guilds.cache.size} servidores.`);
  const botId = client.user?.id;
  if (!botId) return;
  for (const guild of client.guilds.cache.values()) {
    guild.members.fetch(botId).catch(() => {});
  }
});

client.login(process.env.DISCORD_TOKEN).catch((error) => {
  const codigo = error?.code || error?.message || error;
  if (codigo === 'TokenInvalid' || String(codigo).includes('TokenInvalid')) {
    console.error('❌ DISCORD_TOKEN inválido ou expirado. Gere um token novo no Developer Portal e atualize a variável DISCORD_TOKEN na Discloud.');
  } else if (codigo === 'DisallowedIntents') {
    console.error('❌ Intents privilegiadas desativadas. Ative "Message Content Intent" no Developer Portal.');
  } else {
    console.error('❌ Falha ao conectar no Discord:', codigo);
  }
  logErroRotulo('login', error);
  // Sai com código != 0 para a Discloud marcar a app como falha e reiniciar.
  process.exit(1);
});
