const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { comandoPode } = require('../utils/permissions');
const { definir } = require('../utils/avisos');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('canalavisos')
    .setDescription('Define o canal de avisos de estoque esgotado (admin)')
    .addChannelOption((option) =>
      option
        .setName('canal')
        .setDescription('Canal onde os avisos serão enviados')
        .setRequired(false)
    ),

  async execute(interaction) {
    if (!interaction.guild || !comandoPode(interaction.member, interaction.user.id, 'canalavisos')) {
      return interaction.reply({ content: '🔒 Somente administradores.', flags: MessageFlags.Ephemeral });
    }

    const canal = interaction.options.getChannel('canal') || interaction.channel;
    if (!canal || !canal.isTextBased() || !canal.isSendable?.()) {
      return interaction.reply({ content: `❌ ${canal ? 'Este canal não é de texto.' : 'Canal inválido.'} Use um canal de texto.`, flags: MessageFlags.Ephemeral });
    }
    definir(interaction.guildId, canal.id);
    return interaction.reply({ content: `✅ Avisos de estoque serão enviados em ${canal}.`, flags: MessageFlags.Ephemeral });
  },
};
