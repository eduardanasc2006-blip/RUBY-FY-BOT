import os
import zipfile

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)

excluir_raiz = {
    'node_modules', 'data', 'tests', '.git', '.env', '.github',
    'RUBY-FY-BOT.zip', 'RUBY-FY-BOT-v1.4.zip', '.bot.lock',
    '.venv', 'venv', '__pycache__',
}

arquivos = []
for raiz, dirs, fnames in os.walk('.'):
    dirs[:] = [d for d in dirs if d not in excluir_raiz]
    for f in fnames:
        if f == '.env' or f.endswith('.pyc') or f.endswith('.log'):
            continue
        arquivos.append(os.path.join(raiz, f))

arquivos.sort()
with zipfile.ZipFile('RUBY-FY-BOT.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for a in arquivos:
        z.write(a, arcname=a)
print(f'ZIP criado com {len(arquivos)} arquivos')
os.remove(__file__)