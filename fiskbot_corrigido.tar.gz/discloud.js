import { Client, GatewayIntentBits, Partials } from "discord.js";
import { loadSystems } from "./src/loader.mjs";

const TOKEN = process.env.DISCORD_BOT_TOKEN || "MTUwOTE0NjkzMjQ3ODQ3NjM4OQ.GrZ7rN.OhpoeTNIJXiXADTZJKl-WzgGnbI3mg4zV45iHs";

// ── Impede o bot de parar por erros não tratados ─────────────
process.on("unhandledRejection", (reason) => {
  console.error("[FiskBot] Erro não tratado (Promise):", reason);
});
process.on("uncaughtException", (err) => {
  console.error("[FiskBot] Erro não capturado:", err.message);
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});

// Aumenta limite de listeners (bot tem muitos sistemas)
client.setMaxListeners(50);

client.once("clientReady", () => {
  console.log(`[FiskBot] ✅ Online como ${client.user.tag}`);
  client.user.setActivity("!ajuda", { type: 2 });
});

client.on("error", (err) => {
  console.error("[FiskBot] Erro de conexão Discord:", err.message);
});

console.log("[FiskBot] Carregando sistemas...");
await loadSystems(client);
console.log("[FiskBot] ✅ Sistemas carregados! Fazendo login...");
client.login(TOKEN);
