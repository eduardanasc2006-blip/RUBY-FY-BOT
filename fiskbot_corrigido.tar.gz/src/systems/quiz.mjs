import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import QuizModel from '../db/models/Quiz.mjs';
import Usuario from '../db/models/Usuario.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { checkCooldown, formatarTempo } from '../utils/cooldown.mjs';
import { progredirMissao } from './missoes.mjs';
import { isDBConnected } from '../utils/dbGuard.mjs';

const PERGUNTAS = {
  geral: [
    { p: 'Qual é a capital do Brasil?', ops: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Belo Horizonte'], r: 2 },
    { p: 'Quantos estados tem o Brasil?', ops: ['24', '25', '26', '27'], r: 2 },
    { p: 'Qual animal aparece na bandeira do Brasil?', ops: ['Onça', 'Gavião', 'Arara', 'Jaguar'], r: 1 },
    { p: 'Em que continente fica o Brasil?', ops: ['América do Norte', 'América Central', 'América do Sul', 'África'], r: 2 },
    { p: 'Qual é o idioma oficial do Brasil?', ops: ['Espanhol', 'Inglês', 'Português', 'Francês'], r: 2 },
    { p: 'Qual é o rio mais longo do Brasil?', ops: ['Rio São Francisco', 'Rio Paraná', 'Rio Amazonas', 'Rio Tocantins'], r: 2 },
    { p: 'Qual é a maior cidade do Brasil?', ops: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador'], r: 1 },
    { p: 'Qual é a moeda do Brasil?', ops: ['Peso', 'Dólar', 'Euro', 'Real'], r: 3 },
    { p: 'Quantos jogadores tem um time de futebol em campo?', ops: ['9', '10', '11', '12'], r: 2 },
    { p: 'Qual é o planeta mais próximo do Sol?', ops: ['Vênus', 'Terra', 'Marte', 'Mercúrio'], r: 3 },
  ],
  roblox: [
    { p: 'Em que ano o Roblox foi lançado ao público?', ops: ['2004', '2006', '2008', '2010'], r: 1 },
    { p: 'Qual é a moeda principal do Roblox?', ops: ['Tix', 'Robux', 'Gold', 'Coins'], r: 1 },
    { p: 'Quem criou o Roblox?', ops: ['David Baszucki', 'Mark Zuckerberg', 'Notch', 'Erik Cassel'], r: 0 },
    { p: 'O que significa "R$" no Roblox?', ops: ['Real', 'Robux', 'Reward', 'Rank'], r: 1 },
    { p: 'Qual é o nome do personagem padrão do Roblox?', ops: ['Noob', 'Guest', 'Robloxian', 'Builder'], r: 2 },
    { p: 'Em que ano o Roblox removeu os "Guests"?', ops: ['2015', '2016', '2017', '2018'], r: 2 },
    { p: 'Qual linguagem é usada no Roblox Studio?', ops: ['Python', 'JavaScript', 'Lua', 'C#'], r: 2 },
    { p: 'Qual ferramenta é usada para criar jogos no Roblox?', ops: ['Roblox Studio', 'Roblox Builder', 'Roblox Creator', 'Roblox Dev'], r: 0 },
    { p: 'Como se chamava a moeda gratuita do Roblox antes do Robux?', ops: ['Coins', 'Tix', 'Tickets', 'Tix (Tickets)'], r: 3 },
    { p: 'Qual é o jogo mais jogado da história do Roblox?', ops: ['Brookhaven', 'Adopt Me!', 'Blox Fruits', 'Jailbreak'], r: 1 },
  ],
  anime: [
    { p: 'Qual é o personagem principal de Naruto?', ops: ['Sasuke', 'Naruto Uzumaki', 'Itachi', 'Kakashi'], r: 1 },
    { p: 'Em One Piece, qual é o sonho de Luffy?', ops: ['Ser o mais forte', 'Encontrar One Piece', 'Salvar Ace', 'Ser Rei dos Piratas'], r: 3 },
    { p: 'Qual anime tem o personagem Goku?', ops: ['Naruto', 'Dragon Ball', 'Bleach', 'One Piece'], r: 1 },
    { p: 'Em qual anime aparece o Titan Colossal?', ops: ['Sword Art Online', 'Attack on Titan', 'Demon Slayer', 'My Hero Academia'], r: 1 },
    { p: 'Qual é o poder do Deku em My Hero Academia?', ops: ['Sharingan', 'One For All', 'Haki', 'Quirk Fire'], r: 1 },
    { p: 'Qual é o nome da espada de Ichigo em Bleach?', ops: ['Zangetsu', 'Muramasa', 'Tensa', 'Kyoka'], r: 0 },
    { p: 'Quantos membros tem a Akatsuki em Naruto?', ops: ['7', '8', '9', '10'], r: 3 },
    { p: 'Qual é o nome completo do Light Yagami em Death Note?', ops: ['Light Yagami', 'Kira', 'L Lawliet', 'Light Ryuk'], r: 0 },
    { p: 'Em qual anime aparece o personagem Zenitsu?', ops: ['Jujutsu Kaisen', 'Demon Slayer', 'Bleach', 'Fairy Tail'], r: 1 },
    { p: 'O que é Ninjutsu em Naruto?', ops: ['Luta corpo a corpo', 'Arte de usar chakra', 'Arte de ilusões', 'Velocidade extrema'], r: 1 },
  ],
  matematica: [
    { p: 'Quanto é 15 × 15?', ops: ['200', '220', '225', '230'], r: 2 },
    { p: 'Qual é a raiz quadrada de 144?', ops: ['10', '11', '12', '13'], r: 2 },
    { p: 'Quanto é 2⁸?', ops: ['128', '256', '512', '64'], r: 1 },
    { p: 'Qual é o valor de π (pi) aproximado?', ops: ['3.14', '3.16', '3.12', '3.18'], r: 0 },
    { p: '10% de 250 é:', ops: ['20', '25', '30', '35'], r: 1 },
    { p: 'Quanto é 7 × 8?', ops: ['54', '56', '58', '60'], r: 1 },
    { p: 'Qual é o resultado de 12²?', ops: ['124', '144', '132', '164'], r: 1 },
    { p: 'Quanto é 1000 ÷ 8?', ops: ['105', '115', '125', '135'], r: 2 },
    { p: 'Qual é o número primo entre 10 e 15?', ops: ['10', '12', '13', '14'], r: 2 },
    { p: 'Quanto é 25% de 200?', ops: ['25', '40', '50', '75'], r: 2 },
  ],
  tecnologia: [
    { p: 'O que significa "CPU"?', ops: ['Central Processing Unit', 'Computer Power Unit', 'Core Processing Unit', 'Central Power Unit'], r: 0 },
    { p: 'Qual linguagem criou a World Wide Web?', ops: ['Python', 'HTML', 'C++', 'Java'], r: 1 },
    { p: 'Quem fundou a Microsoft?', ops: ['Steve Jobs', 'Elon Musk', 'Bill Gates', 'Larry Page'], r: 2 },
    { p: 'O que é RAM?', ops: ['Read Access Memory', 'Random Access Memory', 'Rapid Access Module', 'Root Access Memory'], r: 1 },
    { p: 'Em que ano foi criado o Python?', ops: ['1985', '1989', '1991', '1995'], r: 2 },
    { p: 'O que significa "GPU"?', ops: ['General Processing Unit', 'Graphics Processing Unit', 'Game Processing Unit', 'Global Processing Unit'], r: 1 },
    { p: 'Quem criou o Linux?', ops: ['Bill Gates', 'Steve Jobs', 'Linus Torvalds', 'Dennis Ritchie'], r: 2 },
    { p: 'O que é um "byte"?', ops: ['4 bits', '8 bits', '16 bits', '32 bits'], r: 1 },
    { p: 'Qual empresa criou o Android?', ops: ['Apple', 'Microsoft', 'Google', 'Samsung'], r: 2 },
    { p: 'O que significa "CSS" no desenvolvimento web?', ops: ['Color Style Sheet', 'Cascading Style Sheets', 'Creative Style Script', 'Computer Style System'], r: 1 },
  ],
  historia: [
    { p: 'Em que ano o Brasil se tornou independente?', ops: ['1820', '1822', '1825', '1830'], r: 1 },
    { p: 'Quem foi o primeiro presidente do Brasil?', ops: ['Dom Pedro II', 'Getúlio Vargas', 'Deodoro da Fonseca', 'Floriano Peixoto'], r: 2 },
    { p: 'Em que ano ocorreu a Segunda Guerra Mundial?', ops: ['1935-1942', '1939-1945', '1941-1946', '1938-1944'], r: 1 },
    { p: 'Quem descobriu o Brasil?', ops: ['Cristóvão Colombo', 'Vasco da Gama', 'Pedro Álvares Cabral', 'Fernão de Magalhães'], r: 2 },
    { p: 'Em que ano o homem chegou à Lua?', ops: ['1965', '1967', '1969', '1971'], r: 2 },
    { p: 'Em que ano a abolição da escravatura ocorreu no Brasil?', ops: ['1880', '1885', '1888', '1890'], r: 2 },
    { p: 'Quem foi Napoleão Bonaparte?', ops: ['Rei da Espanha', 'General e Imperador francês', 'Presidente da França', 'Rei da Itália'], r: 1 },
    { p: 'Qual civilização construiu as pirâmides do Egito?', ops: ['Gregos', 'Romanos', 'Egípcios', 'Maias'], r: 2 },
    { p: 'Em que ano caiu o Muro de Berlim?', ops: ['1987', '1988', '1989', '1990'], r: 2 },
    { p: 'Quem foi o primeiro presidente dos Estados Unidos?', ops: ['Abraham Lincoln', 'George Washington', 'Thomas Jefferson', 'John Adams'], r: 1 },
  ],
  musica: [
    { p: 'Qual é o nome do rei do pop?', ops: ['Elvis Presley', 'Michael Jackson', 'Prince', 'David Bowie'], r: 1 },
    { p: 'Quantas notas musicais existem na escala básica?', ops: ['5', '6', '7', '8'], r: 2 },
    { p: 'Qual banda ficou famosa com "Bohemian Rhapsody"?', ops: ['Led Zeppelin', 'The Beatles', 'Queen', 'Pink Floyd'], r: 2 },
    { p: 'Qual instrumento tem 88 teclas?', ops: ['Órgão', 'Piano', 'Cravo', 'Acordeão'], r: 1 },
    { p: 'Qual cantor brasileiro é conhecido como "Rei"?', ops: ['Caetano Veloso', 'Roberto Carlos', 'Tim Maia', 'Gilberto Gil'], r: 1 },
    { p: 'Qual gênero musical é originário da Jamaica?', ops: ['Funk', 'Reggae', 'Soul', 'R&B'], r: 1 },
    { p: 'O que é BPM na música?', ops: ['Beats Per Minute', 'Bass Power Mode', 'Base Per Measure', 'Beat Play Mode'], r: 0 },
    { p: 'Qual banda criou "Stairway to Heaven"?', ops: ['Pink Floyd', 'Led Zeppelin', 'The Rolling Stones', 'AC/DC'], r: 1 },
    { p: 'Qual é o nome da famosa banda de k-pop com 7 membros?', ops: ['EXO', 'NCT', 'BTS', 'TWICE'], r: 2 },
    { p: 'Qual é o ritmo musical brasileiro mais famoso?', ops: ['Cumbia', 'Salsa', 'Samba', 'Merengue'], r: 2 },
  ],
  ciencias: [
    { p: 'Qual é o símbolo químico do Ouro?', ops: ['Or', 'Go', 'Au', 'Ag'], r: 2 },
    { p: 'Quantos ossos tem o corpo humano adulto?', ops: ['186', '196', '206', '216'], r: 2 },
    { p: 'Qual é o gás mais abundante na atmosfera terrestre?', ops: ['Oxigênio', 'Dióxido de Carbono', 'Nitrogênio', 'Hidrogênio'], r: 2 },
    { p: 'O que é fotossíntese?', ops: ['Respiração celular', 'Produção de energia pela luz', 'Digestão de nutrientes', 'Divisão celular'], r: 1 },
    { p: 'Qual planeta é chamado de "Planeta Vermelho"?', ops: ['Júpiter', 'Saturno', 'Vênus', 'Marte'], r: 3 },
    { p: 'Quantos cromossomos tem uma célula humana normal?', ops: ['23', '44', '46', '48'], r: 2 },
    { p: 'Qual é a fórmula química da água?', ops: ['HO', 'H₂O', 'H₂O₂', 'OH'], r: 1 },
    { p: 'O que estuda a Astronomia?', ops: ['Animais marinhos', 'Corpos celestes', 'Rochas e minerais', 'Plantas'], r: 1 },
    { p: 'Qual é o menor planeta do Sistema Solar?', ops: ['Marte', 'Plutão', 'Mercúrio', 'Vênus'], r: 2 },
    { p: 'Qual é a velocidade da luz no vácuo (aproximada)?', ops: ['100.000 km/s', '200.000 km/s', '300.000 km/s', '400.000 km/s'], r: 2 },
  ],
  esportes: [
    { p: 'Quantos jogadores tem um time de vôlei em quadra?', ops: ['5', '6', '7', '8'], r: 1 },
    { p: 'Em que país foram os primeiros Jogos Olímpicos modernos?', ops: ['Roma', 'Paris', 'Grécia', 'Londres'], r: 2 },
    { p: 'Qual é o esporte mais popular do Brasil?', ops: ['Vôlei', 'Basquete', 'Futebol', 'Tênis'], r: 2 },
    { p: 'Quantas rodadas tem um combate de boxe profissional?', ops: ['10', '12', '15', '8'], r: 1 },
    { p: 'Qual país ganhou mais Copas do Mundo de Futebol?', ops: ['Argentina', 'Alemanha', 'Brasil', 'Itália'], r: 2 },
    { p: 'Qual é a distância de uma maratona?', ops: ['30 km', '40 km', '42,195 km', '45 km'], r: 2 },
    { p: 'Em que esporte se usa o termo "ace"?', ops: ['Futebol', 'Tênis', 'Vôlei', 'Basquete'], r: 1 },
    { p: 'Quantos pontos vale uma cesta de 3 no basquete?', ops: ['1', '2', '3', '4'], r: 2 },
    { p: 'Qual é o esporte nacional do Japão?', ops: ['Karatê', 'Sumô', 'Judô', 'Kendo'], r: 1 },
    { p: 'Quantos sets tem uma partida de vôlei (melhor de)?', ops: ['3', '4', '5', '6'], r: 2 },
  ],
  series: [
    { p: 'Em qual série aparece o personagem Walter White?', ops: ['Dexter', 'Breaking Bad', 'Ozark', 'Narcos'], r: 1 },
    { p: 'Qual série tem a frase "Winter is coming"?', ops: ['Vikings', 'The Witcher', 'Game of Thrones', 'House of Dragon'], r: 2 },
    { p: 'Em qual série existe o "Mundo Invertido"?', ops: ['Dark', 'Stranger Things', 'Outer Range', 'Lost'], r: 1 },
    { p: 'Qual é o nome da personagem principal de "Bridgerton"?', ops: ['Penelope', 'Eloise', 'Daphne', 'Kate'], r: 2 },
    { p: 'Em qual série aparece o vilão Gustavo Fring?', ops: ['Narcos', 'Ozark', 'Breaking Bad', 'Better Call Saul'], r: 2 },
    { p: 'Qual série se passa na cidade fictícia de Hawkins?', ops: ['Dark', 'Stranger Things', 'The OA', 'Manifest'], r: 1 },
    { p: 'Quantas temporadas tem "Friends"?', ops: ['8', '9', '10', '11'], r: 2 },
    { p: 'Qual ator interpreta Tony Stark no MCU?', ops: ['Chris Evans', 'Robert Downey Jr.', 'Mark Ruffalo', 'Chris Hemsworth'], r: 1 },
    { p: 'Em qual série existe a Casa do Papel?', ops: ['Elite', 'La Casa de Papel', 'Narcos: México', 'Cable Girls'], r: 1 },
    { p: 'Qual personagem de "The Office" é gerente regional?', ops: ['Jim Halpert', 'Dwight Schrute', 'Michael Scott', 'Andy Bernard'], r: 2 },
  ],
  pokemon: [
    { p: 'Qual é o Pokémon inicial de fogo de Kanto?', ops: ['Squirtle', 'Bulbasaur', 'Charmander', 'Cyndaquil'], r: 2 },
    { p: 'Qual é o número do Pokémon Pikachu na Pokédex?', ops: ['#025', '#035', '#045', '#055'], r: 0 },
    { p: 'Qual é o tipo do Pokémon Gengar?', ops: ['Fantasma/Veneno', 'Escuro/Fantasma', 'Veneno/Psíquico', 'Fantasma/Sombrio'], r: 0 },
    { p: 'Qual é a evolução final de Charmander?', ops: ['Charmeleon', 'Charizard', 'Charmander Max', 'Mega Charizard'], r: 1 },
    { p: 'Qual lenda é o Pokémon mascote de Pokémon Gold?', ops: ['Lugia', 'Ho-Oh', 'Suicune', 'Entei'], r: 1 },
    { p: 'Qual é o Pokémon mais pesado do jogo original?', ops: ['Snorlax', 'Onix', 'Lapras', 'Gyarados'], r: 0 },
    { p: 'Qual tipo é super efetivo contra Água?', ops: ['Fogo', 'Elétrico', 'Grama', 'Gelo'], r: 1 },
    { p: 'Quantos Pokémon existiam na 1ª geração?', ops: ['100', '121', '151', '181'], r: 2 },
    { p: 'Qual Pokémon é chamado de "Pokémon DNA"?', ops: ['Mew', 'Mewtwo', 'Ditto', 'Deoxys'], r: 1 },
    { p: 'Qual cidade tem o primeiro ginásio em Pokémon Red/Blue?', ops: ['Pewter City', 'Cerulean City', 'Vermilion City', 'Pallet Town'], r: 0 },
  ],
  geografia: [
    { p: 'Qual é o maior país do mundo em área?', ops: ['China', 'Canadá', 'Brasil', 'Rússia'], r: 3 },
    { p: 'Qual é a capital da Austrália?', ops: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], r: 2 },
    { p: 'Qual oceano é o maior do mundo?', ops: ['Atlântico', 'Índico', 'Pacífico', 'Ártico'], r: 2 },
    { p: 'Qual é o rio mais longo do mundo?', ops: ['Rio Amazonas', 'Rio Nilo', 'Rio Yangtzé', 'Rio Mississipi'], r: 1 },
    { p: 'Em qual continente fica o Egito?', ops: ['Ásia', 'Europa', 'África', 'Oriente Médio'], r: 2 },
    { p: 'Qual é a capital do Japão?', ops: ['Osaka', 'Quioto', 'Tóquio', 'Hiroshima'], r: 2 },
    { p: 'Qual é o menor país do mundo?', ops: ['Mônaco', 'San Marino', 'Vaticano', 'Liechtenstein'], r: 2 },
    { p: 'Quantos países fazem parte da União Europeia (2024)?', ops: ['25', '27', '30', '32'], r: 1 },
    { p: 'Qual é a montanha mais alta do mundo?', ops: ['Monte Aconcágua', 'Monte Kilimanjaro', 'Monte Everest', 'Monte Logan'], r: 2 },
    { p: 'Qual é a capital da Argentina?', ops: ['Córdoba', 'Buenos Aires', 'Rosário', 'Mendoza'], r: 1 },
  ],
};

const CAT_INFO = {
  geral:      { emoji: '🌍', label: 'Geral' },
  roblox:     { emoji: '🎮', label: 'Roblox' },
  anime:      { emoji: '🍥', label: 'Anime' },
  matematica: { emoji: '🔢', label: 'Matemática' },
  tecnologia: { emoji: '💻', label: 'Tecnologia' },
  historia:   { emoji: '📜', label: 'História' },
  musica:     { emoji: '🎵', label: 'Música' },
  ciencias:   { emoji: '🔬', label: 'Ciências' },
  esportes:   { emoji: '⚽', label: 'Esportes' },
  series:     { emoji: '🎬', label: 'Séries/Filmes' },
  pokemon:    { emoji: '🔴', label: 'Pokémon' },
  geografia:  { emoji: '🗺️', label: 'Geografia' },
};

const jogosAtivos = new Map();
const aguardandoCategoria = new Map();

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'quiz') {
      const cdKey = `quiz:${msg.author.id}:${guildId}`;
      const espera = checkCooldown(cdKey, 15_000);
      if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para jogar novamente.`)] });

      const chave = `${msg.author.id}:${guildId}`;
      if (jogosAtivos.has(chave)) return msg.reply({ embeds: [embedErro('Você já tem um quiz em andamento!')] });

      const categoriaInput = args[0]?.toLowerCase();
      const cats = Object.keys(PERGUNTAS);
      const categoriaForce = cats.find(c => c.startsWith(categoriaInput || '___NUNCA___'));

      if (categoriaForce) {
        return iniciarQuiz(msg, guildId, categoriaForce);
      }

      // Menu de seleção de categoria (2 linhas de 4 + 1 linha de 4)
      const botoes = Object.entries(CAT_INFO).map(([id, info]) =>
        new ButtonBuilder()
          .setCustomId(`quiz_cat:${id}:${msg.author.id}:${guildId}`)
          .setLabel(`${info.emoji} ${info.label}`)
          .setStyle(ButtonStyle.Secondary)
      );

      const rows = [];
      for (let i = 0; i < botoes.length; i += 4) {
        rows.push(new ActionRowBuilder().addComponents(botoes.slice(i, i + 4)));
      }

      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('🧠 Quiz — Escolha a Categoria')
        .setDescription(
          Object.entries(CAT_INFO).map(([, info]) => `${info.emoji} **${info.label}**`).join('  •  ')
        )
        .setFooter({ text: 'Você tem 30 segundos para escolher!' })
        .setTimestamp();

      const menuMsg = await msg.reply({ embeds: [embed], components: rows });

      aguardandoCategoria.set(chave, { menuMsgId: menuMsg.id });
      setTimeout(async () => {
        if (!aguardandoCategoria.has(chave)) return;
        aguardandoCategoria.delete(chave);
        await menuMsg.edit({ components: [] }).catch(() => {});
        await msg.channel.send({
          embeds: [new EmbedBuilder().setColor(0xe74c3c).setDescription(`⏰ <@${msg.author.id}> não escolheu uma categoria a tempo!`)],
        }).catch(() => {});
      }, 30_000);

      return;
    }

    if (cmd === 'quizstats') {
      if (!isDBConnected()) return msg.reply({ embeds: [embedErro('Banco de dados offline.')] });
      const alvo = msg.mentions.users.first() || msg.author;
      const doc = await QuizModel.findOne({ userId: alvo.id, guildId });
      if (!doc || doc.total === 0) return msg.reply({ embeds: [embedErro('Nenhum quiz registrado.')] });
      const precisao = ((doc.acertos / doc.total) * 100).toFixed(1);
      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle(`📊 Stats de Quiz — ${alvo.displayName}`)
        .addFields(
          { name: '📝 Total', value: String(doc.total), inline: true },
          { name: '✅ Acertos', value: String(doc.acertos), inline: true },
          { name: '❌ Erros', value: String(doc.erros), inline: true },
          { name: '🎯 Precisão', value: `${precisao}%`, inline: true },
          { name: '⭐ Favorita', value: doc.categoriaFavorita || 'N/A', inline: true },
        )
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'topquiz') {
      if (!isDBConnected()) return msg.reply({ embeds: [embedErro('Banco de dados offline.')] });
      const top = await QuizModel.find({ guildId }).sort({ acertos: -1 }).limit(10).lean();
      const linhas = top.map((u, i) => `**#${i + 1}** <@${u.userId}> — ✅ ${u.acertos} acertos (${u.total} jogos)`);
      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('🏆 Top Quiz')
        .setDescription(linhas.join('\n') || 'Nenhum dado.')
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    const { customId } = interaction;

    // Seleção de categoria
    if (customId.startsWith('quiz_cat:')) {
      const parts = customId.split(':');
      const categoria = parts[1];
      const userId = parts[2];
      const guildId = parts[3];

      if (interaction.user.id !== userId)
        return interaction.reply({ content: 'Este menu não é seu.', ephemeral: true });

      const chave = `${userId}:${guildId}`;
      if (!aguardandoCategoria.has(chave))
        return interaction.reply({ content: 'Este menu expirou.', ephemeral: true });

      aguardandoCategoria.delete(chave);
      await interaction.update({ components: [] }).catch(() => {});
      await iniciarQuizInteraction(interaction, guildId, categoria);
      return;
    }

    // Resposta de quiz
    if (!customId.startsWith('quiz:')) return;
    const parts = customId.split(':');
    const respostaStr = parts[1];
    const userId = parts[2];
    const guildId = parts[3];

    if (interaction.user.id !== userId) return interaction.reply({ content: 'Este quiz não é seu.', ephemeral: true });

    const chave = `${userId}:${guildId}`;
    const jogo = jogosAtivos.get(chave);
    if (!jogo) return interaction.reply({ content: 'Este quiz expirou.', ephemeral: true });

    jogosAtivos.delete(chave);
    const resposta = parseInt(respostaStr);
    const correto = resposta === jogo.correto;
    const xpGanho = correto ? 30 : 0;

    // Salva stats (ignora erro silenciosamente se DB offline)
    try {
      if (isDBConnected()) {
        await QuizModel.findOneAndUpdate(
          { userId, guildId },
          { $inc: { total: 1, acertos: correto ? 1 : 0, erros: correto ? 0 : 1 }, $setOnInsert: { userId, guildId } },
          { upsert: true }
        );
        if (correto && xpGanho > 0) {
          await Usuario.findOneAndUpdate(
            { userId, guildId },
            { $inc: { xp: xpGanho }, $setOnInsert: { userId, guildId } },
            { upsert: true }
          );
        }
        await progredirMissao(userId, guildId, 'quiz').catch(() => {});
      }
    } catch {}

    const embed = new EmbedBuilder()
      .setColor(correto ? 0x2ecc71 : 0xe74c3c)
      .setDescription(
        correto
          ? `✅ Correto! <@${userId}> acertou!${xpGanho > 0 ? ` +${xpGanho} XP` : ''}`
          : `❌ Errado! A resposta certa era a opção **${['A', 'B', 'C', 'D'][jogo.correto]}) ${jogo.ops[jogo.correto]}**`
      )
      .setTimestamp();

    await interaction.update({ embeds: [embed], components: [] }).catch(() => {});
  });
}

async function iniciarQuiz(msg, guildId, categoria) {
  const chave = `${msg.author.id}:${guildId}`;
  const perguntas = PERGUNTAS[categoria];
  const pergunta = perguntas[Math.floor(Math.random() * perguntas.length)];
  const info = CAT_INFO[categoria] || { emoji: '🧠', label: categoria };

  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`🧠 Quiz — ${info.emoji} ${info.label}`)
    .setDescription(`**${pergunta.p}**`)
    .setFooter({ text: 'Você tem 30 segundos para responder!' })
    .setTimestamp();

  const botoes = pergunta.ops.map((op, i) =>
    new ButtonBuilder()
      .setCustomId(`quiz:${i}:${msg.author.id}:${guildId}`)
      .setLabel(`${['A', 'B', 'C', 'D'][i]}) ${op}`)
      .setStyle(ButtonStyle.Primary)
  );
  const row = new ActionRowBuilder().addComponents(botoes);
  const quizMsg = await msg.reply({ embeds: [embed], components: [row] });

  jogosAtivos.set(chave, { correto: pergunta.r, ops: pergunta.ops, categoria });
  setTimeout(async () => {
    if (!jogosAtivos.has(chave)) return;
    jogosAtivos.delete(chave);
    await quizMsg.edit({ components: [] }).catch(() => {});
    await msg.channel.send({
      embeds: [new EmbedBuilder()
        .setColor(0xe74c3c)
        .setDescription(`⏰ <@${msg.author.id}> o tempo esgotou! A resposta era: **${['A', 'B', 'C', 'D'][pergunta.r]}) ${pergunta.ops[pergunta.r]}**`)],
    }).catch(() => {});
  }, 30_000);
}

async function iniciarQuizInteraction(interaction, guildId, categoria) {
  const userId = interaction.user.id;
  const chave = `${userId}:${guildId}`;
  const perguntas = PERGUNTAS[categoria];
  const pergunta = perguntas[Math.floor(Math.random() * perguntas.length)];
  const info = CAT_INFO[categoria] || { emoji: '🧠', label: categoria };

  const embed = new EmbedBuilder()
    .setColor(0x3498db)
    .setTitle(`🧠 Quiz — ${info.emoji} ${info.label}`)
    .setDescription(`**${pergunta.p}**`)
    .setFooter({ text: 'Você tem 30 segundos para responder!' })
    .setTimestamp();

  const botoes = pergunta.ops.map((op, i) =>
    new ButtonBuilder()
      .setCustomId(`quiz:${i}:${userId}:${guildId}`)
      .setLabel(`${['A', 'B', 'C', 'D'][i]}) ${op}`)
      .setStyle(ButtonStyle.Primary)
  );
  const row = new ActionRowBuilder().addComponents(botoes);
  const quizMsg = await interaction.channel.send({ embeds: [embed], components: [row] });

  jogosAtivos.set(chave, { correto: pergunta.r, ops: pergunta.ops, categoria });
  setTimeout(async () => {
    if (!jogosAtivos.has(chave)) return;
    jogosAtivos.delete(chave);
    await quizMsg.edit({ components: [] }).catch(() => {});
    await interaction.channel.send({
      embeds: [new EmbedBuilder()
        .setColor(0xe74c3c)
        .setDescription(`⏰ <@${userId}> o tempo esgotou! A resposta era: **${['A', 'B', 'C', 'D'][pergunta.r]}) ${pergunta.ops[pergunta.r]}**`)],
    }).catch(() => {});
  }, 30_000);
}
