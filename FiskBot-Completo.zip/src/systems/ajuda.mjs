import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';

const PAGINAS = [
  {
    titulo: '💸 Conversão & Robux',
    cor: 0x00a2ff,
    campos: [
      { name: '!robux <valor>', value: 'Converte BRL → Robux' },
      { name: '!brl <valor>', value: 'Converte Robux → BRL' },
      { name: '!taxa', value: 'Mostra a taxa atual' },
      { name: '!simular <min> <max>', value: 'Tabela de preços' },
      { name: '!historico', value: 'Histórico de taxas' },
      { name: '!comparar <robux>', value: 'Valor bruto e líquido' },
      { name: '!meta <robux>', value: 'Calcular meta em BRL' },
    ],
  },
  {
    titulo: '🎮 Roblox',
    cor: 0x00a2ff,
    campos: [
      { name: '!perfil <usuário>', value: 'Perfil do jogador' },
      { name: '!avatar <usuário>', value: 'Avatar 2D/3D' },
      { name: '!grupo <id>', value: 'Informações do grupo' },
      { name: '!gamepass <id>', value: 'Informações do gamepass' },
    ],
  },
  {
    titulo: '💍 Relacionamentos',
    cor: 0xff69b4,
    campos: [
      { name: '!casar @user', value: 'Pedido de casamento' },
      { name: '!divorciar', value: 'Pedido de divórcio' },
      { name: '!parceiro [@user]', value: 'Ver parceiro(a)' },
      { name: '!aniversariocasamento', value: 'Aniversário do casal' },
      { name: '!topcasais', value: 'Ranking de casais' },
    ],
  },
  {
    titulo: '💜 Afinidade & Interações',
    cor: 0xa855f7,
    campos: [
      { name: '!afinidade @user', value: 'Ver afinidade real' },
      { name: '!topafinidade', value: 'Top afinidade dos casais' },
      { name: '!ship @u1 @u2', value: 'Ship divertido (aleatório)' },
      { name: '!abracar/beijar/cafune @user', value: '+Afinidade (1x/12h)' },
      { name: '!acariciar/dancar/elogiar @user', value: 'Outras interações' },
      { name: '!proteger/xingar @user', value: 'Mais interações' },
    ],
  },
  {
    titulo: '⭐ Reputação & Perfil',
    cor: 0xffd700,
    campos: [
      { name: '!rep @user', value: '+1 rep (1x/24h)' },
      { name: '!ranking', value: 'Top reputação' },
      { name: '!meuperfil [@user]', value: 'Ver perfil' },
      { name: '!perfilcard [@user]', value: 'Card visual do perfil' },
      { name: '!titulos', value: 'Títulos desbloqueados' },
      { name: '!equipartitulo <nome>', value: 'Equipar título' },
    ],
  },
  {
    titulo: '🏆 XP & Níveis',
    cor: 0x00bfff,
    campos: [
      { name: '!xp [@user]', value: 'Ver XP atual' },
      { name: '!rank [@user]', value: 'Ver nível e progresso' },
      { name: '!leaderboard', value: 'Ranking global de XP' },
    ],
  },
  {
    titulo: '🧠 Quiz & 🎯 Forca',
    cor: 0x3498db,
    campos: [
      { name: '!quiz [categoria]', value: 'Iniciar quiz (+30 XP acerto)' },
      { name: '!quizstats [@user]', value: 'Estatísticas de quiz' },
      { name: '!topquiz', value: 'Ranking quiz' },
      { name: '!forca [categoria]', value: 'Jogo da forca (+50 XP)' },
      { name: '!forcaranking', value: 'Ranking forca' },
    ],
  },
  {
    titulo: '🎲 Diversão',
    cor: 0x9b59b6,
    campos: [
      { name: '!8ball <pergunta>', value: 'Bola mágica' },
      { name: '!dado [faces]', value: 'Rolar dado' },
      { name: '!coinflip', value: 'Cara ou coroa' },
      { name: '!ppt', value: 'Pedra, papel ou tesoura' },
      { name: '!escolher <op1> <op2>...', value: 'Escolha aleatória' },
      { name: '!sortear', value: 'Sortear usuário' },
      { name: '!verdade / !desafio', value: 'Verdade ou desafio' },
    ],
  },
  {
    titulo: '🏅 Conquistas & 📋 Missões',
    cor: 0xf1c40f,
    campos: [
      { name: '!conquistas [@user]', value: 'Ver conquistas' },
      { name: '!badges [@user]', value: 'Ver insígnias' },
      { name: '!missoes', value: 'Missões diárias e semanais' },
    ],
  },
  {
    titulo: '🎫 Suporte & 🚨 Denúncias',
    cor: 0x7289da,
    campos: [
      { name: '!suporte / !ticket', value: 'Abrir ticket de suporte' },
      { name: '!fecharticket', value: 'Fechar ticket' },
      { name: '!transcript', value: 'Histórico do ticket' },
      { name: '!denunciar @user', value: 'Denunciar usuário' },
      { name: '!avaliar', value: 'Avaliar serviço (⭐-⭐⭐⭐⭐⭐)' },
      { name: '!avaliacoes', value: 'Ver avaliações' },
    ],
  },
  {
    titulo: '🛍️ Produtos & Serviços',
    cor: 0xf39c12,
    campos: [
      { name: '!catalogo / !servicos', value: 'Ver catálogo de produtos' },
      { name: '!preco <nome>', value: 'Ver preços do produto' },
      { name: '!addproduto', value: 'Adicionar produto (admin)' },
      { name: '!addtabela <nome>', value: 'Adicionar tabela de preços' },
      { name: '!delproduto <nome>', value: 'Remover produto (admin)' },
    ],
  },
  {
    titulo: '📢 Administração',
    cor: 0xe74c3c,
    campos: [
      { name: '!anuncio <texto>', value: 'Fazer anúncio' },
      { name: '!embed <titulo>|<desc>', value: 'Criar embed' },
      { name: '!enquete <pergunta>', value: 'Criar enquete' },
      { name: '!sorteio <min> <prêmio>', value: 'Criar sorteio' },
      { name: '!limpar <qtd>', value: 'Apagar mensagens (máx 100)' },
      { name: '!settaxa <valor>', value: 'Alterar taxa de conversão' },
      { name: '!setconfig <chave> <valor>', value: 'Configurar bot' },
      { name: '!painel', value: 'Painel de configurações' },
      { name: '!setwelcome / !testwelcome', value: 'Boas-vindas' },
    ],
  },
  {
    titulo: '📊 Estatísticas & Info',
    cor: 0xa855f7,
    campos: [
      { name: '!stats', value: 'Estatísticas do servidor' },
      { name: '!botinfo', value: 'Informações do bot' },
      { name: '!logs [tipo]', value: 'Últimos logs (admin)' },
    ],
  },
];

const sessoesAjuda = new Map();

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();

    if (cmd !== 'ajuda' && cmd !== 'help' && cmd !== 'comandos') return;

    await enviarPagina(msg, 0, configs);
  });

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;
    const { customId } = interaction;

    if (customId.startsWith('ajuda:')) {
      const [, acao, paginaStr, userId] = customId.split(':');
      if (interaction.user.id !== userId)
        return interaction.reply({ content: 'Este menu não é seu.', ephemeral: true });

      let pagina = parseInt(paginaStr);
      if (acao === 'prox') pagina = Math.min(pagina + 1, PAGINAS.length - 1);
      else if (acao === 'ant') pagina = Math.max(pagina - 1, 0);
      else if (acao === 'inicio') pagina = 0;

      const embed = construirEmbed(pagina, interaction.user.id);
      const row = construirRow(pagina, interaction.user.id);
      await interaction.update({ embeds: [embed], components: [row] });
    }
  });
}

async function enviarPagina(msg, pagina, configs) {
  const embed = construirEmbed(pagina, msg.author.id);
  const row = construirRow(pagina, msg.author.id);
  return msg.reply({ embeds: [embed], components: [row] });
}

function construirEmbed(pagina, userId) {
  const p = PAGINAS[pagina];
  const embed = new EmbedBuilder()
    .setColor(p.cor)
    .setTitle(`📖 ${p.titulo}`)
    .setFooter({ text: `Página ${pagina + 1}/${PAGINAS.length} • FiskBot Ultimate` })
    .setTimestamp();

  for (const campo of p.campos) {
    embed.addFields({ name: campo.name, value: campo.value, inline: true });
  }
  return embed;
}

function construirRow(pagina, userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ajuda:inicio:${pagina}:${userId}`)
      .setLabel('🏠 Início')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(pagina === 0),
    new ButtonBuilder()
      .setCustomId(`ajuda:ant:${pagina}:${userId}`)
      .setLabel('◀ Anterior')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(pagina === 0),
    new ButtonBuilder()
      .setCustomId(`ajuda:prox:${pagina}:${userId}`)
      .setLabel('Próximo ▶')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(pagina === PAGINAS.length - 1),
  );
}
