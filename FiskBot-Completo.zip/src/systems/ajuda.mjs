import {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';

const EXPIRACAO_MS = 5 * 60 * 1000; // 5 minutos

const CATEGORIAS = {
  robux: {
    emoji: '💸',
    label: 'Robux & Conversão',
    cor: 0x00a2ff,
    comandos: [
      { cmd: '!robux <valor>', desc: 'Converte BRL para Robux.' },
      { cmd: '!brl <valor>', desc: 'Converte Robux para BRL.' },
      { cmd: '!taxa', desc: 'Mostra a taxa atual.' },
      { cmd: '!simular <v1> <v2>', desc: 'Gera tabela de conversão.' },
      { cmd: '!historico', desc: 'Histórico de alterações de taxa.' },
      { cmd: '!comparar <robux>', desc: 'Compara valor bruto e líquido.' },
      { cmd: '!meta <robux>', desc: 'Calcula metas de Robux.' },
    ],
  },
  roblox: {
    emoji: '🎮',
    label: 'Roblox',
    cor: 0x00c8ff,
    comandos: [
      { cmd: '!perfil <usuário>', desc: 'Mostra perfil Roblox.' },
      { cmd: '!avatar <usuário>', desc: 'Mostra avatar em 2D ou 3D.' },
      { cmd: '!grupo <id>', desc: 'Informações de grupo.' },
      { cmd: '!gamepass <id>', desc: 'Informações de gamepass.' },
    ],
  },
  relacionamentos: {
    emoji: '💑',
    label: 'Relacionamentos',
    cor: 0xff69b4,
    comandos: [
      { cmd: '!casar @user', desc: 'Pedido de casamento.' },
      { cmd: '!divorciar', desc: 'Pedido de divórcio.' },
      { cmd: '!parceiro [@user]', desc: 'Informações do parceiro.' },
      { cmd: '!ship @u1 @u2', desc: 'Compatibilidade divertida.' },
      { cmd: '!afinidade @user', desc: 'Afinidade baseada em dados reais.' },
      { cmd: '!topafinidade', desc: 'Ranking de afinidade.' },
      { cmd: '!topcasais', desc: 'Ranking de casais.' },
    ],
  },
  interacoes: {
    emoji: '🤝',
    label: 'Interações',
    cor: 0xa855f7,
    comandos: [
      { cmd: '!abracar @user', desc: 'Dá um abraço (+afinidade).' },
      { cmd: '!beijar @user', desc: 'Dá um beijo (+afinidade).' },
      { cmd: '!cafune @user', desc: 'Dá um cafuné (+afinidade).' },
      { cmd: '!acariciar @user', desc: 'Faz um carinho.' },
      { cmd: '!dancar @user', desc: 'Dança com alguém.' },
      { cmd: '!elogiar @user', desc: 'Elogia alguém.' },
      { cmd: '!proteger @user', desc: 'Promete proteger.' },
      { cmd: '!xingar @user', desc: 'Xinga alguém (diversão).' },
    ],
  },
  reputacao: {
    emoji: '⭐',
    label: 'Reputação',
    cor: 0xffd700,
    comandos: [
      { cmd: '!rep @user', desc: 'Dá +1 rep (1x por dia).' },
      { cmd: '!meuperfil [@user]', desc: 'Ver perfil e reputação.' },
      { cmd: '!ranking', desc: 'Top 10 em reputação.' },
    ],
  },
  niveis: {
    emoji: '🏆',
    label: 'Níveis & XP',
    cor: 0x00bfff,
    comandos: [
      { cmd: '!xp [@user]', desc: 'Ver XP atual.' },
      { cmd: '!rank [@user]', desc: 'Ver nível e progresso.' },
      { cmd: '!leaderboard', desc: 'Ranking global de XP.' },
    ],
  },
  quiz: {
    emoji: '🧠',
    label: 'Quiz',
    cor: 0x3498db,
    comandos: [
      { cmd: '!quiz [categoria]', desc: 'Iniciar quiz (+30 XP por acerto).' },
      { cmd: '!quizstats [@user]', desc: 'Estatísticas de quiz.' },
      { cmd: '!topquiz', desc: 'Ranking de quiz.' },
    ],
  },
  forca: {
    emoji: '🎯',
    label: 'Forca',
    cor: 0xe67e22,
    comandos: [
      { cmd: '!forca [categoria]', desc: 'Jogo da forca (+50 XP).' },
      { cmd: '!forcaranking', desc: 'Ranking de forca.' },
    ],
  },
  diversao: {
    emoji: '🎲',
    label: 'Diversão',
    cor: 0x9b59b6,
    comandos: [
      { cmd: '!8ball <pergunta>', desc: 'Bola mágica.' },
      { cmd: '!dado [faces]', desc: 'Rolar dado.' },
      { cmd: '!coinflip', desc: 'Cara ou coroa.' },
      { cmd: '!ppt', desc: 'Pedra, papel ou tesoura.' },
      { cmd: '!escolher <op1> <op2>', desc: 'Escolha aleatória.' },
      { cmd: '!sortear', desc: 'Sortear usuário do servidor.' },
      { cmd: '!verdade / !desafio', desc: 'Verdade ou desafio.' },
    ],
  },
  conquistas: {
    emoji: '🎖️',
    label: 'Conquistas',
    cor: 0xf1c40f,
    comandos: [
      { cmd: '!conquistas [@user]', desc: 'Ver conquistas desbloqueadas.' },
      { cmd: '!badges [@user]', desc: 'Ver insígnias.' },
    ],
  },
  missoes: {
    emoji: '🎯',
    label: 'Missões',
    cor: 0x27ae60,
    comandos: [
      { cmd: '!missoes', desc: 'Ver missões diárias e semanais.' },
    ],
  },
  titulos: {
    emoji: '👑',
    label: 'Títulos',
    cor: 0xe74c3c,
    comandos: [
      { cmd: '!titulos', desc: 'Ver títulos desbloqueados.' },
      { cmd: '!equipartitulo <nome>', desc: 'Equipar um título.' },
    ],
  },
  perfilvisual: {
    emoji: '🎭',
    label: 'Perfil Visual',
    cor: 0x2ecc71,
    comandos: [
      { cmd: '!perfilcard [@user]', desc: 'Card visual do perfil.' },
      { cmd: '!meuperfil [@user]', desc: 'Ver perfil completo.' },
    ],
  },
  sugestoes: {
    emoji: '💡',
    label: 'Sugestões',
    cor: 0xf39c12,
    comandos: [
      { cmd: '!sugerir <texto>', desc: 'Enviar sugestão para os admins.' },
      { cmd: '!sugestoes', desc: 'Ver sugestões enviadas.' },
    ],
  },
  suporte: {
    emoji: '🎫',
    label: 'Suporte',
    cor: 0x7289da,
    comandos: [
      { cmd: '!suporte / !ticket', desc: 'Abrir ticket de suporte.' },
      { cmd: '!fecharticket', desc: 'Fechar ticket atual.' },
      { cmd: '!transcript', desc: 'Histórico do ticket.' },
    ],
    extra: '**Categorias:** Compra • Dúvida • Problema • Parceria',
  },
  denuncias: {
    emoji: '🚨',
    label: 'Denúncias',
    cor: 0xe74c3c,
    comandos: [
      { cmd: '!denunciar @user', desc: 'Denunciar usuário.' },
    ],
    extra: '**Fluxo:** Selecionar motivo → Informar usuário → Enviar provas → Ticket privado criado.',
  },
  servicos: {
    emoji: '🛍️',
    label: 'Serviços',
    cor: 0xf39c12,
    comandos: [
      { cmd: '!catalogo / !servicos', desc: 'Ver catálogo de produtos.' },
      { cmd: '!preco <nome>', desc: 'Ver preços do produto.' },
      { cmd: '!addproduto', desc: 'Adicionar produto (admin).' },
      { cmd: '!delproduto <nome>', desc: 'Remover produto (admin).' },
      { cmd: '!ticket', desc: 'Abrir ticket de compra.' },
    ],
    extra: '**Status:** 🟢 Disponível  🟡 Poucas vagas  🔴 Fechado',
  },
  administracao: {
    emoji: '📢',
    label: 'Administração',
    cor: 0xe74c3c,
    comandos: [
      { cmd: '!anuncio <texto>', desc: 'Fazer anúncio.' },
      { cmd: '!embed <titulo>|<desc>', desc: 'Criar embed.' },
      { cmd: '!enquete <pergunta>', desc: 'Criar enquete.' },
      { cmd: '!sorteio <min> <prêmio>', desc: 'Criar sorteio.' },
      { cmd: '!limpar <qtd>', desc: 'Apagar mensagens (máx 100).' },
      { cmd: '!settaxa <valor>', desc: 'Alterar taxa de conversão.' },
      { cmd: '!setconfig <chave> <valor>', desc: 'Configurar bot.' },
      { cmd: '!setwelcome / !testwelcome', desc: 'Configurar boas-vindas.' },
      { cmd: '!painel', desc: 'Painel de configurações.' },
    ],
  },
  estatisticas: {
    emoji: '📊',
    label: 'Estatísticas',
    cor: 0xa855f7,
    comandos: [
      { cmd: '!stats', desc: 'Estatísticas do servidor.' },
      { cmd: '!botinfo', desc: 'Informações do bot.' },
      { cmd: '!logs [tipo]', desc: 'Últimos logs (admin).' },
    ],
  },
  atualizacoes: {
    emoji: '📰',
    label: 'Atualizações',
    cor: 0x1abc9c,
    comandos: [
      { cmd: '!changelog', desc: 'Ver últimas atualizações do bot.' },
      { cmd: '!versao', desc: 'Versão atual do FiskBot.' },
    ],
    extra: '🔔 Fique atento ao canal de atualizações para novidades!',
  },
};

function embedPrincipal() {
  return new EmbedBuilder()
    .setColor(0x5865f2)
    .setTitle('✨ FiskBot — Central de Comandos')
    .setDescription(
      'Bem-vindo ao painel de ajuda do **FiskBot**.\n\n' +
      'Selecione uma categoria abaixo para visualizar seus comandos.'
    )
    .addFields({
      name: '📋 Categorias disponíveis',
      value: Object.values(CATEGORIAS)
        .map(c => `${c.emoji} ${c.label}`)
        .join('  •  '),
    })
    .setFooter({ text: 'FiskBot Ultimate • Selecione uma categoria no menu abaixo' })
    .setTimestamp();
}

function embedCategoria(id) {
  const cat = CATEGORIAS[id];
  if (!cat) return null;

  const linhas = cat.comandos.map(c => `\`${c.cmd}\`\n┗ ${c.desc}`).join('\n\n');
  const embed = new EmbedBuilder()
    .setColor(cat.cor)
    .setTitle(`${cat.emoji} ${cat.label}`)
    .setDescription(linhas || 'Nenhum comando disponível.')
    .setFooter({ text: 'FiskBot Ultimate • Clique em ⬅ Voltar para o menu principal' })
    .setTimestamp();

  if (cat.extra) embed.addFields({ name: '\u200b', value: cat.extra });
  return embed;
}

function menuPrincipal(userId) {
  const opcoes = Object.entries(CATEGORIAS).map(([id, cat]) =>
    new StringSelectMenuOptionBuilder()
      .setValue(`ajuda_cat:${id}:${userId}`)
      .setLabel(cat.label)
      .setEmoji(cat.emoji)
  );

  const select = new StringSelectMenuBuilder()
    .setCustomId(`ajuda_menu:${userId}`)
    .setPlaceholder('📂 Selecione uma categoria...')
    .addOptions(opcoes);

  return new ActionRowBuilder().addComponents(select);
}

function botaoVoltar(userId) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`ajuda_voltar:${userId}`)
      .setLabel('⬅ Voltar ao Menu Principal')
      .setStyle(ButtonStyle.Secondary)
  );
}

export function register(client, configs) {
  const sessoes = new Map();

  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    if (cmd !== 'ajuda' && cmd !== 'help' && cmd !== 'comandos') return;

    const sent = await msg.reply({
      embeds: [embedPrincipal()],
      components: [menuPrincipal(msg.author.id)],
    });

    sessoes.set(sent.id, {
      userId: msg.author.id,
      timer: setTimeout(() => {
        sent.edit({ components: [] }).catch(() => null);
        sessoes.delete(sent.id);
      }, EXPIRACAO_MS),
    });
  });

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isStringSelectMenu() && !interaction.isButton()) return;

    const { customId } = interaction;

    if (interaction.isStringSelectMenu() && customId.startsWith('ajuda_menu:')) {
      const userId = customId.split(':')[1];
      if (interaction.user.id !== userId)
        return interaction.reply({ content: '❌ Este menu não é seu.', ephemeral: true });

      const valor = interaction.values[0];
      const [, catId] = valor.split(':');
      const embed = embedCategoria(catId);
      if (!embed)
        return interaction.reply({ content: '❌ Categoria inválida.', ephemeral: true });

      const sessao = sessoes.get(interaction.message.id);
      if (sessao) clearTimeout(sessao.timer);
      sessoes.set(interaction.message.id, {
        userId,
        timer: setTimeout(() => {
          interaction.message.edit({ components: [] }).catch(() => null);
          sessoes.delete(interaction.message.id);
        }, EXPIRACAO_MS),
      });

      await interaction.update({
        embeds: [embed],
        components: [botaoVoltar(userId)],
      });
    }

    if (interaction.isButton() && customId.startsWith('ajuda_voltar:')) {
      const userId = customId.split(':')[1];
      if (interaction.user.id !== userId)
        return interaction.reply({ content: '❌ Este menu não é seu.', ephemeral: true });

      const sessao = sessoes.get(interaction.message.id);
      if (sessao) clearTimeout(sessao.timer);
      sessoes.set(interaction.message.id, {
        userId,
        timer: setTimeout(() => {
          interaction.message.edit({ components: [] }).catch(() => null);
          sessoes.delete(interaction.message.id);
        }, EXPIRACAO_MS),
      });

      await interaction.update({
        embeds: [embedPrincipal()],
        components: [menuPrincipal(userId)],
      });
    }
  });
}
