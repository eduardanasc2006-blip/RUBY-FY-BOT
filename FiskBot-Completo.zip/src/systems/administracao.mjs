import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import Config from '../db/models/Config.mjs';
import { embedErro, embedSucesso } from '../utils/embeds.mjs';
import { isAdmin, isEquipe } from '../utils/permissions.mjs';
import { registrarLog } from '../utils/logger.mjs';

const sorteiosAtivos = new Map();

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'anuncio') {
      if (!isEquipe(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Sem permissão.')] });
      const texto = args.join(' ');
      if (!texto) return msg.reply({ embeds: [embedErro('Use: `!anuncio <texto>`')] });

      const embed = new EmbedBuilder()
        .setColor(0xe74c3c)
        .setTitle('📢 Anúncio Oficial')
        .setDescription(texto)
        .setAuthor({ name: msg.guild.name, iconURL: msg.guild.iconURL() })
        .setTimestamp();

      await msg.channel.send({ embeds: [embed] });
      await msg.delete().catch(() => {});
      await registrarLog(client, guildId, 'admin', msg.author.id, { descricao: `<@${msg.author.id}> fez um anúncio.` }, configs);
      return;
    }

    if (cmd === 'embed') {
      if (!isEquipe(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Sem permissão.')] });
      const texto = args.join(' ');
      if (!texto) return msg.reply({ embeds: [embedErro('Use: `!embed <texto>` — Use | para separar título e descrição')] });
      const [titulo, ...desc] = texto.split('|');
      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(titulo.trim())
        .setDescription(desc.join('|').trim() || '')
        .setTimestamp();
      await msg.channel.send({ embeds: [embed] });
      await msg.delete().catch(() => {});
      return;
    }

    if (cmd === 'enquete') {
      if (!isEquipe(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Sem permissão.')] });
      const pergunta = args.join(' ');
      if (!pergunta) return msg.reply({ embeds: [embedErro('Use: `!enquete <pergunta>`')] });
      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('📊 Enquete')
        .setDescription(pergunta)
        .setFooter({ text: 'Vote com ✅ ou ❌' })
        .setTimestamp();
      const m = await msg.channel.send({ embeds: [embed] });
      await m.react('✅');
      await m.react('❌');
      await msg.delete().catch(() => {});
      return;
    }

    if (cmd === 'sorteio') {
      if (!isEquipe(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Sem permissão.')] });
      const durMin = parseInt(args[0]) || 1;
      const premio = args.slice(1).join(' ') || 'Prêmio Surpresa';

      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle('🎉 SORTEIO!')
        .setDescription(`**Prêmio:** ${premio}\n\nReaja com 🎉 para participar!\n⏱️ Duração: **${durMin} minuto(s)**`)
        .setTimestamp();

      const m = await msg.channel.send({ embeds: [embed] });
      await m.react('🎉');

      setTimeout(async () => {
        const mensagem = await m.fetch().catch(() => null);
        if (!mensagem) return;
        const reacao = mensagem.reactions.cache.get('🎉');
        if (!reacao) return;
        const usuarios = (await reacao.users.fetch()).filter(u => !u.bot);
        if (!usuarios.size) {
          await msg.channel.send({ embeds: [new EmbedBuilder().setColor(0xe74c3c).setDescription('❌ Ninguém participou do sorteio.')] });
          return;
        }
        const arr = [...usuarios.values()];
        const ganhador = arr[Math.floor(Math.random() * arr.length)];
        await msg.channel.send({
          embeds: [new EmbedBuilder()
            .setColor(0x2ecc71)
            .setTitle('🎊 Resultado do Sorteio!')
            .setDescription(`**🏆 Ganhador:** ${ganhador}\n**🎁 Prêmio:** ${premio}\n\nParabéns!`)
            .setTimestamp()],
        });
      }, durMin * 60_000);

      await msg.delete().catch(() => {});
      return;
    }

    if (cmd === 'limpar') {
      if (!isEquipe(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Sem permissão.')] });
      const qtd = Math.min(parseInt(args[0]) || 10, 100);
      const deletadas = await msg.channel.bulkDelete(qtd + 1, true).catch(() => null);
      const qtdReal = deletadas?.size ? deletadas.size - 1 : 0;
      const m = await msg.channel.send({ embeds: [new EmbedBuilder().setColor(0xe74c3c).setDescription(`🗑️ **${qtdReal}** mensagens apagadas.`)] });
      setTimeout(() => m.delete().catch(() => {}), 3_000);
      await registrarLog(client, guildId, 'admin', msg.author.id, { descricao: `<@${msg.author.id}> apagou ${qtdReal} mensagens em #${msg.channel.name}.` }, configs);
      return;
    }

    if (cmd === 'setwelcome') {
      if (!isAdmin(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Apenas administradores.')] });
      const texto = args.join(' ');
      if (!texto) return msg.reply({ embeds: [embedErro('Use: `!setwelcome <mensagem>` — use {user} e {server}')] });
      await Config.findOneAndUpdate({ guildId }, { $set: { mensagemBemVindo: texto, canalBemVindo: msg.channel.id } }, { upsert: true });
      if (cfg) { cfg.mensagemBemVindo = texto; cfg.canalBemVindo = msg.channel.id; }
      return msg.reply({ embeds: [embedSucesso('Boas-vindas Configurado!', `Mensagem definida neste canal.`)] });
    }

    if (cmd === 'testwelcome') {
      if (!isAdmin(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Apenas administradores.')] });
      const dbCfg = await Config.findOne({ guildId });
      if (!dbCfg?.mensagemBemVindo) return msg.reply({ embeds: [embedErro('Nenhuma mensagem configurada. Use `!setwelcome` primeiro.')] });
      const texto = dbCfg.mensagemBemVindo.replace('{user}', msg.author.toString()).replace('{server}', msg.guild.name);
      await msg.channel.send({ embeds: [new EmbedBuilder().setColor(0x2ecc71).setDescription(texto)] });
      return;
    }

    if (cmd === 'setconfig') {
      if (!isAdmin(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Apenas administradores.')] });
      const [chave, valor] = args;
      const camposValidos = ['canalLogs', 'canalSuporte', 'canalDenuncias', 'canalSugestoes', 'cargoEquipe', 'cargoSuporte', 'cargoVendedor', 'cargoAdmin', 'cargoServicos', 'prefixo'];
      if (!camposValidos.includes(chave)) return msg.reply({ embeds: [embedErro(`Chave inválida. Válidas: ${camposValidos.join(', ')}`)] });

      const idExtraido = valor?.replace(/[<#@&!>]/g, '');
      await Config.findOneAndUpdate({ guildId }, { $set: { [chave]: idExtraido || valor } }, { upsert: true });
      if (cfg) cfg[chave] = idExtraido || valor;
      return msg.reply({ embeds: [embedSucesso('Configuração Atualizada', `**${chave}** = ${valor}`)] });
    }

    if (cmd === 'painel') {
      if (!isAdmin(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Apenas administradores.')] });
      const dbCfg = await Config.findOne({ guildId });

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle('⚙️ Painel de Configurações')
        .setDescription(`**Servidor:** ${msg.guild.name}`)
        .addFields(
          { name: '🔖 Prefixo', value: dbCfg?.prefixo || '!', inline: true },
          { name: '💸 Taxa Robux', value: `R$${(dbCfg?.taxa || 38).toFixed(2)}/1k`, inline: true },
          { name: '📋 Canal de Logs', value: dbCfg?.canalLogs ? `<#${dbCfg.canalLogs}>` : 'Não definido', inline: true },
          { name: '🎫 Canal Suporte', value: dbCfg?.canalSuporte ? `<#${dbCfg.canalSuporte}>` : 'Não definido', inline: true },
          { name: '🚨 Canal Denúncias', value: dbCfg?.canalDenuncias ? `<#${dbCfg.canalDenuncias}>` : 'Não definido', inline: true },
          { name: '👥 Cargo Equipe', value: dbCfg?.cargoEquipe ? `<@&${dbCfg.cargoEquipe}>` : 'Não definido', inline: true },
        )
        .setFooter({ text: 'Use !setconfig <chave> <valor> para alterar' })
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });

  client.on('guildMemberAdd', async (member) => {
    const cfg = configs.get(member.guild.id);
    const dbCfg = await Config.findOne({ guildId: member.guild.id });
    if (!dbCfg?.mensagemBemVindo || !dbCfg?.canalBemVindo) return;
    const canal = member.guild.channels.cache.get(dbCfg.canalBemVindo);
    if (!canal) return;
    const texto = dbCfg.mensagemBemVindo.replace('{user}', member.toString()).replace('{server}', member.guild.name);
    const embed = new EmbedBuilder().setColor(0xa855f7).setDescription(texto).setThumbnail(member.user.displayAvatarURL({ size: 256 })).setTimestamp();
    await canal.send({ embeds: [embed] }).catch(() => {});
  });
}
