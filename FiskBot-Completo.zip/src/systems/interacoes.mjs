import { EmbedBuilder } from 'discord.js';
import { checkCooldown, formatarTempo } from '../utils/cooldown.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { addAfinidade } from './afinidade.mjs';

const GIFS = {
  abracar: [
    'https://media.tenor.com/gNxdFE9bHHcAAAAC/hug.gif',
    'https://media.tenor.com/OR58iFQXeXkAAAAC/hug-anime.gif',
    'https://media.tenor.com/zxpgW_k9droAAAAC/anime-hug.gif',
  ],
  beijar: [
    'https://media.tenor.com/N7i2iy_Ag2UAAAAC/anime-kiss.gif',
    'https://media.tenor.com/nz_Lr7bfaLwAAAAC/kiss.gif',
    'https://media.tenor.com/f_I2Lv9HnGIAAAAC/anime-kiss.gif',
  ],
  cafune: [
    'https://media.tenor.com/lBvJXbG9sDoAAAAC/pat.gif',
    'https://media.tenor.com/aHxQKVqJlcUAAAAC/head-pat-anime.gif',
    'https://media.tenor.com/yfZOdWKpnNcAAAAC/anime-pat.gif',
  ],
  acariciar: [
    'https://media.tenor.com/yfZOdWKpnNcAAAAC/anime-pat.gif',
    'https://media.tenor.com/aHxQKVqJlcUAAAAC/head-pat-anime.gif',
  ],
  dancar: [
    'https://media.tenor.com/8gswRnwH8FIAAAAC/anime-dance.gif',
    'https://media.tenor.com/QnGOKE0K-DEAAAAC/anime-dance-cute.gif',
    'https://media.tenor.com/5WFTGvv-aS8AAAAC/dance.gif',
  ],
  elogiar: null,
  xingar: null,
  proteger: [
    'https://media.tenor.com/RFOiGbcv_z0AAAAC/anime-protect.gif',
    'https://media.tenor.com/qHBW3bm5mwoAAAAC/anime-protect.gif',
  ],
};

const ELOGIOS = [
  'Você é incrível! 🌟', 'Que pessoa maravilhosa! 💜', 'Você ilumina esse servidor! ✨',
  'É uma honra ter você aqui! 🏆', 'Você é simplesmente perfeito(a)! 💫',
];

const XINGAMENTOS = [
  'Vai varrer a rua, seu pé de alface! 🥬', 'Você tem cara de emoji de boia! 🏊',
  'Seu pé de moleque! 🥜', 'Você confunde pizza de banana com comida! 🍌',
  'Vai tomar banho, sua batata crua! 🥔',
];

const AFINIDADE_MAPA = {
  abracar: 1, beijar: 3, cafune: 2, acariciar: 2, dancar: 1, elogiar: 1, xingar: 0, proteger: 2,
};

const TEXTOS = {
  abracar: (a, b) => `🤗 <@${a}> abraçou <@${b}>!`,
  beijar: (a, b) => `💋 <@${a}> beijou <@${b}>!`,
  cafune: (a, b) => `🥰 <@${a}> fez cafuné em <@${b}>!`,
  acariciar: (a, b) => `💕 <@${a}> acariciou <@${b}>!`,
  dancar: (a, b) => `💃 <@${a}> dançou com <@${b}>!`,
  proteger: (a, b) => `🛡️ <@${a}> protegeu <@${b}>!`,
};

export function register(client, configs) {
  const cmds = ['abracar', 'beijar', 'cafune', 'acariciar', 'dancar', 'elogiar', 'xingar', 'proteger'];

  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    if (!cmds.includes(cmd)) return;

    const alvo = msg.mentions.users.first();
    if (!alvo || alvo.bot) return msg.reply({ embeds: [embedErro('Mencione um usuário válido.')] });

    const cdKey = `inter:${cmd}:${msg.author.id}:${msg.guild.id}`;
    const espera = checkCooldown(cdKey, 20_000);
    if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para usar novamente.`)] });

    const pontos = AFINIDADE_MAPA[cmd] || 0;
    let afin = { ganhou: false, pontosGanhos: 0 };
    if (pontos > 0 && alvo.id !== msg.author.id) {
      afin = await addAfinidade(msg.guild.id, msg.author.id, alvo.id, pontos);
    }

    const embed = new EmbedBuilder().setColor(0xa855f7).setTimestamp();

    if (cmd === 'elogiar') {
      const elogio = ELOGIOS[Math.floor(Math.random() * ELOGIOS.length)];
      embed.setDescription(`💬 <@${msg.author.id}> elogiou <@${alvo.id}>:\n> *${elogio}*`);
    } else if (cmd === 'xingar') {
      const xingo = XINGAMENTOS[Math.floor(Math.random() * XINGAMENTOS.length)];
      embed.setDescription(`😤 <@${msg.author.id}> para <@${alvo.id}>:\n> *${xingo}*`);
    } else {
      const gifs = GIFS[cmd];
      const gif = gifs?.[Math.floor(Math.random() * gifs.length)];
      const texto = TEXTOS[cmd]?.(msg.author.id, alvo.id) || `<@${msg.author.id}> interagiu com <@${alvo.id}>`;
      embed.setDescription(texto);
      if (gif) embed.setImage(gif);
    }

    if (afin.ganhou && pontos > 0) {
      embed.setFooter({ text: `+${pontos} Afinidade! Total: ${afin.pontos} pts` });
    } else if (pontos > 0) {
      embed.setFooter({ text: 'Afinidade: já ganhada hoje (próxima em 12h)' });
    }

    return msg.reply({ embeds: [embed] });
  });
}
