import { EmbedBuilder } from 'discord.js';
import Config from '../db/models/Config.mjs';
import { isAdmin } from '../utils/permissions.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { registrarLog } from '../utils/logger.mjs';

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const taxa = cfg?.taxa || 38;

    if (cmd === 'robux') {
      const valor = parseFloat(args[0]?.replace(',', '.'));
      if (!valor || isNaN(valor)) return msg.reply({ embeds: [embedErro('Use: `!robux <valor em reais>`')] });
      const robux = Math.floor((valor / taxa) * 1000);
      const embed = new EmbedBuilder()
        .setColor(0x00a2ff)
        .setTitle('💰 Conversão BRL → Robux')
        .setDescription(`**R$${valor.toFixed(2)}** ≈ **${robux.toLocaleString('pt-BR')} Robux**`)
        .addFields({ name: 'Taxa atual', value: `1.000 Robux = R$${taxa.toFixed(2)}`, inline: true })
        .setFooter({ text: 'FiskBot • Conversão' })
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'brl') {
      const robux = parseInt(args[0]?.replace(/\./g, ''));
      if (!robux || isNaN(robux)) return msg.reply({ embeds: [embedErro('Use: `!brl <quantidade de robux>`')] });
      const valor = (robux / 1000) * taxa;
      const embed = new EmbedBuilder()
        .setColor(0x00a2ff)
        .setTitle('💰 Conversão Robux → BRL')
        .setDescription(`**${robux.toLocaleString('pt-BR')} Robux** ≈ **R$${valor.toFixed(2)}**`)
        .addFields({ name: 'Taxa atual', value: `1.000 Robux = R$${taxa.toFixed(2)}`, inline: true })
        .setFooter({ text: 'FiskBot • Conversão' })
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'taxa') {
      const embed = new EmbedBuilder()
        .setColor(0x00a2ff)
        .setTitle('📊 Taxa Atual')
        .setDescription(`**1.000 Robux = R$${taxa.toFixed(2)}**`)
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'simular') {
      const v1 = parseInt(args[0]?.replace(/\./g, ''));
      const v2 = parseInt(args[1]?.replace(/\./g, ''));
      if (!v1 || !v2 || isNaN(v1) || isNaN(v2)) return msg.reply({ embeds: [embedErro('Use: `!simular <min> <max>`')] });
      const steps = gerarSteps(Math.min(v1, v2), Math.max(v2, v1));
      const linhas = steps.map(r => `**${r.toLocaleString('pt-BR')}** Robux = R$${((r / 1000) * taxa).toFixed(2)}`);
      const embed = new EmbedBuilder()
        .setColor(0x00a2ff)
        .setTitle('📋 Simulação de Preços')
        .setDescription(linhas.join('\n'))
        .addFields({ name: 'Taxa', value: `1.000 Robux = R$${taxa.toFixed(2)}`, inline: true })
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'historico') {
      const dbCfg = await Config.findOne({ guildId: msg.guild.id });
      const hist = dbCfg?.taxaHistorico?.slice(-10).reverse() || [];
      if (!hist.length) return msg.reply({ embeds: [embedErro('Nenhuma alteração registrada.')] });
      const linhas = hist.map(h => {
        const data = new Date(h.data).toLocaleDateString('pt-BR');
        return `**${data}** — R$${h.taxa.toFixed(2)} por 1k • <@${h.adminId}>`;
      });
      const embed = new EmbedBuilder().setColor(0x00a2ff).setTitle('📜 Histórico de Taxa').setDescription(linhas.join('\n')).setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'comparar') {
      const robux = parseInt(args[0]?.replace(/\./g, ''));
      if (!robux || isNaN(robux)) return msg.reply({ embeds: [embedErro('Use: `!comparar <robux>`')] });
      const bruto = (robux / 1000) * taxa;
      const taxaPlat = bruto * 0.1;
      const liquido = bruto - taxaPlat;
      const embed = new EmbedBuilder()
        .setColor(0x00a2ff)
        .setTitle(`💱 Comparação — ${robux.toLocaleString('pt-BR')} Robux`)
        .addFields(
          { name: '💰 Valor Bruto', value: `R$${bruto.toFixed(2)}`, inline: true },
          { name: '📉 Taxa (10%)', value: `R$${taxaPlat.toFixed(2)}`, inline: true },
          { name: '✅ Valor Líquido', value: `R$${liquido.toFixed(2)}`, inline: true },
        ).setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'meta') {
      const robux = parseInt(args[0]?.replace(/\./g, ''));
      if (!robux || isNaN(robux)) return msg.reply({ embeds: [embedErro('Use: `!meta <robux>`')] });
      const necessario = (robux / 1000) * taxa;
      const embed = new EmbedBuilder()
        .setColor(0x00a2ff)
        .setTitle('🎯 Calculadora de Meta')
        .addFields(
          { name: '🎮 Meta em Robux', value: `${robux.toLocaleString('pt-BR')} Robux`, inline: true },
          { name: '💰 Necessário em BRL', value: `R$${necessario.toFixed(2)}`, inline: true },
        ).setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'settaxa') {
      if (!isAdmin(msg.member, cfg)) return msg.reply({ embeds: [embedErro('Sem permissão.')] });
      const novatTaxa = parseFloat(args[0]?.replace(',', '.'));
      if (!novatTaxa || isNaN(novatTaxa)) return msg.reply({ embeds: [embedErro('Use: `!settaxa <valor>`')] });
      await Config.findOneAndUpdate(
        { guildId: msg.guild.id },
        {
          $set: { taxa: novatTaxa },
          $push: { taxaHistorico: { taxa: novatTaxa, adminId: msg.author.id, data: new Date() } },
        },
        { upsert: true }
      );
      if (cfg) cfg.taxa = novatTaxa;
      await registrarLog(client, msg.guild.id, 'admin', msg.author.id, { descricao: `Taxa alterada para R$${novatTaxa.toFixed(2)} por <@${msg.author.id}>` }, configs);
      return msg.reply({ embeds: [new EmbedBuilder().setColor(0x2ecc71).setDescription(`✅ Taxa atualizada para **R$${novatTaxa.toFixed(2)}** por 1.000 Robux.`)] });
    }
  });
}

function gerarSteps(min, max) {
  const passos = [100, 250, 500, 1000, 2000, 5000, 10000, 25000, 50000, 100000];
  const resultado = passos.filter(p => p >= min && p <= max);
  if (!resultado.length) {
    const step = Math.floor((max - min) / 5);
    for (let i = 0; i <= 5; i++) resultado.push(min + step * i);
  }
  return [...new Set(resultado)].slice(0, 10);
}
