import { EmbedBuilder } from 'discord.js';
import Usuario from '../db/models/Usuario.mjs';
import Conquista from '../db/models/Conquista.mjs';
import { embedErro, embedSucesso } from '../utils/embeds.mjs';

const TITULOS_DISPONIVEIS = [
  { id: 'novato', nome: '🌱 Novato', origem: 'nivel', nivel: 1 },
  { id: 'aventureiro', nome: '⚔️ Aventureiro', origem: 'nivel', nivel: 5 },
  { id: 'veterano', nome: '🛡️ Veterano', origem: 'nivel', nivel: 10 },
  { id: 'elite', nome: '💎 Elite', origem: 'nivel', nivel: 15 },
  { id: 'lenda', nome: '🌟 Lenda', origem: 'nivel', nivel: 20 },
  { id: 'mestre', nome: '👑 Mestre', origem: 'nivel', nivel: 30 },
  { id: 'imortal', nome: '⚡ Imortal', origem: 'nivel', nivel: 40 },
  { id: 'supremo', nome: '🔥 Supremo', origem: 'nivel', nivel: 50 },
  { id: 'mitico', nome: '🌌 Mítico', origem: 'nivel', nivel: 60 },
  { id: 'celestial', nome: '✨ Celestial', origem: 'nivel', nivel: 70 },
  { id: 'divino', nome: '🌠 Divino', origem: 'nivel', nivel: 80 },
  { id: 'deus_servidor', nome: '⚡ Deus do Servidor', origem: 'nivel', nivel: 100 },
  { id: 'mestre_quiz', nome: '🧠 Mestre Quiz', origem: 'conquista', conquista: 'quiz_100' },
  { id: 'alma_gemea_titulo', nome: '💜 Alma Gêmea', origem: 'conquista', conquista: 'alma_gemea' },
];

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'titulos') {
      const u = await Usuario.findOne({ userId: msg.author.id, guildId });
      const conquistas = (await Conquista.findOne({ userId: msg.author.id, guildId }))?.conquistas || [];
      const { calcularNivel } = await import('../utils/nivelCalc.mjs');
      const { nivel } = calcularNivel(u?.xp || 0);

      const titulosUser = u?.titulos || [];
      const disponiveis = TITULOS_DISPONIVEIS.filter(t => {
        if (t.origem === 'nivel') return nivel >= t.nivel;
        if (t.origem === 'conquista') return conquistas.includes(t.conquista);
        return false;
      });

      const linhas = TITULOS_DISPONIVEIS.map(t => {
        const disponivel = disponiveis.find(d => d.id === t.id);
        const equipado = u?.tituloEquipado === t.nome;
        if (!disponivel) return `🔒 **${t.nome}** *(bloqueado)*`;
        return `${equipado ? '✅' : '🔓'} **${t.nome}** ${equipado ? '*(equipado)*' : ''}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle('👑 Seus Títulos')
        .setDescription(linhas.join('\n'))
        .setFooter({ text: `Use !equipartitulo <nome> para equipar` })
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'equipartitulo') {
      const nome = args.join(' ');
      if (!nome) return msg.reply({ embeds: [embedErro('Use: `!equipartitulo <nome do título>`')] });

      const titulo = TITULOS_DISPONIVEIS.find(t => t.nome.toLowerCase().includes(nome.toLowerCase()));
      if (!titulo) return msg.reply({ embeds: [embedErro('Título não encontrado.')] });

      const u = await Usuario.findOne({ userId: msg.author.id, guildId });
      const conquistas = (await Conquista.findOne({ userId: msg.author.id, guildId }))?.conquistas || [];
      const { calcularNivel } = await import('../utils/nivelCalc.mjs');
      const { nivel } = calcularNivel(u?.xp || 0);

      const disponivel = (titulo.origem === 'nivel' && nivel >= titulo.nivel) ||
        (titulo.origem === 'conquista' && conquistas.includes(titulo.conquista));
      if (!disponivel) return msg.reply({ embeds: [embedErro('Você ainda não desbloqueou esse título.')] });

      await Usuario.updateOne({ userId: msg.author.id, guildId }, { $set: { tituloEquipado: titulo.nome }, $setOnInsert: { userId: msg.author.id, guildId } }, { upsert: true });
      return msg.reply({ embeds: [embedSucesso('Título Equipado!', `Você equipou o título **${titulo.nome}**.`)] });
    }
  });
}
