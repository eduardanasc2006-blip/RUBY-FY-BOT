import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import QuizModel from '../db/models/Quiz.mjs';
import Usuario from '../db/models/Usuario.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { checkCooldown, formatarTempo } from '../utils/cooldown.mjs';
import { progredirMissao } from './missoes.mjs';

const PERGUNTAS = {
  roblox: [
    { p: 'Em que ano o Roblox foi lançado ao público?', ops: ['2004', '2006', '2008', '2010'], r: 1 },
    { p: 'Qual é a moeda principal do Roblox?', ops: ['Tix', 'Robux', 'Gold', 'Coins'], r: 1 },
    { p: 'Quem criou o Roblox?', ops: ['David Baszucki', 'Mark Zuckerberg', 'Notch', 'Erik Cassel'], r: 0 },
    { p: 'O que significa "R$" no Roblox?', ops: ['Real', 'Robux', 'Reward', 'Rank'], r: 1 },
    { p: 'Qual é o nome do personagem padrão do Roblox?', ops: ['Noob', 'Guest', 'Robloxian', 'Builder'], r: 2 },
  ],
  anime: [
    { p: 'Qual é o personagem principal de Naruto?', ops: ['Sasuke', 'Naruto Uzumaki', 'Itachi', 'Kakashi'], r: 1 },
    { p: 'Em One Piece, qual é o sonho de Luffy?', ops: ['Ser o mais forte', 'Encontrar One Piece', 'Salvar Ace', 'Ser Rei dos Piratas'], r: 3 },
    { p: 'Qual anime tem o personagem Goku?', ops: ['Naruto', 'Dragon Ball', 'Bleach', 'One Piece'], r: 1 },
    { p: 'Em qual anime aparece o Titan Colossal?', ops: ['Sword Art Online', 'Attack on Titan', 'Demon Slayer', 'My Hero Academia'], r: 1 },
    { p: 'Qual é o poder do Deku em My Hero Academia?', ops: ['Sharingan', 'One For All', 'Haki', 'Quirk Fire'], r: 1 },
  ],
  matematica: [
    { p: 'Quanto é 15 × 15?', ops: ['200', '220', '225', '230'], r: 2 },
    { p: 'Qual é a raiz quadrada de 144?', ops: ['10', '11', '12', '13'], r: 2 },
    { p: 'Quanto é 2⁸?', ops: ['128', '256', '512', '64'], r: 1 },
    { p: 'Qual é o valor de π (pi) aproximado?', ops: ['3.14', '3.16', '3.12', '3.18'], r: 0 },
    { p: '10% de 250 é:', ops: ['20', '25', '30', '35'], r: 1 },
  ],
  tecnologia: [
    { p: 'O que significa "CPU"?', ops: ['Central Processing Unit', 'Computer Power Unit', 'Core Processing Unit', 'Central Power Unit'], r: 0 },
    { p: 'Qual linguagem criou a World Wide Web?', ops: ['Python', 'HTML', 'C++', 'Java'], r: 1 },
    { p: 'Quem fundou a Microsoft?', ops: ['Steve Jobs', 'Elon Musk', 'Bill Gates', 'Larry Page'], r: 2 },
    { p: 'O que é RAM?', ops: ['Read Access Memory', 'Random Access Memory', 'Rapid Access Module', 'Root Access Memory'], r: 1 },
    { p: 'Em que ano foi criado o Python?', ops: ['1985', '1989', '1991', '1995'], r: 2 },
  ],
  historia: [
    { p: 'Em que ano o Brasil se tornou independente?', ops: ['1820', '1822', '1825', '1830'], r: 1 },
    { p: 'Quem foi o primeiro presidente do Brasil?', ops: ['Dom Pedro II', 'Getúlio Vargas', 'Deodoro da Fonseca', 'Floriano Peixoto'], r: 2 },
    { p: 'Em que ano ocorreu a Segunda Guerra Mundial?', ops: ['1935-1942', '1939-1945', '1941-1946', '1938-1944'], r: 1 },
    { p: 'Quem descobriu o Brasil?', ops: ['Cristóvão Colombo', 'Vasco da Gama', 'Pedro Álvares Cabral', 'Fernão de Magalhães'], r: 2 },
    { p: 'Em que ano o homem chegou à Lua?', ops: ['1965', '1967', '1969', '1971'], r: 2 },
  ],
};

const jogosAtivos = new Map();

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'quiz') {
      const cdKey = `quiz:${msg.author.id}:${guildId}`;
      const espera = checkCooldown(cdKey, 15_000);
      if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para jogar novamente.`)] });

      const categoriaInput = args[0]?.toLowerCase();
      const cats = Object.keys(PERGUNTAS);
      const categoria = cats.find(c => c.includes(categoriaInput)) || cats[Math.floor(Math.random() * cats.length)];
      const perguntas = PERGUNTAS[categoria];
      const pergunta = perguntas[Math.floor(Math.random() * perguntas.length)];

      const chave = `${msg.author.id}:${guildId}`;
      if (jogosAtivos.has(chave)) return msg.reply({ embeds: [embedErro('Você já tem um quiz em andamento!')] });

      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle(`🧠 Quiz — ${categoria.charAt(0).toUpperCase() + categoria.slice(1)}`)
        .setDescription(`**${pergunta.p}**`)
        .setFooter({ text: 'Você tem 30 segundos para responder!' })
        .setTimestamp();

      const botoes = pergunta.ops.map((op, i) =>
        new ButtonBuilder().setCustomId(`quiz:${i}:${msg.author.id}:${guildId}`).setLabel(`${['A', 'B', 'C', 'D'][i]}) ${op}`).setStyle(ButtonStyle.Primary)
      );
      const row = new ActionRowBuilder().addComponents(botoes);
      const quizMsg = await msg.reply({ embeds: [embed], components: [row] });

      jogosAtivos.set(chave, { correto: pergunta.r, categoria, msgId: quizMsg.id });
      setTimeout(async () => {
        if (!jogosAtivos.has(chave)) return;
        jogosAtivos.delete(chave);
        await quizMsg.edit({ components: [] }).catch(() => {});
        await msg.channel.send({ embeds: [new EmbedBuilder().setColor(0xe74c3c).setDescription(`⏰ <@${msg.author.id}> o tempo esgotou! A resposta era: **${['A', 'B', 'C', 'D'][pergunta.r]}) ${pergunta.ops[pergunta.r]}**`)] }).catch(() => {});
      }, 30_000);
      return;
    }

    if (cmd === 'quizstats') {
      const alvo = msg.mentions.users.first() || msg.author;
      const doc = await QuizModel.findOne({ userId: alvo.id, guildId });
      if (!doc || doc.total === 0) return msg.reply({ embeds: [embedErro('Nenhum quiz registrado.')] });

      const precisao = ((doc.acertos / doc.total) * 100).toFixed(1);
      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle(`📊 Stats de Quiz — ${alvo.displayName}`)
        .addFields(
          { name: '📝 Total', value: String(doc.total), inline: true },
          { name: '✅ Acertos', value: String(doc.acertos), inline: true },
          { name: '❌ Erros', value: String(doc.erros), inline: true },
          { name: '🎯 Precisão', value: `${precisao}%`, inline: true },
          { name: '⭐ Favorita', value: doc.categoriaFavorita || 'N/A', inline: true },
        )
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'topquiz') {
      const top = await QuizModel.find({ guildId }).sort({ acertos: -1 }).limit(10).lean();
      const linhas = top.map((u, i) => `**#${i + 1}** <@${u.userId}> — ✅ ${u.acertos} acertos (${u.total} jogos)`);
      const embed = new EmbedBuilder()
        .setColor(0x3498db)
        .setTitle('🏆 Top Quiz')
        .setDescription(linhas.join('\n') || 'Nenhum dado.')
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton() || !interaction.customId.startsWith('quiz:')) return;
    const [, respostaStr, userId, guildId] = interaction.customId.split(':');
    if (interaction.user.id !== userId) return interaction.reply({ content: 'Este quiz não é seu.', ephemeral: true });

    const chave = `${userId}:${guildId}`;
    const jogo = jogosAtivos.get(chave);
    if (!jogo) return interaction.reply({ content: 'Este quiz expirou.', ephemeral: true });

    jogosAtivos.delete(chave);
    const resposta = parseInt(respostaStr);
    const correto = resposta === jogo.correto;
    const xpGanho = correto ? 30 : 0;

    await QuizModel.findOneAndUpdate(
      { userId, guildId },
      { $inc: { total: 1, acertos: correto ? 1 : 0, erros: correto ? 0 : 1 }, $setOnInsert: { userId, guildId } },
      { upsert: true }
    );

    if (correto && xpGanho > 0) {
      await Usuario.updateOne({ userId, guildId }, { $inc: { xp: xpGanho }, $setOnInsert: { userId, guildId } }, { upsert: true });
    }

    await progredirMissao(userId, guildId, 'quiz').catch(() => {});

    const embed = new EmbedBuilder()
      .setColor(correto ? 0x2ecc71 : 0xe74c3c)
      .setDescription(correto ? `✅ Correto! <@${userId}> acertou! +${xpGanho} XP` : `❌ Errado! A resposta certa era a opção **${['A', 'B', 'C', 'D'][jogo.correto]}**`)
      .setTimestamp();

    await interaction.update({ embeds: [embed], components: [] }).catch(() => {});
  });
}
