import { EmbedBuilder } from 'discord.js';
import Afinidade from '../db/models/Afinidade.mjs';
import Casamento from '../db/models/Casamento.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { nivelAfinidade } from '../utils/nivelCalc.mjs';

function chaveAfin(u1, u2) {
  return u1 < u2 ? [u1, u2] : [u2, u1];
}

export async function addAfinidade(guildId, userId1, userId2, pontos) {
  const [u1, u2] = chaveAfin(userId1, userId2);
  const agora = new Date();
  const doc = await Afinidade.findOne({ guildId, userId1: u1, userId2: u2 });

  if (doc) {
    const ultimaHora = doc.ultimaInteracao ? (agora - doc.ultimaInteracao) / 3600000 : 99;
    const ganhou = ultimaHora >= 12;
    if (ganhou) {
      doc.pontos += pontos;
      doc.interacoes += 1;
      doc.ultimaInteracao = agora;
      await doc.save();
    } else {
      doc.interacoes += 1;
      await doc.save();
    }
    return { pontos: doc.pontos, ganhou, pontosGanhos: ganhou ? pontos : 0 };
  }

  const novo = await Afinidade.create({ guildId, userId1: u1, userId2: u2, pontos, interacoes: 1, ultimaInteracao: agora });
  return { pontos: novo.pontos, ganhou: true, pontosGanhos: pontos };
}

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'afinidade') {
      const alvo = msg.mentions.users.first();
      if (!alvo || alvo.bot) return msg.reply({ embeds: [embedErro('Mencione um usuário válido.')] });
      if (alvo.id === msg.author.id) return msg.reply({ embeds: [embedErro('Você não pode ver sua afinidade consigo mesmo.')] });

      const [u1, u2] = chaveAfin(msg.author.id, alvo.id);
      const doc = await Afinidade.findOne({ guildId, userId1: u1, userId2: u2 });
      const pontos = doc?.pontos || 0;
      const nivel = nivelAfinidade(pontos);
      const dias = doc?.ultimaInteracao ? Math.floor((Date.now() - doc.ultimaInteracao.getTime()) / 86400000) : 0;

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(`💜 Afinidade com ${alvo.displayName}`)
        .addFields(
          { name: '⭐ Pontos', value: `${pontos}`, inline: true },
          { name: '📊 Nível', value: nivel, inline: true },
          { name: '🤝 Interações', value: String(doc?.interacoes || 0), inline: true },
          { name: '📅 Última interação', value: doc?.ultimaInteracao ? `${dias} dia(s) atrás` : 'Nunca', inline: true },
        )
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'topafinidade') {
      const casamentos = await Casamento.find({ guildId, ativo: true }).lean();
      const dados = await Promise.all(casamentos.map(async (c) => {
        const [u1, u2] = chaveAfin(c.userId1, c.userId2);
        const afin = await Afinidade.findOne({ guildId, userId1: u1, userId2: u2 });
        return { c, pontos: afin?.pontos || 0 };
      }));
      dados.sort((a, b) => b.pontos - a.pontos);
      const linhas = dados.slice(0, 10).map((d, i) =>
        `**#${i + 1}** <@${d.c.userId1}> 💜 <@${d.c.userId2}> — **${d.pontos}** pts (${nivelAfinidade(d.pontos)})`
      );
      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle('💜 Top Afinidade (Casais Oficiais)')
        .setDescription(linhas.join('\n') || 'Nenhum dado registrado.')
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });
}
