import { EmbedBuilder, AttachmentBuilder } from 'discord.js';
import { checkCooldown, formatarTempo } from '../utils/cooldown.mjs';
import { embedErro } from '../utils/embeds.mjs';

const TEMAS = [
  { min: 0, max: 20, nome: 'Sombrio', cor: '#2c2c2c', msg: 'Talvez seja melhor manter distância...', emoji: '💀' },
  { min: 21, max: 40, nome: 'Neutro', cor: '#7f8c8d', msg: 'Existe potencial, mas ainda é cedo.', emoji: '🤔' },
  { min: 41, max: 60, nome: 'Amizade', cor: '#27ae60', msg: 'Uma amizade muito promissora.', emoji: '🤝' },
  { min: 61, max: 80, nome: 'Romântico', cor: '#e91e8c', msg: 'Talvez exista algo especial aqui.', emoji: '💕' },
  { min: 81, max: 100, nome: 'Alma Gêmea', cor: '#f1c40f', msg: 'Feitos um para o outro.', emoji: '💜' },
];

function getTema(pct) {
  return TEMAS.find(t => pct >= t.min && pct <= t.max) || TEMAS[4];
}

function gerarBarra(pct, tamanho = 20) {
  const preenchido = Math.round((pct / 100) * tamanho);
  return '█'.repeat(preenchido) + '░'.repeat(tamanho - preenchido);
}

function gerarPorcentagem(id1, id2) {
  const seed = (BigInt(id1) + BigInt(id2)).toString();
  let hash = 0;
  for (const char of seed) hash = (hash * 31 + char.charCodeAt(0)) | 0;
  return Math.abs(hash) % 101;
}

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    if (cmd !== 'ship') return;

    const mencionados = msg.mentions.users;
    const u1 = mencionados.first();
    const u2 = mencionados.at(1);

    if (!u1 || !u2) return msg.reply({ embeds: [embedErro('Use: `!ship @usuario1 @usuario2`')] });
    if (u1.id === u2.id) return msg.reply({ embeds: [embedErro('Mencione dois usuários diferentes.')] });

    const cdKey = `ship:${[u1.id, u2.id].sort().join(':')}:${msg.guild.id}`;
    const espera = checkCooldown(cdKey, 20_000);
    if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para usar este par novamente.`)] });

    const pct = gerarPorcentagem(u1.id, u2.id);
    const tema = getTema(pct);
    const barra = gerarBarra(pct);

    let corNum = 0xa855f7;
    try { corNum = parseInt(tema.cor.replace('#', ''), 16); } catch {}

    const embed = new EmbedBuilder()
      .setColor(corNum)
      .setTitle(`${tema.emoji} Ship — ${u1.displayName} & ${u2.displayName}`)
      .setDescription(`**${u1.displayName}** ❤️ **${u2.displayName}**\n\n\`${barra}\`\n**${pct}%** — ${tema.nome}`)
      .addFields(
        { name: '💬 Mensagem', value: tema.msg, inline: false },
        { name: '🎭 Tema', value: tema.nome, inline: true },
        { name: '💯 Compatibilidade', value: `${pct}%`, inline: true },
      )
      .setThumbnail(u1.displayAvatarURL({ size: 256 }))
      .setFooter({ text: `${u2.displayName} • FiskBot Ship`, iconURL: u2.displayAvatarURL({ size: 64 }) })
      .setTimestamp();

    return msg.reply({ embeds: [embed] });
  });
}
