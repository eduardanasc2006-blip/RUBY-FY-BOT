import { EmbedBuilder } from 'discord.js';
import Conquista from '../db/models/Conquista.mjs';
import Usuario from '../db/models/Usuario.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { registrarLog } from '../utils/logger.mjs';
import { calcularNivel } from '../utils/nivelCalc.mjs';

export const LISTA_CONQUISTAS = [
  { id: 'primeira_mensagem', nome: '💬 Primeira Mensagem', descricao: 'Envie sua primeira mensagem', xp: 50 },
  { id: 'mensagens_100', nome: '📢 100 Mensagens', descricao: 'Envie 100 mensagens', xp: 100 },
  { id: 'mensagens_500', nome: '🎙️ 500 Mensagens', descricao: 'Envie 500 mensagens', xp: 250 },
  { id: 'mensagens_1000', nome: '📡 1000 Mensagens', descricao: 'Envie 1000 mensagens', xp: 500 },
  { id: 'primeiro_quiz', nome: '🧠 Primeiro Quiz', descricao: 'Responda seu primeiro quiz', xp: 50 },
  { id: 'quiz_100', nome: '🎓 100 Quizzes', descricao: 'Responda 100 quizzes', xp: 300 },
  { id: 'primeira_rep', nome: '⭐ Primeira Reputação', descricao: 'Receba sua primeira rep', xp: 50 },
  { id: 'primeiro_casamento', nome: '💍 Primeiro Casamento', descricao: 'Case-se com alguém', xp: 100 },
  { id: 'primeiro_ticket', nome: '🎫 Primeiro Ticket', descricao: 'Abra seu primeiro ticket', xp: 50 },
  { id: 'nivel_10', nome: '🏆 Veterano', descricao: 'Alcance o nível 10', xp: 200, secreta: false },
  { id: 'nivel_30', nome: '⚡ Mestre', descricao: 'Alcance o nível 30', xp: 500, secreta: true },
  { id: 'nivel_50', nome: '👑 Lenda do Servidor', descricao: 'Alcance o nível 50', xp: 1000, secreta: true },
  { id: 'alma_gemea', nome: '💜 Casal Perfeito', descricao: 'Tenha 1000+ pontos de afinidade', xp: 300, secreta: true },
];

export async function verificarConquistas(client, userId, guildId, usuario, configs) {
  const doc = await Conquista.findOne({ userId, guildId }) ||
    await Conquista.create({ userId, guildId });

  const desbloqueadas = doc.conquistas;
  const novas = [];

  const mensagens = usuario.mensagens || 0;
  const { nivel } = calcularNivel(usuario.xp || 0);

  const checks = [
    { id: 'primeira_mensagem', ok: mensagens >= 1 },
    { id: 'mensagens_100', ok: mensagens >= 100 },
    { id: 'mensagens_500', ok: mensagens >= 500 },
    { id: 'mensagens_1000', ok: mensagens >= 1000 },
    { id: 'nivel_10', ok: nivel >= 10 },
    { id: 'nivel_30', ok: nivel >= 30 },
    { id: 'nivel_50', ok: nivel >= 50 },
  ];

  for (const check of checks) {
    if (check.ok && !desbloqueadas.includes(check.id)) {
      novas.push(check.id);
    }
  }

  if (novas.length > 0) {
    await Conquista.updateOne({ userId, guildId }, { $push: { conquistas: { $each: novas } } });
    for (const id of novas) {
      const conquista = LISTA_CONQUISTAS.find(c => c.id === id);
      if (!conquista) continue;
      if (conquista.xp) {
        await Usuario.updateOne({ userId, guildId }, { $inc: { xp: conquista.xp } });
      }
      await registrarLog(client, guildId, 'conquista', userId, {
        descricao: `<@${userId}> desbloqueou a conquista **${conquista.nome}**!`,
      }, configs);
    }
  }
}

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'conquistas' || cmd === 'badges') {
      const alvo = msg.mentions.users.first() || msg.author;
      const doc = await Conquista.findOne({ userId: alvo.id, guildId });
      const desbloqueadas = doc?.conquistas || [];

      const visiveis = LISTA_CONQUISTAS.filter(c => !c.secreta || desbloqueadas.includes(c.id));
      const linhas = visiveis.map(c => {
        const ok = desbloqueadas.includes(c.id);
        return `${ok ? '✅' : '🔒'} **${c.nome}** — ${c.descricao}`;
      });

      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle(`🏅 Conquistas de ${alvo.displayName}`)
        .setDescription(linhas.join('\n') || 'Nenhuma conquista disponível.')
        .setFooter({ text: `${desbloqueadas.length}/${LISTA_CONQUISTAS.length} desbloqueadas` })
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });
}
