import { EmbedBuilder } from 'discord.js';
import Usuario from '../db/models/Usuario.mjs';
import { checkCooldown, formatarTempo } from '../utils/cooldown.mjs';
import { embedErro, embedSucesso } from '../utils/embeds.mjs';
import { registrarLog } from '../utils/logger.mjs';

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    const guildId = msg.guild.id;

    if (cmd === 'rep') {
      const alvo = msg.mentions.users.first();
      if (!alvo || alvo.bot) return msg.reply({ embeds: [embedErro('Mencione um usuário válido.')] });
      if (alvo.id === msg.author.id) return msg.reply({ embeds: [embedErro('Você não pode dar reputação a si mesmo.')] });

      const cdKey = `rep:${msg.author.id}:${guildId}`;
      const espera = checkCooldown(cdKey, 24 * 3600 * 1000);
      if (espera) {
        const h = Math.floor(espera / 3600);
        const m = Math.floor((espera % 3600) / 60);
        return msg.reply({ embeds: [embedErro(`Você já deu reputação hoje. Próxima em **${h}h ${m}m**.`)] });
      }

      await Usuario.findOneAndUpdate(
        { userId: alvo.id, guildId },
        { $inc: { reputacao: 1 }, $setOnInsert: { userId: alvo.id, guildId } },
        { upsert: true, new: true }
      );

      await registrarLog(client, guildId, 'reputacao', msg.author.id, {
        descricao: `<@${msg.author.id}> deu +1 rep para <@${alvo.id}>`,
      }, configs);

      return msg.reply({
        embeds: [new EmbedBuilder()
          .setColor(0xffd700)
          .setDescription(`⭐ <@${msg.author.id}> deu **+1 reputação** para <@${alvo.id}>!`)
          .setTimestamp()],
      });
    }

    if (cmd === 'ranking') {
      const top = await Usuario.find({ guildId }).sort({ reputacao: -1 }).limit(10).lean();
      const linhas = top.map((u, i) => `**#${i + 1}** <@${u.userId}> — ⭐ ${u.reputacao} rep`);
      const embed = new EmbedBuilder()
        .setColor(0xffd700)
        .setTitle('⭐ Ranking de Reputação')
        .setDescription(linhas.join('\n') || 'Nenhum dado ainda.')
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'meuperfil') {
      const alvo = msg.mentions.users.first() || msg.author;
      const u = await Usuario.findOne({ userId: alvo.id, guildId });
      const { calcularNivel } = await import('../utils/nivelCalc.mjs');
      const { nivel, xpAtual, xpProximo } = calcularNivel(u?.xp || 0);
      const barra = gerarBarra(xpAtual, xpProximo);

      const embed = new EmbedBuilder()
        .setColor(0xa855f7)
        .setTitle(`📋 Perfil de ${alvo.displayName}`)
        .setThumbnail(alvo.displayAvatarURL({ size: 256 }))
        .addFields(
          { name: '⭐ XP', value: `${u?.xp || 0}`, inline: true },
          { name: '🏆 Nível', value: String(nivel), inline: true },
          { name: '📊 Progresso', value: `${barra} ${xpAtual}/${xpProximo}`, inline: false },
          { name: '💜 Reputação', value: String(u?.reputacao || 0), inline: true },
          { name: '👑 Título', value: u?.tituloEquipado || 'Nenhum', inline: true },
          { name: '💬 Mensagens', value: String(u?.mensagens || 0), inline: true },
        )
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });
}

function gerarBarra(atual, total, tamanho = 10) {
  const preenchido = Math.round((atual / total) * tamanho);
  return '█'.repeat(preenchido) + '░'.repeat(tamanho - preenchido);
}
