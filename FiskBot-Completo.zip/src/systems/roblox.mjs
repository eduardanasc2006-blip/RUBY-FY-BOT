import { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { checkCooldown, formatarTempo } from '../utils/cooldown.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { registrarLog } from '../utils/logger.mjs';

const API = 'https://api.roblox.com';
const API2 = 'https://users.roblox.com/v1';
const THUMB = 'https://thumbnails.roblox.com/v1';

async function fetchJSON(url) {
  const r = await fetch(url, { headers: { 'Accept': 'application/json' } });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  return r.json();
}

async function resolverUsuario(nome) {
  const r = await fetch('https://users.roblox.com/v1/usernames/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usernames: [nome], excludeBannedUsers: false }),
  });
  const d = await r.json();
  return d.data?.[0] || null;
}

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    if (!msg.content.startsWith(prefixo)) return;

    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();

    const CDKey = (c) => `roblox:${c}:${msg.author.id}:${msg.guild.id}`;
    const CD_MS = 20_000;

    if (cmd === 'perfil') {
      const nome = args.join(' ');
      if (!nome) return msg.reply({ embeds: [embedErro('Use: `!perfil <usuário roblox>`')] });
      const espera = checkCooldown(CDKey('perfil'), CD_MS);
      if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para usar novamente.`)] });
      const loading = await msg.reply('🔍 Buscando perfil...');
      try {
        const user = await resolverUsuario(nome);
        if (!user) { await loading.edit({ content: null, embeds: [embedErro('Usuário não encontrado.')] }); return; }
        const [info, friends, followers, following, thumb] = await Promise.all([
          fetchJSON(`${API2}/users/${user.id}`),
          fetchJSON(`${API}/users/${user.id}/friends/count`),
          fetchJSON(`https://friends.roblox.com/v1/users/${user.id}/followers/count`),
          fetchJSON(`https://friends.roblox.com/v1/users/${user.id}/followings/count`),
          fetchJSON(`${THUMB}/users/avatar-headshot?userIds=${user.id}&size=420x420&format=Png`),
        ]);
        const avatarUrl = thumb.data?.[0]?.imageUrl;
        const embed = new EmbedBuilder()
          .setColor(0x00a2ff)
          .setTitle(`🎮 ${info.displayName} (@${info.name})`)
          .setThumbnail(avatarUrl || null)
          .addFields(
            { name: '🆔 ID', value: String(info.id), inline: true },
            { name: '📅 Criado em', value: new Date(info.created).toLocaleDateString('pt-BR'), inline: true },
            { name: '👥 Amigos', value: String(friends.count ?? 0), inline: true },
            { name: '👁️ Seguidores', value: String(followers.count ?? 0), inline: true },
            { name: '➡️ Seguindo', value: String(following.count ?? 0), inline: true },
            { name: '🔗 Perfil', value: `[Abrir](https://www.roblox.com/users/${info.id}/profile)`, inline: true },
          )
          .setFooter({ text: 'FiskBot • Roblox' })
          .setTimestamp();
        await registrarLog(client, msg.guild.id, 'roblox', msg.author.id, { descricao: `<@${msg.author.id}> consultou perfil de ${info.name}` }, configs);
        await loading.edit({ content: null, embeds: [embed] });
      } catch (e) {
        await loading.edit({ content: null, embeds: [embedErro('Erro ao buscar perfil. Tente novamente.')] });
      }
      return;
    }

    if (cmd === 'avatar') {
      const nome = args.join(' ');
      if (!nome) return msg.reply({ embeds: [embedErro('Use: `!avatar <usuário roblox>`')] });
      const espera = checkCooldown(CDKey('avatar'), CD_MS);
      if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para usar novamente.`)] });
      const loading = await msg.reply('🔍 Buscando avatar...');
      try {
        const user = await resolverUsuario(nome);
        if (!user) { await loading.edit({ content: null, embeds: [embedErro('Usuário não encontrado.')] }); return; }
        const [thumb2d, thumb3d] = await Promise.all([
          fetchJSON(`${THUMB}/users/avatar?userIds=${user.id}&size=420x420&format=Png`),
          fetchJSON(`${THUMB}/users/avatar-3d?userId=${user.id}`),
        ]);
        const url2d = thumb2d.data?.[0]?.imageUrl;
        const url3d = thumb3d?.imageUrl;
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setLabel('Ver 2D').setStyle(ButtonStyle.Link).setURL(url2d || 'https://roblox.com'),
          new ButtonBuilder().setLabel('Ver 3D').setStyle(ButtonStyle.Link).setURL(url3d || 'https://roblox.com'),
        );
        const embed = new EmbedBuilder()
          .setColor(0x00a2ff)
          .setTitle(`🎭 Avatar de ${user.name}`)
          .setImage(url2d || null)
          .setFooter({ text: 'FiskBot • Roblox' });
        await loading.edit({ content: null, embeds: [embed], components: [row] });
      } catch {
        await loading.edit({ content: null, embeds: [embedErro('Erro ao buscar avatar.')] });
      }
      return;
    }

    if (cmd === 'grupo') {
      const id = args[0];
      if (!id || isNaN(id)) return msg.reply({ embeds: [embedErro('Use: `!grupo <id>`')] });
      const espera = checkCooldown(CDKey('grupo'), CD_MS);
      if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para usar novamente.`)] });
      const loading = await msg.reply('🔍 Buscando grupo...');
      try {
        const [info, icon] = await Promise.all([
          fetchJSON(`https://groups.roblox.com/v1/groups/${id}`),
          fetchJSON(`${THUMB}/groups/icons?groupIds=${id}&size=420x420&format=Png`),
        ]);
        const embed = new EmbedBuilder()
          .setColor(0x00a2ff)
          .setTitle(`👥 ${info.name}`)
          .setThumbnail(icon.data?.[0]?.imageUrl || null)
          .setDescription(info.description?.slice(0, 300) || 'Sem descrição.')
          .addFields(
            { name: '👑 Dono', value: info.owner?.username || 'N/A', inline: true },
            { name: '👥 Membros', value: info.memberCount?.toLocaleString('pt-BR') || '0', inline: true },
          )
          .setFooter({ text: 'FiskBot • Roblox' });
        await loading.edit({ content: null, embeds: [embed] });
      } catch {
        await loading.edit({ content: null, embeds: [embedErro('Grupo não encontrado.')] });
      }
      return;
    }

    if (cmd === 'gamepass') {
      const id = args[0];
      if (!id || isNaN(id)) return msg.reply({ embeds: [embedErro('Use: `!gamepass <id>`')] });
      const espera = checkCooldown(CDKey('gamepass'), CD_MS);
      if (espera) return msg.reply({ embeds: [embedErro(`Aguarde **${formatarTempo(espera)}** para usar novamente.`)] });
      const loading = await msg.reply('🔍 Buscando gamepass...');
      try {
        const info = await fetchJSON(`https://economy.roblox.com/v1/game-passes/${id}/game-pass-product-info`);
        const thumb = await fetchJSON(`${THUMB}/game-passes?gamePassIds=${id}&size=150x150&format=Png`);
        const embed = new EmbedBuilder()
          .setColor(0x00a2ff)
          .setTitle(`🎟️ ${info.Name}`)
          .setThumbnail(thumb.data?.[0]?.imageUrl || null)
          .addFields(
            { name: '💰 Preço', value: info.PriceInRobux ? `${info.PriceInRobux} R$` : 'Grátis', inline: true },
            { name: '👤 Criador', value: info.Creator?.Name || 'N/A', inline: true },
            { name: '🔗 Link', value: `[Ver no Roblox](https://www.roblox.com/game-pass/${id})`, inline: true },
          )
          .setFooter({ text: 'FiskBot • Roblox' });
        await loading.edit({ content: null, embeds: [embed] });
      } catch {
        await loading.edit({ content: null, embeds: [embedErro('Gamepass não encontrado.')] });
      }
      return;
    }
  });
}
