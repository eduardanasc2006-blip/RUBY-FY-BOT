import { EmbedBuilder } from 'discord.js';
import Usuario from '../db/models/Usuario.mjs';
import { calcularNivel, xpParaNivel, CARGOS_NIVEL } from '../utils/nivelCalc.mjs';
import { registrarLog } from '../utils/logger.mjs';
import { embedErro } from '../utils/embeds.mjs';
import { verificarConquistas } from './conquistas.mjs';

const MSGS_RECENTES = new Map();

export function register(client, configs) {
  client.on('messageCreate', async (msg) => {
    if (msg.author.bot || !msg.guild) return;
    const cfg = configs.get(msg.guild.id);
    const prefixo = cfg?.prefixo || '!';
    const guildId = msg.guild.id;

    if (!msg.content.startsWith(prefixo)) {
      await processarXP(msg, client, configs, guildId, cfg);
    }

    if (!msg.content.startsWith(prefixo)) return;
    const args = msg.content.slice(prefixo.length).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();

    if (cmd === 'xp') {
      const alvo = msg.mentions.users.first() || msg.author;
      const u = await Usuario.findOne({ userId: alvo.id, guildId });
      const { nivel, xpAtual, xpProximo } = calcularNivel(u?.xp || 0);
      const barra = gerarBarra(xpAtual, xpProximo);
      const embed = new EmbedBuilder()
        .setColor(0x00bfff)
        .setTitle(`⭐ XP de ${alvo.displayName}`)
        .addFields(
          { name: '⭐ XP Total', value: String(u?.xp || 0), inline: true },
          { name: '🏆 Nível', value: String(nivel), inline: true },
          { name: '📊 Progresso', value: `${barra} ${xpAtual}/${xpProximo}`, inline: false },
        )
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'rank') {
      const alvo = msg.mentions.users.first() || msg.author;
      const u = await Usuario.findOne({ userId: alvo.id, guildId });
      const { nivel, xpAtual, xpProximo } = calcularNivel(u?.xp || 0);
      const embed = new EmbedBuilder()
        .setColor(0x00bfff)
        .setTitle(`🏆 Rank de ${alvo.displayName}`)
        .addFields(
          { name: '🏆 Nível Atual', value: String(nivel), inline: true },
          { name: '⭐ XP Atual', value: `${xpAtual}/${xpProximo}`, inline: true },
          { name: '📈 XP Total', value: String(u?.xp || 0), inline: true },
        )
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }

    if (cmd === 'leaderboard') {
      const top = await Usuario.find({ guildId }).sort({ xp: -1 }).limit(10).lean();
      const linhas = top.map((u, i) => {
        const { nivel } = calcularNivel(u.xp || 0);
        return `**#${i + 1}** <@${u.userId}> — Nível **${nivel}** (${u.xp} XP)`;
      });
      const embed = new EmbedBuilder()
        .setColor(0x00bfff)
        .setTitle('🏆 Leaderboard Global')
        .setDescription(linhas.join('\n') || 'Nenhum dado ainda.')
        .setTimestamp();
      return msg.reply({ embeds: [embed] });
    }
  });
}

async function processarXP(msg, client, configs, guildId, cfg) {
  if (!msg.content.trim() || msg.content.length < 5) return;

  const chave = `xp:${msg.author.id}:${guildId}`;
  const agora = Date.now();
  const ultimo = MSGS_RECENTES.get(chave) || 0;
  if (agora - ultimo < 60_000) return;

  const recentes = [...MSGS_RECENTES.entries()]
    .filter(([k]) => k.startsWith(`hist:${msg.author.id}:${guildId}`))
    .map(([, v]) => v);

  if (recentes.includes(msg.content)) return;

  MSGS_RECENTES.set(chave, agora);
  MSGS_RECENTES.set(`hist:${msg.author.id}:${guildId}:${agora}`, msg.content);
  setTimeout(() => MSGS_RECENTES.delete(`hist:${msg.author.id}:${guildId}:${agora}`), 120_000);

  const ganho = Math.floor(Math.random() * 11) + 10;

  const u = await Usuario.findOneAndUpdate(
    { userId: msg.author.id, guildId },
    {
      $inc: { xp: ganho, mensagens: 1 },
      $setOnInsert: { userId: msg.author.id, guildId },
    },
    { upsert: true, new: true }
  );

  const nivelAntes = calcularNivel(u.xp - ganho).nivel;
  const nivelDepois = calcularNivel(u.xp).nivel;

  if (nivelDepois > nivelAntes) {
    await subirNivel(msg, client, configs, guildId, cfg, u, nivelDepois);
  }

  await verificarConquistas(client, msg.author.id, guildId, u, configs).catch(() => {});
  await atualizarMissoes(msg.author.id, guildId, 'mensagem').catch(() => {});
}

async function subirNivel(msg, client, configs, guildId, cfg, usuario, novoNivel) {
  const cargoParaDar = [...CARGOS_NIVEL].reverse().find(c => c.nivel <= novoNivel);

  const embed = new EmbedBuilder()
    .setColor(0xf1c40f)
    .setTitle('🎉 Subiu de Nível!')
    .setDescription(`Parabéns <@${usuario.userId}>! Você alcançou o **Nível ${novoNivel}**! ${cargoParaDar ? `\n🏅 Cargo: **${cargoParaDar.nome}**` : ''}`)
    .setTimestamp();
  await msg.channel.send({ embeds: [embed] }).catch(() => {});

  if (cfg?.cargoEquipe) {
    const membro = msg.guild.members.cache.get(usuario.userId);
    if (membro && cargoParaDar) {
      const cargoNome = cargoParaDar.nome;
      const cargo = msg.guild.roles.cache.find(r => r.name === cargoNome);
      if (cargo) await membro.roles.add(cargo).catch(() => {});
    }
  }

  await registrarLog(client, guildId, 'nivel', usuario.userId, {
    descricao: `<@${usuario.userId}> subiu para o Nível **${novoNivel}**.`,
  }, configs);
}

async function atualizarMissoes(userId, guildId, tipo) {
  try {
    const { default: Missao } = await import('../db/models/Missao.mjs');
    await Missao.updateOne(
      { userId, guildId, 'diarias.tipo': tipo, 'diarias.concluida': false },
      { $inc: { 'diarias.$.atual': 1 } }
    );
  } catch {}
}

function gerarBarra(atual, total, tamanho = 10) {
  const preenchido = Math.round((atual / total) * tamanho);
  return '█'.repeat(Math.max(0, preenchido)) + '░'.repeat(Math.max(0, tamanho - preenchido));
}
