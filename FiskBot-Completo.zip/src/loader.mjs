import { connectDB } from './db/connection.mjs';
import Config from './db/models/Config.mjs';

import { register as regConversao } from './systems/conversao.mjs';
import { register as regRoblox } from './systems/roblox.mjs';
import { register as regRelacionamentos } from './systems/relacionamentos.mjs';
import { register as regAfinidade } from './systems/afinidade.mjs';
import { register as regInteracoes } from './systems/interacoes.mjs';
import { register as regReputacao } from './systems/reputacao.mjs';
import { register as regXpNiveis } from './systems/xpniveis.mjs';
import { register as regQuiz } from './systems/quiz.mjs';
import { register as regForca } from './systems/forca.mjs';
import { register as regDiversao } from './systems/diversao.mjs';
import { register as regConquistas } from './systems/conquistas.mjs';
import { register as regMissoes } from './systems/missoes.mjs';
import { register as regTitulos } from './systems/titulos.mjs';
import { register as regPerfilVisual } from './systems/perfilvisual.mjs';
import { register as regShip } from './systems/ship.mjs';
import { register as regProdutos } from './systems/produtos.mjs';
import { register as regSuporte } from './systems/suporte.mjs';
import { register as regDenuncias } from './systems/denuncias.mjs';
import { register as regAvaliacoes } from './systems/avaliacoes.mjs';
import { register as regAdministracao } from './systems/administracao.mjs';
import { register as regLogs } from './systems/logs.mjs';
import { register as regAntiAbuso } from './systems/antiabuso.mjs';
import { register as regAjuda } from './systems/ajuda.mjs';
import { register as regEstatisticas } from './systems/estatisticas.mjs';

const configs = new Map();

async function carregarConfigs() {
  const todas = await Config.find().lean();
  for (const cfg of todas) {
    configs.set(cfg.guildId, cfg);
  }
  console.log(`[Loader] ${todas.length} configurações de servidor carregadas.`);
}

export async function loadSystems(client, mongoUri) {
  console.log('[Loader] Conectando ao MongoDB...');
  await connectDB(mongoUri);

  await carregarConfigs();

  client.on('guildCreate', async (guild) => {
    if (!configs.has(guild.id)) {
      const cfg = await Config.findOneAndUpdate(
        { guildId: guild.id },
        { $setOnInsert: { guildId: guild.id } },
        { upsert: true, new: true }
      );
      configs.set(guild.id, cfg);
    }
  });

  const sistemas = [
    ['Conversao', regConversao],
    ['Roblox', regRoblox],
    ['Relacionamentos', regRelacionamentos],
    ['Afinidade', regAfinidade],
    ['Interações', regInteracoes],
    ['Reputacao', regReputacao],
    ['XP & Níveis', regXpNiveis],
    ['Quiz', regQuiz],
    ['Forca', regForca],
    ['Diversão', regDiversao],
    ['Conquistas', regConquistas],
    ['Missões', regMissoes],
    ['Títulos', regTitulos],
    ['Perfil Visual', regPerfilVisual],
    ['Ship', regShip],
    ['Produtos', regProdutos],
    ['Suporte', regSuporte],
    ['Denúncias', regDenuncias],
    ['Avaliações', regAvaliacoes],
    ['Administração', regAdministracao],
    ['Logs', regLogs],
    ['Anti-Abuso', regAntiAbuso],
    ['Ajuda', regAjuda],
    ['Estatísticas', regEstatisticas],
  ];

  for (const [nome, fn] of sistemas) {
    try {
      fn(client, configs);
      console.log(`[Loader] ✅ Sistema carregado: ${nome}`);
    } catch (e) {
      console.error(`[Loader] ❌ Erro ao carregar ${nome}:`, e.message);
    }
  }

  console.log(`[Loader] 🚀 FiskBot Ultimate — ${sistemas.length} sistemas ativos.`);
  return configs;
}
