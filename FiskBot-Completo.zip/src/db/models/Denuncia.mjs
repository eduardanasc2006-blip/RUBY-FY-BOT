import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  guildId: { type: String, required: true },
  denuncianteId: { type: String, required: true },
  denunciadoId: { type: String, required: true },
  motivo: { type: String, required: true },
  descricao: { type: String, default: '' },
  provas: { type: String, default: '' },
  status: { type: String, enum: ['pendente', 'aceita', 'recusada'], default: 'pendente' },
}, { timestamps: true });

schema.index({ guildId: 1, status: 1 });

export default mongoose.models.Denuncia || mongoose.model('Denuncia', schema);
