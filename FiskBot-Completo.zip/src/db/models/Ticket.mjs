import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  ticketId: { type: String, required: true },
  guildId: { type: String, required: true },
  userId: { type: String, required: true },
  categoria: { type: String, required: true },
  channelId: { type: String, required: true },
  status: { type: String, enum: ['aberto', 'fechado'], default: 'aberto' },
  responsavel: { type: String, default: null },
  transcript: { type: [{ autor: String, conteudo: String, data: Date }], default: [] },
}, { timestamps: true });

schema.index({ guildId: 1, ticketId: 1 }, { unique: true });
schema.index({ guildId: 1, userId: 1 });

export default mongoose.models.Ticket || mongoose.model('Ticket', schema);
