import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  conquistas: { type: [String], default: [] },
  badges: { type: [String], default: [] },
}, { timestamps: true });

schema.index({ userId: 1, guildId: 1 }, { unique: true });

export default mongoose.models.Conquista || mongoose.model('Conquista', schema);
