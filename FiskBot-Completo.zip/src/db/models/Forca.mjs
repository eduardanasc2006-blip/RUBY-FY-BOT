import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  vitorias: { type: Number, default: 0 },
  derrotas: { type: Number, default: 0 },
}, { timestamps: true });

schema.index({ userId: 1, guildId: 1 }, { unique: true });

export default mongoose.models.Forca || mongoose.model('Forca', schema);
