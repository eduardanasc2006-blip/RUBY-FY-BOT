import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  guildId: { type: String, required: true },
  userId1: { type: String, required: true },
  userId2: { type: String, required: true },
  ativo: { type: Boolean, default: true },
  dataCasamento: { type: Date, default: Date.now },
  dataFim: { type: Date, default: null },
}, { timestamps: true });

schema.index({ guildId: 1, userId1: 1 });
schema.index({ guildId: 1, userId2: 1 });

export default mongoose.models.Casamento || mongoose.model('Casamento', schema);
