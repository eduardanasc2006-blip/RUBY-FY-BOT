import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  xp: { type: Number, default: 0 },
  nivel: { type: Number, default: 0 },
  reputacao: { type: Number, default: 0 },
  ultimaRep: { type: Date, default: null },
  tituloEquipado: { type: String, default: null },
  titulos: { type: [String], default: [] },
  mensagens: { type: Number, default: 0 },
  ultimaMensagem: { type: Date, default: null },
  ultimoXP: { type: Date, default: null },
}, { timestamps: true });

schema.index({ userId: 1, guildId: 1 }, { unique: true });

export default mongoose.models.Usuario || mongoose.model('Usuario', schema);
