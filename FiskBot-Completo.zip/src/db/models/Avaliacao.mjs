import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  guildId: { type: String, required: true },
  userId: { type: String, required: true },
  nota: { type: Number, min: 1, max: 5, required: true },
  comentario: { type: String, default: '' },
}, { timestamps: true });

schema.index({ guildId: 1 });

export default mongoose.models.Avaliacao || mongoose.model('Avaliacao', schema);
