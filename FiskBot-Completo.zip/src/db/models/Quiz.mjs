import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  total: { type: Number, default: 0 },
  acertos: { type: Number, default: 0 },
  erros: { type: Number, default: 0 },
  categoriaFavorita: { type: String, default: null },
  categoriasContagem: { type: Map, of: Number, default: {} },
}, { timestamps: true });

schema.index({ userId: 1, guildId: 1 }, { unique: true });

export default mongoose.models.Quiz || mongoose.model('Quiz', schema);
