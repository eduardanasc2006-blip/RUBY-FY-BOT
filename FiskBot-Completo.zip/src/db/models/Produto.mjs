import mongoose from 'mongoose';

const tabelaSchema = new mongoose.Schema({
  quantidade: String,
  preco: String,
}, { _id: false });

const schema = new mongoose.Schema({
  guildId: { type: String, required: true },
  nome: { type: String, required: true },
  categoria: { type: String, required: true },
  descricao: { type: String, default: '' },
  imagem: { type: String, default: null },
  tabela: { type: [tabelaSchema], default: [] },
  status: { type: String, enum: ['disponivel', 'poucas', 'fechado'], default: 'disponivel' },
}, { timestamps: true });

schema.index({ guildId: 1, nome: 1 });

export default mongoose.models.Produto || mongoose.model('Produto', schema);
