import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  guildId: { type: String, required: true },
  userId1: { type: String, required: true },
  userId2: { type: String, required: true },
  pontos: { type: Number, default: 0 },
  interacoes: { type: Number, default: 0 },
  ultimaInteracao: { type: Date, default: null },
}, { timestamps: true });

schema.index({ guildId: 1, userId1: 1, userId2: 1 }, { unique: true });

export default mongoose.models.Afinidade || mongoose.model('Afinidade', schema);
