import mongoose from 'mongoose';

const taxaHistSchema = new mongoose.Schema({
  taxa: Number,
  adminId: String,
  data: { type: Date, default: Date.now },
}, { _id: false });

const schema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  prefixo: { type: String, default: '!' },
  canalLogs: { type: String, default: null },
  canalSuporte: { type: String, default: null },
  canalDenuncias: { type: String, default: null },
  canalSugestoes: { type: String, default: null },
  cargoEquipe: { type: String, default: null },
  cargoSuporte: { type: String, default: null },
  cargoVendedor: { type: String, default: null },
  cargoAdmin: { type: String, default: null },
  cargoServicos: { type: String, default: null },
  taxa: { type: Number, default: 38 },
  taxaHistorico: { type: [taxaHistSchema], default: [] },
}, { timestamps: true });

export default mongoose.models.Config || mongoose.model('Config', schema);
