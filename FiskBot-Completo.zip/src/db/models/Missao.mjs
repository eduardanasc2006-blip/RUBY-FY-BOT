import mongoose from 'mongoose';

const progressoSchema = new mongoose.Schema({
  id: String,
  tipo: String,
  descricao: String,
  meta: Number,
  atual: { type: Number, default: 0 },
  recompensa: Number,
  concluida: { type: Boolean, default: false },
  expira: Date,
}, { _id: false });

const schema = new mongoose.Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },
  diarias: { type: [progressoSchema], default: [] },
  semanais: { type: [progressoSchema], default: [] },
  ultimaRenovacaoDiaria: { type: Date, default: null },
  ultimaRenovacaoSemanal: { type: Date, default: null },
}, { timestamps: true });

schema.index({ userId: 1, guildId: 1 }, { unique: true });

export default mongoose.models.Missao || mongoose.model('Missao', schema);
