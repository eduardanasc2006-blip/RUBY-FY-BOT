import mongoose from 'mongoose';

let connected = false;

export async function connectDB(uri) {
  if (connected) return;
  await mongoose.connect(uri, {
    serverSelectionTimeoutMS: 10000,
    maxPoolSize: 10,
  });
  connected = true;
  console.log('[DB] MongoDB conectado.');
}

export { mongoose };
