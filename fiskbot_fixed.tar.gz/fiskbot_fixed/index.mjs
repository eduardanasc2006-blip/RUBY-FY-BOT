import 'dotenv/config';
import { Client, GatewayIntentBits, Partials } from 'discord.js';

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});

client.once('ready', () => {
  console.log(`[FiskBot] ✅ Online como ${client.user.tag}`);
  client.user.setActivity('!ajuda', { type: 2 });
});

const token = process.env.DISCORD_BOT_TOKEN;
if (!token || token === 'SEU_TOKEN_AQUI') {
  console.error('[FiskBot] ❌ DISCORD_BOT_TOKEN não configurado!');
  console.error('[FiskBot] Configure a variável de ambiente DISCORD_BOT_TOKEN no Discloud.');
  process.exit(1);
}

client.login(token);
