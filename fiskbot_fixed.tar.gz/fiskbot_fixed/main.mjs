import 'dotenv/config';
import { Client } from 'discord.js';
import { loadSystems } from './src/loader.mjs';

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.warn('[FiskBot] ⚠️  MONGODB_URI não definido. Bot iniciará em modo offline (sem banco de dados).');
  console.warn('[FiskBot] Comandos como !ajuda, !robux, !8ball funcionarão normalmente.');
}

const loginOriginal = Client.prototype.login;

Client.prototype.login = async function (token) {
  try {
    console.log('[FiskBot] Carregando sistemas da expansão...');
    await loadSystems(this, MONGODB_URI);
    console.log('[FiskBot] ✅ Sistemas carregados! Fazendo login...');
  } catch (e) {
    console.error('[FiskBot] ❌ Erro ao carregar sistemas:', e.message);
  }
  return loginOriginal.call(this, token);
};

await import('./index.mjs');
